# Changelog

## 0.3.0 — 2026-10-22

- Add optional scene autosave with rotating recovery copies, unnamed-scene recovery and build/recovery guards.
- Add a read-only avatar check with resource links, preparation estimates and shared policy/audio validation.
- Browse and compare saved build receipts; save named client-location profiles in UserSettings.
- Share native audio resource validation between avatar checks and builds.
- Share asset dependency traversal and pending-importer policy interpretation; separate material adaptation from export coordination.
- Keep SDK readiness distinct from local-delivery setup and group repeated environment requirements in avatar reports.
- Propagate bulk edits independently across linked mip groups, preserving excluded levels and Undo/Redo.
- Shorten avatar-check, autosave, build-history and authoring-notice text. Check avatar drops a report for a different avatar instead of warning about it.
- Stop hashing built bundles; receipts no longer record a SHA-256 and the window no longer shows one.
- Keep the Console quiet on successful builds (only Build & Test delivery is announced) and keep at most 200 build receipts.
- Reorganize the VRCForward window: last build and avatar check first, then collapsible sections (texture array policies, local testing, scene autosave, build history, project). The VRChat project switch moves under Project; labels no longer clip.
- Build receipts, the last-build summary and build history list what each build prepared (texture arrays, audio resources).
- Add a starter Unity 6 avatar project (`-unity6-project.zip`) that locks SDK 3.10.5 and includes VRCForward, so ALCOM installs the SDK it otherwise filters out for Unity 6.
- README: drop Animator timing/physics and reversed particle sorting from the feature list (plain Unity 6 features; VRCForward does nothing for them).
- Find VRChat in a Windows Steam install on any drive, using Steam's registry entry. With Steam outside Program Files, Build & Test was refused until the client folder was chosen by hand.
- Install from VCC or ALCOM through the VPM listing at `https://markoapple.github.io/vpm/index.json`.
- Require exactly Avatars SDK 3.10.5 in `vpmDependencies` (`=3.10.5`). A bare version means "or later" to VCC/ALCOM, which let them upgrade the SDK to a version VRCForward then switches off for.

## 0.2.0 — Unreleased

### Avatar features

- Prepare native AudioRandomContainer dependencies through the normal VRChat SDK build, preserving source assets, playback settings and shared references.
- Support fixed, positive-offset and native negative-offset mip policies for texture arrays, including readable arrays, animated materials and controller overrides.
- Adapt readable ShaderLab sources when top mips are removed, preserving native sampling, texture metadata and custom render queues.
- Add signed texture-format support to the SDK performance scanner while keeping its existing limits. Preserve independent Animator timing/physics settings and reversed particle sorting.

### Authoring and setup

- Add mip-limit controls to the normal array Inspector and the VRCForward window.
- Let users link desktop quality groups explicitly and choose the source policy. Linked edits work without an open avatar, support Undo/Redo and preserve excluded quality levels.
- Check known array/shader incompatibilities before applying edits. Keep the previous setting and show a persistent explanation without repeating modal notices.
- Apply safe fallback policies only to build copies when older or generated settings cannot be represented. Record the adjustment without changing source assets.
- Add a persistent non-VRChat project mode and an independent local-delivery switch. Ordinary SDK builds on other versions remain available when no feature preparation is needed.
- Match Linux/Proton delivery to the selected Steam installation and the built avatar's Unity version.

### Reliability and diagnostics

- Recover temporary assets and native-mip settings after interrupted builds; clean up after successful, failed and rejected SDK builds.
- Bound native-mip staging memory and preserve unrelated project settings and changes made by other tools.
- Keep current setup separate from previous build results, retain failed-build details across reloads and redact home paths from copied diagnostics.
- Include Base SDK versions and build adjustments in diagnostics. Use clearer Guide, Copy build details and Show avatar file labels.
- Centralize version-specific SDK integration and shared policy checks. Add reusable Unity/SDK regression tests outside the package and verify release archives against their source.

## 0.1.0 — 2026-09-18

- Background integration with the normal VRChat SDK Build & Test workflow.
- Unity 6000.0.67f1 and Avatar SDK 3.10.5 compatibility checks.
- Native AudioResource / AudioRandomContainer validation support.
- Windows 64-bit build-target helper and Linux/Proton local-test delivery.
- Build receipts, diagnostics, and a compact status/settings window.
