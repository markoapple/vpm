using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("VRCForward.Tests.Editor")]
