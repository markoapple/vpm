using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    // Extend Unity's existing inspector header; retain its preview/import controls.
    [InitializeOnLoad]
    internal static class VrcForwardArrayAuthoring
    {
        static VrcForwardArrayAuthoring() => UnityEditor.Editor.finishedDefaultHeaderGUI += DrawHeader;

        private static void DrawHeader(UnityEditor.Editor editor)
        {
            if (!VrcForwardBuildContext.HandlesCurrentTarget || !VrcForwardBuildContext.Compatible) return;
            var arrays = editor.targets.Select(target => target as Texture2DArray ??
                (target is TextureImporter importer && importer.textureShape == TextureImporterShape.Texture2DArray
                    ? AssetDatabase.LoadAssetAtPath<Texture2DArray>(AssetDatabase.GetAssetPath(importer)) : null))
                .Where(array => array != null).ToArray();
            if (arrays.Length == editor.targets.Length) Draw(arrays);
        }

        internal static void DrawSelection()
        {
            var arrays = Selection.objects.OfType<Texture2DArray>().ToArray();
            if (arrays.Length == 0) return;
            GUILayout.Space(8);
            GUILayout.Label(arrays.Length == 1 ? arrays[0].name : arrays.Length + " selected texture arrays", EditorStyles.boldLabel);
            Draw(arrays, false);
        }

        internal static Object PolicyTarget(Texture2DArray array) =>
            AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(array)) as TextureImporter ?? (Object)array;

        private static void Draw(Texture2DArray[] arrays, bool inlineNotice = true)
        {
            bool busy = VrcForwardBuildContext.Active || EditorApplication.isPlayingOrWillChangePlaymode ||
                EditorApplication.isCompiling || EditorApplication.isUpdating;
            using (new EditorGUI.DisabledScope(busy))
            using (var so = new SerializedObject(arrays.Select(PolicyTarget).Distinct().ToArray()))
            {
                var group = so.FindProperty("m_MipmapLimitGroupName");
                var ignore = so.FindProperty("m_IgnoreMipmapLimit");
                if (group == null || ignore == null) return;
                var names = new[] { "" }.Concat(VrcForwardMipPolicies.Groups()).ToList();
                if (!names.Contains(group.stringValue)) names.Add(group.stringValue);
                var labels = names.Select(name => string.IsNullOrEmpty(name) ? "Global default" : name).ToArray();
                bool previousMixed = EditorGUI.showMixedValue;
                try
                {
                    EditorGUI.showMixedValue = ignore.hasMultipleDifferentValues;
                    EditorGUI.BeginChangeCheck();
                    bool use = EditorGUILayout.Toggle(new GUIContent("Use mip limits", "Use global or group mip policies for this array."), !ignore.boolValue);
                    if (EditorGUI.EndChangeCheck()) Apply(arrays, null, !use);
                    EditorGUI.showMixedValue = group.hasMultipleDifferentValues;
                    EditorGUI.BeginChangeCheck();
                    int choice = EditorGUILayout.Popup("Mipmap group", names.IndexOf(group.stringValue), labels);
                    if (EditorGUI.EndChangeCheck()) Apply(arrays, names[choice], null);
                }
                finally { EditorGUI.showMixedValue = previousMixed; }
            }
            var context = VrcForwardAuthoringNotice.Context;
            bool affected = arrays.Contains(context) || (context is Material material &&
                VrcForwardArrayPreflight.Properties(material, new System.Collections.Generic.HashSet<Texture2DArray>(arrays)).Length > 0);
            if (inlineNotice && affected && !string.IsNullOrEmpty(VrcForwardAuthoringNotice.Message))
            {
                EditorGUILayout.HelpBox(VrcForwardAuthoringNotice.Message, MessageType.Info);
                if (GUILayout.Button("Open VRCForward", EditorStyles.miniButton)) VrcForwardWindow.Open();
            }
        }

        // The same serialized Undo path as Unity's controls invokes authoring preflight.
        internal static void Apply(Texture2DArray[] arrays, string group, bool? ignore)
        {
            var targets = arrays.Select(PolicyTarget).Distinct().ToArray();
            using (var so = new SerializedObject(targets))
            {
                if (group != null) so.FindProperty("m_MipmapLimitGroupName").stringValue = group;
                if (ignore.HasValue) so.FindProperty("m_IgnoreMipmapLimit").boolValue = ignore.Value;
                so.ApplyModifiedProperties();
            }
            Undo.FlushUndoRecordObjects();
            foreach (var importer in targets.OfType<TextureImporter>()) importer.SaveAndReimport();
        }
    }
}
