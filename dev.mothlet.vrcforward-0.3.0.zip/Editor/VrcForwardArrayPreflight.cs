using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // Only arrays that actually lose top mips need a shader adaptation. Share
    // this decision and the material property selection with the export pass.
    internal static class VrcForwardArrayPreflight
    {
        // Pending importer edits may differ from the imported native asset.
        // Authoring guards and reports must inspect the same effective policy.
        internal static void ReadAuthoringPolicy(Texture2DArray texture, out string group, out bool ignore, out int mips)
        {
            var importer = AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(texture)) as TextureImporter;
            group = importer == null ? texture.mipmapLimitGroup : importer.mipmapLimitGroupName;
            ignore = importer == null ? texture.ignoreMipmapLimit : importer.ignoreMipmapLimit;
            mips = importer == null ? texture.mipmapCount : !importer.mipmapEnabled ? 1 :
                1 + (int)Math.Floor(Math.Log(Math.Max(texture.width, texture.height), 2));
        }

        internal sealed class Evaluation
        {
            internal string Group;
            internal bool Ignore;
            internal int Mips;
            // Set when the build copy must fall back to the global policy.
            internal string ProblemCode, Problem;
            internal long StagingBytes;
            internal bool NeedsShader;
        }

        // The authoring-time view of one array; the guard and Check avatar both read this.
        internal static Evaluation Evaluate(Texture2DArray texture, long reservedStagingBytes)
        {
            var result = new Evaluation();
            ReadAuthoringPolicy(texture, out result.Group, out result.Ignore, out result.Mips);
            if (!VrcForwardTextureArrayCompatibility.PolicyProblem(texture, result.Group, result.Ignore, result.Mips,
                reservedStagingBytes, out result.ProblemCode, out result.Problem, out result.StagingBytes))
                result.NeedsShader = NeedsShader(texture, result.Group, result.Ignore, result.Mips);
            return result;
        }

        internal static bool NeedsShader(Texture2DArray texture, string group, bool ignore, int mips)
        {
            if (ignore || mips <= 1 || string.IsNullOrEmpty(group)) return false;
            var policy = VrcForwardMipPolicies.Read(group, out _);
            return policy.HasValue && VrcForwardMipPolicies.Reduction(texture, policy.Value.Bias, mips) > 0;
        }

        internal static string[] Properties(Material material, ISet<Texture2DArray> textures)
        {
            if (material.shader == null || textures.Count == 0) return Array.Empty<string>();
            return Enumerable.Range(0, material.shader.GetPropertyCount())
                .Where(i => material.shader.GetPropertyType(i) == UnityEngine.Rendering.ShaderPropertyType.Texture)
                .Select(material.shader.GetPropertyName)
                .Where(name => material.GetTexture(name) is Texture2DArray array && textures.Contains(array))
                .OrderBy(name => name, StringComparer.Ordinal).ToArray();
        }

        internal static bool CheckShader(Material material, ISet<Texture2DArray> reduced, out string reason)
        {
            var names = Properties(material, reduced);
            reason = null;
            return names.Length == 0 || VrcForwardArrayShaderCompatibility.CanAdapt(material.shader, names, out reason);
        }
    }
}
