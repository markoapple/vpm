using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    /// <summary>
    /// Unity regenerates its reserved _TexelSize uniforms when materials load.
    /// Give rebased arrays a normal serialized uniform instead, on a generated
    /// copy of the user's shader. No renderer script or source edits are needed.
    /// </summary>
    internal static class VrcForwardArrayShaderCompatibility
    {
        internal sealed class Result
        {
            internal Shader Shader;
            internal Dictionary<string, string> Uniforms;
        }

        internal static bool CanAdapt(Shader shader, IEnumerable<string> properties, out string reason)
        {
            try
            {
                // Plan is read-only: inspect source/dependencies without importing
                // shaders, allocating textures or changing project settings.
                Plan(shader, properties.Distinct().ToDictionary(n => n + "_TexelSize", n => "_VrcForwardCheck" + n),
                    "Assets/_VRCForwardPreflight", new Dictionary<Shader, string>(), new HashSet<Shader>(),
                    new List<KeyValuePair<string, string>>());
                reason = null;
                return true;
            }
            catch (Exception exception)
            {
                reason = exception.Message + " Use a shader with readable ShaderLab source, or a mip policy that does not reduce the array.";
                return false;
            }
        }

        internal static Result Create(Shader original, IEnumerable<string> properties, string folder)
        {
            var names = properties.Distinct().OrderBy(x => x, StringComparer.Ordinal).ToArray();
            var prefix = "_VrcForward_" + Guid.NewGuid().ToString("N") + "_";
            var uniforms = names.ToDictionary(n => n + "_TexelSize", n => prefix + n + "_TexelSize");
            var planned = new Dictionary<Shader, string>();
            var active = new HashSet<Shader>();
            var files = new List<KeyValuePair<string, string>>();
            Plan(original, uniforms, folder, planned, active, files);
            foreach (var file in files)
            {
                File.WriteAllText(file.Key, file.Value);
                AssetDatabase.ImportAsset(file.Key, ImportAssetOptions.ForceSynchronousImport);
            }
            var shader = AssetDatabase.LoadAssetAtPath<Shader>(planned[original]);
            if (shader == null || ShaderUtil.ShaderHasError(shader))
                throw new InvalidOperationException("Could not compile the build-local texture-array shader derived from '" + original.name + "'.");
            return new Result { Shader = shader, Uniforms = uniforms };
        }

        private static string Plan(Shader source, Dictionary<string, string> uniforms, string folder,
            Dictionary<Shader, string> planned, HashSet<Shader> active, List<KeyValuePair<string, string>> files)
        {
            if (active.Contains(source)) throw new InvalidOperationException("Cyclic shader pass/fallback dependencies cannot be adapted safely: " + source.name);
            if (planned.TryGetValue(source, out var existing)) return GeneratedName(existing);
            var originalPath = AssetDatabase.GetAssetPath(source);
            if (!originalPath.EndsWith(".shader", StringComparison.OrdinalIgnoreCase) || !File.Exists(originalPath))
                throw new InvalidOperationException("Reducing texture-array mips needs readable ShaderLab source for shader '" + source.name + "'.");
            var text = File.ReadAllText(originalPath);
            var mask = MaskComments(text);
            var syntax = MaskStrings(mask);
            var header = Regex.Match(mask, "\\bShader\\s+\"(?<name>(?:\\\\.|[^\"\\\\])*)\"\\s*\\{");
            if (!header.Success) throw new InvalidOperationException("Unrecognized ShaderLab header in " + originalPath);
            string path = folder + "/ArrayShader_" + Guid.NewGuid().ToString("N") + ".shader";
            planned.Add(source, path);
            active.Add(source);
            // Text replacements against the original source, applied back to front.
            var edits = new List<(int Start, int Length, string Text)>();
            edits.Add((header.Groups["name"].Index, header.Groups["name"].Length, GeneratedName(path)));
            var properties = Regex.Match(syntax, "\\bProperties\\s*\\{");
            var declarations = string.Join("\n", uniforms.Values.Select(n => "[HideInInspector] " + n + " (\"VRCForward native array metadata\", Vector) = (0,0,0,0)"));
            if (properties.Success) edits.Add((properties.Index + properties.Length, 0, "\n" + declarations + "\n"));
            else edits.Add((header.Index + header.Length, 0, "\nProperties {\n" + declarations + "\n}\n"));
            string aliases = "\n" + string.Join("\n", uniforms.Select(p => "#define " + p.Key + " " + p.Value)) + "\n";
            foreach (Match block in Regex.Matches(syntax, "\\b(?:CGPROGRAM|HLSLPROGRAM|CGINCLUDE|HLSLINCLUDE)\\b"))
                edits.Add((block.Index + block.Length, 0, aliases));
            // Relative includes must still resolve from the original shader's
            // directory; includes within included files retain their own context.
            foreach (Match include in Regex.Matches(mask, "(?m)^\\s*#\\s*include(?:_with_pragmas)?\\s+\"(?<path>[^\"]+)\""))
            {
                var group = include.Groups["path"];
                // The shader compiler resolves Unity asset paths, not arbitrary
                // absolute filesystem paths (notably for UPM package includes).
                var candidate = Path.Combine(Path.GetDirectoryName(originalPath), group.Value).Replace('\\', '/');
                if (File.Exists(candidate)) edits.Add((group.Index, group.Length, candidate));
            }
            foreach (Match reference in Regex.Matches(mask, "\\b(?<kind>UsePass|Fallback)\\s+\"(?<name>[^\"]+)\""))
            {
                if (syntax[reference.Index] == ' ') continue;
                var value = reference.Groups["name"];
                bool pass = reference.Groups["kind"].Value == "UsePass";
                int split = pass ? value.Value.LastIndexOf('/') : value.Value.Length;
                if (split <= 0) throw new InvalidOperationException("Unrecognized shader pass reference: " + value.Value);
                var shaderName = value.Value.Substring(0, split);
                var dependency = Shader.Find(shaderName);
                if (dependency == null) throw new InvalidOperationException("Missing shader dependency: " + shaderName);
                // Built-in fallbacks cannot sample an authored Texture2DArray:
                // leave their ordinary fallback behavior untouched.
                var dependencyPath = AssetDatabase.GetAssetPath(dependency);
                if (!pass && !dependencyPath.EndsWith(".shader", StringComparison.OrdinalIgnoreCase)) continue;
                var replacement = Plan(dependency, uniforms, folder, planned, active, files) + (pass ? value.Value.Substring(split) : "");
                edits.Add((value.Index, value.Length, replacement));
            }
            foreach (var edit in edits.OrderByDescending(e => e.Start))
                text = text.Substring(0, edit.Start) + edit.Text + text.Substring(edit.Start + edit.Length);
            active.Remove(source);
            files.Add(new KeyValuePair<string, string>(path, text));
            return GeneratedName(path);
        }

        private static string GeneratedName(string path) => "Hidden/VRCForward/" + path.Substring("Assets/".Length).Replace(".shader", "");

        private static string MaskStrings(string source)
        {
            var result = new StringBuilder(source);
            bool quoted = false;
            for (int i = 0; i < source.Length; i++)
            {
                char c = source[i];
                if (c == '"') { quoted = !quoted; result[i] = ' '; }
                else if (quoted)
                {
                    result[i] = ' ';
                    if (c == '\\' && i + 1 < source.Length) result[++i] = ' ';
                }
            }
            return result.ToString();
        }

        private static string MaskComments(string source)
        {
            // Preserve offsets and quoted strings while hiding commented-out
            // ShaderLab tokens. Escaped quotes inside paths/names stay intact.
            var result = new StringBuilder(source);
            bool quoted = false, line = false, block = false;
            for (int i = 0; i < source.Length; i++)
            {
                char c = source[i], next = i + 1 < source.Length ? source[i + 1] : '\0';
                if (line)
                {
                    if (c == '\n' || c == '\r') line = false; else result[i] = ' ';
                    continue;
                }
                if (block)
                {
                    if (c == '*' && next == '/') { result[i] = result[i + 1] = ' '; block = false; i++; }
                    else if (c != '\n' && c != '\r') result[i] = ' ';
                    continue;
                }
                if (quoted)
                {
                    if (c == '\\' && next != '\0') i++;
                    else if (c == '"') quoted = false;
                    continue;
                }
                if (c == '"') { quoted = true; continue; }
                if (c == '/' && (next == '/' || next == '*'))
                {
                    line = next == '/'; block = next == '*'; result[i] = result[i + 1] = ' '; i++;
                }
            }
            return result.ToString();
        }
    }
}
