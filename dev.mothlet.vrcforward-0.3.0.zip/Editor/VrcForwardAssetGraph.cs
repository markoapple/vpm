using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    // Shared read-only traversal for preparation and preflight. Consumers choose
    // their roots and copy policy; this class never mutates or clones assets.
    internal static class VrcForwardAssetGraph
    {
        internal static Object[] Collect(Object[] roots)
        {
            // CollectDependencies omits editor controller state-machine/state
            // sub-assets. Follow serialized references too, with cycle detection.
            var seen = new HashSet<Object>();
            var queue = new Queue<Object>(EditorUtility.CollectDependencies(roots).Concat(roots));
            while (queue.Count > 0)
            {
                var asset = queue.Dequeue();
                if (asset == null || asset is Component || asset is GameObject || asset is MonoScript || !seen.Add(asset)) continue;
                // Custom render textures own update/initialization materials;
                // they are containers in the dependency graph, not pixel leaves.
                if ((asset is Texture && !(asset is CustomRenderTexture)) || asset is Shader || asset is Mesh || asset is AudioClip) continue;
                foreach (var reference in References(asset)) queue.Enqueue(reference);
            }
            return seen.ToArray();
        }

        // Assets the given components reference directly: the roots for Collect.
        internal static Object[] RootAssets(IEnumerable<Object> components) => components.SelectMany(References)
            .Where(x => !(x is Component) && !(x is GameObject) && !(x is MonoScript)).Distinct().ToArray();

        internal static bool IsEditorOnly(Transform transform)
        {
            for (var current = transform; current != null; current = current.parent)
                if (current.CompareTag("EditorOnly")) return true;
            return false;
        }

        internal static IEnumerable<Object> References(Object target)
        {
            if (target is Material material && material.parent != null) yield return material.parent;
            using (var serialized = new SerializedObject(target))
            {
                var property = serialized.GetIterator();
                bool enter = true;
                while (property.Next(enter))
                {
                    enter = ShouldEnter(property);
                    if (property.propertyType != SerializedPropertyType.ObjectReference || IsMetadata(property.name)) continue;
                    if (property.objectReferenceValue != null) yield return property.objectReferenceValue;
                }
            }
        }

        // Visit reference-bearing arrays while skipping numeric pixel/mesh data.
        // Rewrite passes use the same rules as read-only discovery.
        internal static bool ShouldEnter(SerializedProperty property)
        {
            if (property.propertyType != SerializedPropertyType.Generic && property.propertyType != SerializedPropertyType.ManagedReference) return false;
            if (!property.isArray || property.arraySize == 0) return true;
            var type = property.GetArrayElementAtIndex(0).propertyType;
            return type == SerializedPropertyType.Generic || type == SerializedPropertyType.ManagedReference || type == SerializedPropertyType.ObjectReference;
        }

        internal static bool IsMetadata(string name) => name == "m_CorrespondingSourceObject" ||
            name == "m_PrefabInstance" || name == "m_PrefabAsset" || name == "m_Script";
    }
}
