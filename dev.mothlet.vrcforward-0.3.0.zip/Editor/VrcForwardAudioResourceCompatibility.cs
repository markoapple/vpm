using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Audio;
using VRC.SDKBase.Editor;
using VRC.SDKBase.Editor.BuildPipeline;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    /// <summary>
    /// Prepare native Unity 6 audio containers on the SDK's build clone. Imported
    /// clips and authored containers remain untouched; only a clip's background
    /// loading flag changes in the generated dependency graph.
    /// </summary>
    [InitializeOnLoad]
    public sealed class VrcForwardAudioResourceCompatibility :
        IVRCSDKPreprocessAvatarCallback, IVRCSDKPostprocessAvatarCallback
    {
        private const string FolderPrefix = "Assets/_VRCForwardAudio_";
        private const string Registry = "audio";
        private const string FoldersKey = "VRCForward.GeneratedAudioFolders";
        internal const string ContainerType = "UnityEngine.Audio.AudioRandomContainer";
        private const string ElementType = "UnityEngine.Audio.AudioContainerElement";

        static VrcForwardAudioResourceCompatibility()
        {
            // Do not leave generated assets behind after an interrupted build/reload.
            AssemblyReloadEvents.beforeAssemblyReload += Cleanup;
            EditorApplication.quitting += Cleanup;
            EditorApplication.delayCall += () =>
            {
                if (!VrcForwardBuildContext.Active && VRC_SdkBuilder.ActiveBuildType == VRC_SdkBuilder.BuildType.None) Cleanup();
            };
        }

        // After NDMF/MA authoring, immediately before the resource validator.
        public int callbackOrder => 9999;

        public bool OnPreprocessAvatar(GameObject avatarGameObject)
        {
            if (!VrcForwardBuildContext.Preparing) return true;
            if (Prepare(avatarGameObject, out var error)) return true;
            return VrcForwardBuildContext.Fail(error, avatarGameObject);
        }

        public void OnPostprocessAvatar() => Cleanup();

        /// <summary>Apply to a disposable build clone, never an authoring avatar.</summary>
        public static bool Prepare(GameObject avatar, out string error)
        {
            error = null;
            if (avatar == null || !VrcForwardBuildContext.HandlesCurrentTarget) return true;
            var copies = new Dictionary<Object, Object>();
            var replacements = new List<KeyValuePair<AudioSource, AudioResource>>();
            string folder = null;
            try
            {
                var sources = VrcForwardAudioResourceGraph.Sources(avatar).ToArray();
                var affected = new List<AudioResource>();
                foreach (var resource in sources.Select(s => s.resource).Distinct())
                {
                    var dependencies = EditorUtility.CollectDependencies(new Object[] { resource });
                    if (!dependencies.OfType<AudioClip>().Any(VrcForwardAudioResourceGraph.NeedsBackgroundLoading)) continue;
                    if (resource.GetType().FullName != ContainerType)
                        throw new InvalidOperationException("Audio resource '" + resource.name +
                            "' needs background loading, but its native type cannot be copied safely. " +
                            "Enable Load In Background on its clips in the importer.");
                    if (!VrcForwardBuildContext.RequireCompatibility("Audio resource '" + resource.name + "'", out error))
                        throw new InvalidOperationException(error);
                    affected.Add(resource);
                    AddCopy(resource, copies);
                    foreach (var dependency in dependencies)
                    {
                        if (dependency == null) continue;
                        if (dependency is AudioClip clip)
                        {
                            if (VrcForwardAudioResourceGraph.NeedsBackgroundLoading(clip)) AddCopy(clip, copies);
                        }
                        else if (dependency.GetType().FullName == ContainerType ||
                                 dependency.GetType().FullName == ElementType)
                            AddCopy(dependency, copies);
                    }
                }
                if (affected.Count == 0) return true;

                foreach (var entry in copies)
                {
                    using (var serialized = new SerializedObject(entry.Value))
                    {
                        var property = serialized.GetIterator();
                        while (property.Next(true))
                        {
                            if (property.propertyType != SerializedPropertyType.ObjectReference) continue;
                            var reference = property.objectReferenceValue;
                            if (reference != null && copies.TryGetValue(reference, out var replacement))
                                property.objectReferenceValue = replacement;
                        }
                        if (entry.Value is AudioClip)
                        {
                            var flag = serialized.FindProperty("m_LoadInBackground");
                            if (flag == null || flag.propertyType != SerializedPropertyType.Boolean)
                                throw new InvalidOperationException("Unity's AudioClip background-loading field changed.");
                            flag.boolValue = true;
                        }
                        serialized.ApplyModifiedPropertiesWithoutUndo();
                    }
                }
                // Validate the copied graph before publishing any references on the avatar.
                foreach (var resource in affected)
                    if (EditorUtility.CollectDependencies(new[] { copies[resource] })
                        .OfType<AudioClip>().Any(VrcForwardAudioResourceGraph.NeedsBackgroundLoading))
                        throw new InvalidOperationException("Native audio resource references did not remap completely.");

                folder = VrcForwardGeneratedAssets.CreateFolder(Registry, FolderPrefix);
                VrcForwardGeneratedAssets.SaveCopies(folder, copies[affected[0]], copies.Values, "AudioResources");

                foreach (var source in sources)
                {
                    if (!copies.TryGetValue(source.resource, out var replacement)) continue;
                    replacements.Add(new KeyValuePair<AudioSource, AudioResource>(source, source.resource));
                    source.resource = (AudioResource)replacement;
                }
                VrcForwardBuildContext.AddPrepared(affected.Count, "audio resource", "audio resources");
                return true;
            }
            catch (Exception exception)
            {
                foreach (var previous in replacements)
                    if (previous.Key != null) previous.Key.resource = previous.Value;
                if (folder != null && AssetDatabase.IsValidFolder(folder)) AssetDatabase.DeleteAsset(folder);
                foreach (var copy in copies.Values)
                    if (copy != null && !EditorUtility.IsPersistent(copy)) Object.DestroyImmediate(copy);
                error = "Could not prepare Unity 6 audio resources: " + exception.Message;
                return false;
            }
        }

        private static void AddCopy(Object original, IDictionary<Object, Object> copies)
        {
            if (!copies.ContainsKey(original)) copies.Add(original, VrcForwardGeneratedAssets.Clone(original));
        }

        /// <summary>Release generated dependencies after export, failure or restart.</summary>
        public static void Cleanup() => VrcForwardGeneratedAssets.Cleanup(Registry, FolderPrefix, FoldersKey);
    }
}
