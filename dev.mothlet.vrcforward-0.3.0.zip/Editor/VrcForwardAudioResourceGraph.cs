using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Audio;

namespace VrcForward.Editor
{
    // Shared read-only discovery for validation and the authoring report. A
    // serialized audio PPtr curve alone does not establish a playable resource.
    internal static class VrcForwardAudioResourceGraph
    {
        internal static IEnumerable<AudioResource> Resources(GameObject avatar) =>
            Sources(avatar).Select(source => source.resource).Distinct();

        // Runtime AudioSources playing a native resource rather than a plain clip.
        internal static IEnumerable<AudioSource> Sources(GameObject avatar)
        {
            if (avatar == null) return Enumerable.Empty<AudioSource>();
            return avatar.GetComponentsInChildren<AudioSource>(true)
                .Where(source => !VrcForwardAssetGraph.IsEditorOnly(source.transform) &&
                    source.resource != null && !(source.resource is AudioClip));
        }

        // The SDK's clip-import rule, applied to clips inside native resources.
        internal static bool NeedsBackgroundLoading(AudioClip clip) =>
            clip.loadType == AudioClipLoadType.DecompressOnLoad && !clip.loadInBackground;
    }
}
