using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Audio;
using VRC.SDKBase.Editor.BuildPipeline;

namespace VrcForward.Editor
{
    /// <summary>
    /// SDK 3.10.5 checks AudioSource.clip, which is null for a Unity 6 audio container.
    /// Apply the same existing clip-import rule to native resource dependencies instead
    /// of accidentally letting new assets bypass the ordinary SDK requirement.
    /// The compatibility pass prepares build-local copies first; this final check
    /// still rejects any unsafe dependencies it could not adapt.
    /// </summary>
    public sealed class VrcForwardAudioResourceValidation : IVRCSDKPreprocessAvatarCallback
    {
        // Inspect the processed avatar, including resources added by ordinary authoring tools.
        public int callbackOrder => 10000;
        public bool OnPreprocessAvatar(GameObject avatarGameObject)
        {
            if (!VrcForwardBuildContext.Preparing) return true;
            if (Validate(avatarGameObject, out string error)) return true;
            return VrcForwardBuildContext.Fail(error, avatarGameObject);
        }

        public static bool Validate(GameObject avatar, out string error)
        {
            error = null;
            foreach (var inspection in Inspect(avatar))
            {
                if (inspection.Error != null) { error = inspection.Error; return false; }
                var clip = inspection.ClipsNeedingBackgroundLoading.FirstOrDefault();
                if (clip == null) continue;
                string path = AssetDatabase.GetAssetPath(clip);
                error = "Audio resource '" + inspection.Resource.name + "' uses clip '" + clip.name +
                    "' with Decompress On Load but without Load In Background. Enable Load In Background " +
                    "in the clip's import settings." +
                    (string.IsNullOrEmpty(path) ? "" : " Asset: " + path);
                return false;
            }
            return true;
        }

        internal sealed class Inspection
        {
            internal AudioResource Resource;
            internal AudioClip[] ClipsNeedingBackgroundLoading = Array.Empty<AudioClip>();
            internal string Error;
        }

        // A lazy, read-only view shared by the final build validator and the
        // authoring report. Ordinary clips stay under the SDK's own checks.
        internal static IEnumerable<Inspection> Inspect(GameObject avatar)
        {
            if (avatar == null) yield break;
            foreach (var resource in VrcForwardAudioResourceGraph.Resources(avatar))
            {
                var inspection = new Inspection { Resource = resource };
                UnityEngine.Object[] dependencies;
                try { dependencies = EditorUtility.CollectDependencies(new UnityEngine.Object[] { resource }); }
                catch (Exception e)
                {
                    inspection.Error = "Could not inspect the native audio resource '" + resource.name + "': " + e.Message;
                    dependencies = Array.Empty<UnityEngine.Object>();
                }
                inspection.ClipsNeedingBackgroundLoading = dependencies.OfType<AudioClip>().Distinct()
                    .Where(VrcForwardAudioResourceGraph.NeedsBackgroundLoading).ToArray();
                yield return inspection;
            }
        }
    }
}
