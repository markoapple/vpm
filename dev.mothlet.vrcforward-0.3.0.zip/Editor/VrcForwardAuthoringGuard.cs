using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace VrcForward.Editor
{
    // Observe ordinary Unity edits, not a second set of authoring controls. Only
    // evidence-backed array policies reachable from avatar runtime are guarded.
    [InitializeOnLoad]
    internal static class VrcForwardAuthoringGuard
    {
        private static bool applying;
        private sealed class Problem { internal string Key, Code, Message; internal UnityEngine.Object Context; }
        private static readonly Dictionary<int, Dictionary<string, PropertyModification>> Snapshots =
            new Dictionary<int, Dictionary<string, PropertyModification>>();

        private static bool observing;
        static VrcForwardAuthoringGuard() => Refresh();

        // Policy fields observed on arrays and their importers.
        private static readonly string[] ArrayFields = { "m_MipmapLimitGroupName", "m_IgnoreMipmapLimit" };
        private static readonly string[] ImporterFields = { "m_MipmapLimitGroupName", "m_IgnoreMipmapLimit", "m_EnableMipMap" };

        // Builds, Play Mode and batch runs make their own edits; never guard or snapshot those.
        private static bool Suspended => Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode ||
            BuildPipeline.isBuildingPlayer || VrcForwardBuildContext.Active;

        internal static void Refresh()
        {
            bool enabled = VrcForwardBuildContext.HandlesCurrentTarget && VrcForwardBuildContext.Compatible;
            if (observing == enabled) return;
            observing = enabled;
            Snapshots.Clear();
            if (enabled)
            {
                Undo.postprocessModifications += OnModifications;
                ObjectChangeEvents.changesPublished += OnObjectChanges;
                UnityEditor.SceneManagement.EditorSceneManager.sceneOpened += OnSceneOpened;
                EditorApplication.delayCall += SeedSnapshots;
            }
            else
            {
                Undo.postprocessModifications -= OnModifications;
                ObjectChangeEvents.changesPublished -= OnObjectChanges;
                UnityEditor.SceneManagement.EditorSceneManager.sceneOpened -= OnSceneOpened;
                EditorApplication.delayCall -= SeedSnapshots;
            }
        }

        private static void OnSceneOpened(UnityEngine.SceneManagement.Scene scene,
            UnityEditor.SceneManagement.OpenSceneMode mode) => SeedSnapshots();

        private static UndoPropertyModification[] OnModifications(UndoPropertyModification[] modifications)
        {
            if (applying || !observing || !VrcForwardSettings.IsVRChatProject || Suspended) return modifications;
            var relevant = modifications.Where(IsRelevant).ToArray();
            if (relevant.Length == 0) return modifications;
            var original = relevant;
            var originalModifications = modifications;
            applying = true;
            try
            {
                var shared = VrcForwardMipPolicies.Capture(relevant);
                modifications = VrcForwardMipPolicies.ExpandLinked(modifications);
                relevant = modifications.Where(IsRelevant).ToArray();
                var after = Problems();
                if (after.Count == 0) return modifications;
                Apply(relevant, false);
                var baseline = new HashSet<string>(Problems().Select(p => p.Key));
                var rejected = new List<UndoPropertyModification>();
                Problem introduced = null;
                // Keep unrelated targets in a multi-object Undo transaction.
                // Changes on the same object remain atomic (material references,
                // controller swaps and quality fields can depend on each other).
                foreach (var transaction in relevant.GroupBy(m => m.currentValue.target))
                {
                    Apply(transaction, true);
                    var problem = Problems().FirstOrDefault(p => !baseline.Contains(p.Key));
                    if (problem == null) continue;
                    Apply(transaction, false);
                    rejected.AddRange(transaction);
                    if (introduced == null) introduced = problem;
                }
                if (introduced == null) return modifications;
                bool canShare = shared != null && CanShare(shared, baseline);
                WarnOnce(introduced.Code + (shared == null ? "" : ":" + shared.Group),
                    introduced.Message, () => Apply(rejected, true), canShare ? shared : null, introduced.Context);
                // Redo must not re-enable a rejected edit.
                return modifications.Where(m => !rejected.Contains(m)).ToArray();
            }
            catch (Exception exception)
            {
                Apply(relevant, false);
                Apply(original, true);
                Debug.LogWarning("[VRCForward] Could not inspect this authoring edit. " + exception.Message);
                return originalModifications;
            }
            finally
            {
                applying = false;
                foreach (var target in relevant.Select(m => m.currentValue.target).Distinct())
                    if (target != null && Snapshots.ContainsKey(target.GetInstanceID()))
                        Snapshots[target.GetInstanceID()] = Capture(target);
                if (relevant.Any(m => m.currentValue.objectReference != m.previousValue.objectReference)) SeedSnapshots();
            }
        }

        private static bool IsRelevant(UndoPropertyModification modification)
        {
            var value = modification.currentValue;
            if (value?.target == null) return false;
            if (value.target is TextureImporter importer)
                return importer.textureShape == TextureImporterShape.Texture2DArray && ImporterFields.Contains(value.propertyPath);
            if (value.target is GameObject && (value.propertyPath == "m_TagString" || value.propertyPath == "m_IsActive")) return true;
            if (value.target is Texture2DArray) return ArrayFields.Contains(value.propertyPath);
            if (AssetDatabase.GetAssetPath(value.target) == VrcForwardMipPolicies.QualityAssetPath)
                return value.propertyPath.Contains("textureMipmapLimitSettings") || value.propertyPath.Contains("excludedTargetPlatforms");
            using (var serialized = new SerializedObject(value.target))
            {
                var property = serialized.FindProperty(value.propertyPath);
                return property != null && (property.propertyType == SerializedPropertyType.ObjectReference ||
                    (value.target is Renderer && property.propertyType == SerializedPropertyType.ArraySize)) &&
                    !(value.target is MonoScript) && !(value.target is Shader);
            }
        }

        private static List<Problem> Problems()
        {
            var result = new List<Problem>();
            foreach (var avatar in Resources.FindObjectsOfTypeAll<VRCAvatarDescriptor>())
            {
                if (EditorUtility.IsPersistent(avatar) || !avatar.gameObject.scene.IsValid()) continue;
                long reserved = 0;
                var assets = VrcForwardTextureArrayCompatibility.AuthoringAssets(avatar.gameObject, false).ToArray();
                var reduced = new HashSet<Texture2DArray>();
                foreach (var texture in assets.OfType<Texture2DArray>())
                {
                    var array = VrcForwardArrayPreflight.Evaluate(texture, reserved);
                    if (array.Problem == null)
                    {
                        reserved += array.StagingBytes;
                        if (array.NeedsShader) reduced.Add(texture);
                        continue;
                    }
                    result.Add(new Problem {
                        Key = avatar.GetInstanceID() + ":" + texture.GetInstanceID() + ":" + array.ProblemCode + ":" + array.Problem,
                        Code = array.ProblemCode,
                        Context = texture,
                        Message = "Texture array '" + texture.name + "' on avatar '" + avatar.name + "':\n\n" + array.Problem
                    });
                }
                foreach (var material in assets.OfType<Material>())
                    if (!VrcForwardArrayPreflight.CheckShader(material, reduced, out var reason))
                        result.Add(new Problem {
                            Key = avatar.GetInstanceID() + ":" + material.GetInstanceID() + ":array-shader:" + reason,
                            Code = "array-shader", Context = material,
                            Message = "Material '" + material.name + "' on avatar '" + avatar.name + "':\n\n" + reason
                        });
            }
            return result;
        }

        private static void Apply(IEnumerable<UndoPropertyModification> modifications, bool current)
        {
            var values = modifications.Select(m => current ? m.currentValue : m.previousValue).ToArray();
            foreach (var group in values.Where(v => v?.target != null).GroupBy(v => v.target))
            {
                using (var serialized = new SerializedObject(group.Key))
                {
                    foreach (var value in group)
                    {
                        var property = serialized.FindProperty(value.propertyPath);
                        if (property == null) continue;
                        switch (property.propertyType)
                        {
                            case SerializedPropertyType.String: property.stringValue = value.value; break;
                            case SerializedPropertyType.Boolean: property.boolValue = value.value == "1" || value.value == "true"; break;
                            case SerializedPropertyType.Enum:
                            case SerializedPropertyType.Integer:
                            case SerializedPropertyType.ArraySize: property.intValue = int.Parse(value.value, CultureInfo.InvariantCulture); break;
                            case SerializedPropertyType.ObjectReference: property.objectReferenceValue = value.objectReference; break;
                        }
                    }
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
            }
        }

        private static void WarnOnce(string code, string message, Action retry, VrcForwardMipPolicies.Edit shared,
            UnityEngine.Object context)
        {
            VrcForwardAuthoringNotice.Set(message + "\n\nThe previous setting was kept.", context);
            if (!VrcForwardSettings.instance.AcknowledgeWarning(code)) return;
            EditorApplication.delayCall += () =>
            {
                if (!VrcForwardSettings.IsVRChatProject) return;
                int choice = EditorUtility.DisplayDialogComplex("VRCForward — avatar setting",
                    message + "\n\nThe previous setting was kept.\n\n" +
                    (shared == null ? "" : "Apply across desktop levels links group '" + shared.Group +
                        "' so this and future edits apply to every desktop quality level.\n\n") +
                    "Non-VRChat project turns VRCForward off for this project. You can change this later in VRChat SDK > VRCForward.",
                    shared == null ? "Keep unchanged" : "Apply across desktop levels",
                    shared == null ? "Open VRCForward" : "Keep unchanged", "Non-VRChat project");
                if (shared != null && choice == 0)
                {
                    if (ApplyShared(shared))
                    { VrcForwardProjectSettings.instance.ShareGroup(shared.Group); VrcForwardAuthoringNotice.Clear(); }
                    return;
                }
                if (shared == null && choice == 1) VrcForwardWindow.Open();
                if (choice != 2) return;
                VrcForwardSettings.IsVRChatProject = false;
                retry();
                VrcForwardAuthoringNotice.Clear();
                UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
            };
        }

        // Complete-object Undo and Redo do not call postprocessModifications.
        // Unity publishes their changed targets once per frame; retain only
        // policy fields/reference slots, never texture pixels or scene copies.
        private static void OnObjectChanges(ref ObjectChangeEventStream stream)
        {
            if (applying || !observing) return;
            if (Suspended) { Snapshots.Clear(); return; }
            var ids = new HashSet<int>();
            bool graphChanged = Snapshots.Count == 0;
            for (int i = 0; i < stream.length; i++)
            {
                switch (stream.GetEventType(i))
                {
                    case ObjectChangeKind.ChangeAssetObjectProperties:
                        stream.GetChangeAssetObjectPropertiesEvent(i, out var asset); ids.Add(asset.instanceId); break;
                    case ObjectChangeKind.ChangeGameObjectOrComponentProperties:
                        stream.GetChangeGameObjectOrComponentPropertiesEvent(i, out var component); ids.Add(component.instanceId); break;
                    case ObjectChangeKind.CreateGameObjectHierarchy:
                    case ObjectChangeKind.DestroyGameObjectHierarchy:
                    case ObjectChangeKind.ChangeGameObjectStructure:
                    case ObjectChangeKind.ChangeGameObjectStructureHierarchy:
                    case ObjectChangeKind.ChangeGameObjectParent:
                        graphChanged = true; break;
                }
            }
            var changes = new List<UndoPropertyModification>();
            foreach (int id in ids)
            {
                var target = EditorUtility.InstanceIDToObject(id);
                if (target == null || !Snapshots.TryGetValue(id, out var previous)) continue;
                var current = Capture(target);
                foreach (var field in current)
                {
                    if (!previous.TryGetValue(field.Key, out var old))
                    {
                        // Growing a material list creates a reference slot which
                        // had no prior property. Treat that prior slot as empty;
                        // the same target transaction restores its previous size.
                        if (!(target is Renderer) || !field.Key.StartsWith("m_Materials.Array.data[", StringComparison.Ordinal)) continue;
                        old = new PropertyModification { target = target, propertyPath = field.Key };
                    }
                    if (old.value == field.Value.value && old.objectReference == field.Value.objectReference) continue;
                    changes.Add(new UndoPropertyModification { previousValue = old, currentValue = field.Value });
                    if (old.objectReference != field.Value.objectReference) graphChanged = true;
                }
            }
            if (changes.Count > 0) OnModifications(changes.ToArray());
            foreach (int id in ids)
            {
                var target = EditorUtility.InstanceIDToObject(id);
                if (target != null && Snapshots.ContainsKey(id)) Snapshots[id] = Capture(target);
            }
            if (graphChanged) SeedSnapshots();
        }

        private static Dictionary<string, PropertyModification> Capture(UnityEngine.Object target)
        {
            var result = new Dictionary<string, PropertyModification>();
            using (var so = new SerializedObject(target))
            {
                string[] fields = target is Texture2DArray ? ArrayFields : target is TextureImporter ? ImporterFields :
                    target is GameObject ? new[] { "m_TagString" } : target is Transform ? new[] { "m_Father" } : null;
                if (fields != null)
                {
                    foreach (string field in fields) CaptureProperty(so.FindProperty(field), target, result);
                    return result;
                }
                bool quality = AssetDatabase.GetAssetPath(target) == VrcForwardMipPolicies.QualityAssetPath;
                var iterator = so.GetIterator();
                bool enter = true;
                while (iterator.Next(enter))
                {
                    enter = !(target is AnimationClip && iterator.depth == 0 && iterator.name != "m_PPtrCurves");
                    if (iterator.isArray && (iterator.arrayElementType == "UInt8" || iterator.arrayElementType == "int" ||
                        iterator.arrayElementType == "float" || iterator.arrayElementType == "double" || iterator.arrayElementType == "Keyframe")) enter = false;
                    bool policy = quality && (iterator.propertyPath.Contains("textureMipmapLimitSettings") ||
                        iterator.propertyPath.Contains("excludedTargetPlatforms"));
                    if (policy || iterator.propertyType == SerializedPropertyType.ObjectReference ||
                        (target is Renderer && iterator.propertyType == SerializedPropertyType.ArraySize))
                        CaptureProperty(iterator, target, result);
                }
            }
            return result;
        }

        private static void CaptureProperty(SerializedProperty property, UnityEngine.Object target,
            Dictionary<string, PropertyModification> result)
        {
            if (property == null) return;
            var value = new PropertyModification { target = target, propertyPath = property.propertyPath };
            switch (property.propertyType)
            {
                case SerializedPropertyType.String: value.value = property.stringValue; break;
                case SerializedPropertyType.Boolean: value.value = property.boolValue ? "1" : "0"; break;
                case SerializedPropertyType.Integer:
                case SerializedPropertyType.Enum:
                case SerializedPropertyType.ArraySize: value.value = property.intValue.ToString(CultureInfo.InvariantCulture); break;
                case SerializedPropertyType.ObjectReference: value.objectReference = property.objectReferenceValue; break;
                default: return;
            }
            result[property.propertyPath] = value;
        }

        private static void SeedSnapshots()
        {
            if (!observing || Suspended) return;
            var targets = new HashSet<UnityEngine.Object>();
            var quality = VrcForwardMipPolicies.QualityAsset();
            if (quality != null) targets.Add(quality);
            foreach (var avatar in Resources.FindObjectsOfTypeAll<VRCAvatarDescriptor>())
            {
                if (EditorUtility.IsPersistent(avatar) || !avatar.gameObject.scene.IsValid()) continue;
                foreach (var transform in avatar.GetComponentsInChildren<Transform>(true))
                { targets.Add(transform); targets.Add(transform.gameObject); }
                foreach (var component in avatar.GetComponentsInChildren<Component>(true))
                    if (component is Renderer || component is Animator || component is Animation || component is VRCAvatarDescriptor)
                        targets.Add(component);
                foreach (var asset in VrcForwardTextureArrayCompatibility.AuthoringAssets(avatar.gameObject, true))
                {
                    if (asset == null) continue;
                    // Mesh/audio/image payloads cannot introduce array policies.
                    // Only the reference-bearing authoring containers are needed.
                    if (!(asset is Texture2DArray) && !(asset is Material) && !(asset is RuntimeAnimatorController) &&
                        !(asset is AnimationClip) && !(asset is ScriptableObject) && asset.GetType().Namespace != "UnityEditor.Animations") continue;
                    targets.Add(asset);
                    if (asset is Texture2DArray && AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(asset)) is TextureImporter importer)
                        targets.Add(importer);
                }
            }
            var ids = new HashSet<int>(targets.Select(t => t.GetInstanceID()));
            foreach (int id in Snapshots.Keys.Where(id => !ids.Contains(id)).ToArray()) Snapshots.Remove(id);
            foreach (var target in targets)
                if (!Snapshots.ContainsKey(target.GetInstanceID())) Snapshots.Add(target.GetInstanceID(), Capture(target));
        }

        private static bool CanShare(VrcForwardMipPolicies.Edit policy, HashSet<string> baseline)
        {
            var previous = VrcForwardMipPolicies.Set(policy, false);
            try { return previous.Count > 0 && !Problems().Any(p => !baseline.Contains(p.Key)); }
            finally
            {
                using (var so = new SerializedObject(VrcForwardMipPolicies.QualityAsset()))
                {
                    foreach (var value in previous) so.FindProperty(value.Key).intValue = value.Value;
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
            }
        }

        private static bool ApplyShared(VrcForwardMipPolicies.Edit policy)
        {
            if (!observing || !VrcForwardSettings.IsVRChatProject || VrcForwardBuildContext.Active) return false;
            // The user may have changed scene/assets between the warning and
            // this action. Recheck; an old consent must not force an unsafe edit.
            var baseline = new HashSet<string>(Problems().Select(p => p.Key));
            if (!CanShare(policy, baseline)) return false;
            VrcForwardMipPolicies.Set(policy, true);
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
            return true;
        }

        internal static bool LinkGroup(string group, int qualityLevel)
        {
            var policy = VrcForwardMipPolicies.At(group, qualityLevel);
            if (policy == null || !ApplyShared(policy))
            {
                VrcForwardAuthoringNotice.Set("Group '" + group +
                    "' cannot use that policy on the open avatars. Choose a supported desktop policy before linking.");
                return false;
            }
            VrcForwardProjectSettings.instance.ShareGroup(group);
            VrcForwardAuthoringNotice.Clear();
            return true;
        }

        internal static void ReportBuildFallback(Texture2DArray texture, string reason)
        {
            // Older/imported/script-generated assets may bypass interactive Undo
            // edits. Normalize only the build copy, without a modal or build gate.
            string message = "'" + texture.name + "': " + reason + " The build copy uses the global mip policy.";
            if (VrcForwardBuildContext.AddAdjustment(message)) Debug.LogWarning("[VRCForward] " + message, texture);
        }
    }
}
