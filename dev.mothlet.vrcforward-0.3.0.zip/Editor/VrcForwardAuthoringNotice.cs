using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // Keep the latest reason visible across reloads without repeating modal dialogs.
    internal static class VrcForwardAuthoringNotice
    {
        private const string Key = "VRCForward.LastAuthoringNotice";
        internal static string Message => SessionState.GetString(Key, "");
        internal static Object Context
        {
            get
            {
                string path = SessionState.GetString(Key + ".asset", "");
                return string.IsNullOrEmpty(path) ? EditorUtility.InstanceIDToObject(SessionState.GetInt(Key + ".instance", 0))
                    : AssetDatabase.LoadMainAssetAtPath(path);
            }
        }
        internal static void Set(string message, Object context = null)
        {
            SessionState.SetString(Key, message);
            SessionState.SetString(Key + ".asset", context == null ? "" : AssetDatabase.GetAssetPath(context));
            SessionState.SetInt(Key + ".instance", context == null ? 0 : context.GetInstanceID());
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
        }
        internal static void Clear() => Set("");
    }
}
