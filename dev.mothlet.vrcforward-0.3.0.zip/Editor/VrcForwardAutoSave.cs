using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDKBase.Editor;
using VRC.SDKBase.Editor.BuildPipeline;

namespace VrcForward.Editor
{
    // The timer survives closing the window. It saves authored scenes only, never assets or prefab overrides.
    [InitializeOnLoad]
    internal static class VrcForwardAutoSave
    {
        internal const string RecoveryDirectory = "UserSettings/VRCForwardRecovery";
        private const int MaximumSnapshots = 30;
        private const long MaximumSnapshotBytes = 64L * 1024 * 1024;
        private const long MaximumRecoveryBytes = 256L * 1024 * 1024;
        private static double nextSave, lastChange, requestHoldUntil, nextBuilderProbe, nextRecoveryRead;
        private static bool saving, sdkBuilding;
        private static IVRCSdkBuilderApi sdkBuilder;
        private static string status = "Autosave is off.", recoveryStatus;
        private static List<Snapshot> recovery = new List<Snapshot>();
        internal static event Action Changed;

        [Serializable]
        internal sealed class Snapshot
        {
            public int version = 1;
            public string id, scenePath, sceneName, sceneGuid, createdUtc;
            internal string Path => RecoveryDirectory + "/snapshot-" + id + ".unity";
            internal string RecordPath => RecoveryDirectory + "/snapshot-" + id + ".json";
        }

        static VrcForwardAutoSave()
        {
            Schedule();
            lastChange = EditorApplication.timeSinceStartup;
            EditorApplication.update += Update;
            ObjectChangeEvents.changesPublished += OnChanges;
            EditorSceneManager.sceneClosed += OnSceneClosed;
            VRCSdkControlPanel.OnSdkPanelEnable += OnSdkPanelEnabled;
            AssemblyReloadEvents.beforeAssemblyReload += Detach;
            EditorApplication.delayCall += ProbeBuilder;
        }

        internal static string Status => recoveryStatus ?? (!VrcForwardAutoSaveSettings.instance.enabled ? "Autosave is off." :
            PauseReason ?? status);
        internal static double SecondsUntilSave => Math.Max(0, nextSave - EditorApplication.timeSinceStartup);
        internal static IReadOnlyList<Snapshot> Recovery
        {
            get
            {
                if (EditorApplication.timeSinceStartup >= nextRecoveryRead) ReadRecovery();
                return recovery;
            }
        }

        internal static void Configure(bool enabled, int intervalSeconds, int snapshotsPerScene)
        {
            var settings = VrcForwardAutoSaveSettings.instance;
            settings.enabled = enabled;
            settings.intervalSeconds = intervalSeconds;
            settings.snapshotsPerScene = snapshotsPerScene;
            settings.Persist();
            recoveryStatus = null;
            status = enabled ? "Waiting for scene changes." : "Autosave is off.";
            Schedule();
            Changed?.Invoke();
        }

        private static void Schedule() => nextSave = EditorApplication.timeSinceStartup +
            Mathf.Clamp(VrcForwardAutoSaveSettings.instance.intervalSeconds, 60, 1800);
        private static void OnChanges(ref ObjectChangeEventStream changes)
        {
            if (!saving) lastChange = EditorApplication.timeSinceStartup;
        }
        private static void OnSceneClosed(Scene scene) => SessionState.EraseString("VRCForward.AutoSave.Unnamed." + scene.handle);
        private static void OnSdkPanelEnabled(object sender, EventArgs args) => ProbeBuilder();
        private static void ProbeBuilder()
        {
            nextBuilderProbe = EditorApplication.timeSinceStartup + 1;
            if (VRCSdkControlPanel.window == null || !VRCSdkControlPanel.TryGetBuilder<IVRCSdkBuilderApi>(out var builder) || ReferenceEquals(builder, sdkBuilder)) return;
            // Keep the running builder even if its panel is closed or another target is selected.
            if (sdkBuilding || (sdkBuilder != null && sdkBuilder.BuildState == SdkBuildState.Building)) return;
            Detach();
            sdkBuilder = builder;
            sdkBuilder.OnSdkBuildStart += OnBuildStart;
            sdkBuilder.OnSdkBuildFinish += OnBuildFinish;
        }
        private static void OnBuildStart(object sender, object target) => sdkBuilding = true;
        private static void OnBuildFinish(object sender, string message) => sdkBuilding = false;
        private static void Detach()
        {
            if (sdkBuilder == null) return;
            sdkBuilder.OnSdkBuildStart -= OnBuildStart;
            sdkBuilder.OnSdkBuildFinish -= OnBuildFinish;
            sdkBuilder = null;
        }
        internal static void HoldBuildRequest() => requestHoldUntil = EditorApplication.timeSinceStartup + 5;

        // The target-scoped compatibility transaction does not cover every SDK build or interrupted export.
        internal static string PauseReason
        {
            get
            {
                if (!VrcForwardSettings.IsVRChatProject) return "Paused: VRChat project is disabled.";
                if (Application.isBatchMode) return "Paused in batch mode.";
                if (EditorApplication.isPlayingOrWillChangePlaymode) return "Paused during Play Mode.";
                if (EditorApplication.isCompiling || EditorApplication.isUpdating) return "Paused while Unity compiles or imports.";
                if (BuildPipeline.isBuildingPlayer || VrcForwardBuildContext.Active || sdkBuilding ||
                    (VRCSdkControlPanel.window != null && VRCSdkControlPanel.window.PanelState == SdkPanelState.Building) ||
                    (sdkBuilder != null && sdkBuilder.BuildState == SdkBuildState.Building) ||
                    EditorApplication.timeSinceStartup < requestHoldUntil) return "Paused during an SDK build.";
                if (File.Exists(VrcForwardNegativeMipCompatibility.JournalPath) || VrcForwardGeneratedAssets.CleanupPending)
                    return "Paused until interrupted build recovery finishes.";
                if (PrefabStageUtility.GetCurrentPrefabStage() != null) return "Paused in Prefab Mode; Unity controls prefab saving.";
                if (GUIUtility.hotControl != 0 || EditorGUIUtility.editingTextField ||
                    EditorApplication.timeSinceStartup - lastChange < 2) return "Waiting until editing is idle.";
                return null;
            }
        }

        private static void Update()
        {
            if (EditorApplication.timeSinceStartup >= nextBuilderProbe) ProbeBuilder();
            if (!VrcForwardAutoSaveSettings.instance.enabled || saving || EditorApplication.timeSinceStartup < nextSave ||
                PauseReason != null) return;
            SaveNow();
        }

        internal static void SaveNow()
        {
            if (!VrcForwardAutoSaveSettings.instance.enabled || saving) return;
            string paused = PauseReason;
            if (paused != null) { status = paused; Changed?.Invoke(); return; }
            saving = true;
            recoveryStatus = null;
            int saved = 0, unnamed = 0;
            try
            {
                Directory.CreateDirectory(RecoveryDirectory);
                for (int i = 0; i < SceneManager.sceneCount; i++)
                {
                    Scene scene = SceneManager.GetSceneAt(i);
                    if (!scene.IsValid() || !scene.isLoaded || !scene.isDirty || EditorSceneManager.IsPreviewScene(scene)) continue;
                    // Never overwrite package scenes or imported recovery copies outside the authored Assets tree.
                    if (!string.IsNullOrEmpty(scene.path) && !scene.path.StartsWith("Assets/", StringComparison.Ordinal)) continue;
                    WriteSnapshot(scene);
                    if (string.IsNullOrEmpty(scene.path)) { unnamed++; continue; }
                    if (!VrcForwardAutoSaveAssetScope.Save(scene)) throw new IOException("Unity could not save " + scene.path + ". Its recovery copy is available.");
                    saved++;
                }
                if (saved > 0 || unnamed > 0)
                {
                    var settings = VrcForwardAutoSaveSettings.instance;
                    settings.lastSaveUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
                    settings.Persist();
                }
                status = saved == 0 && unnamed == 0 ? "No scene changes to save." :
                    (saved == 0 ? "" : "Saved " + saved + " scene" + (saved == 1 ? "." : "s.")) +
                    (unnamed == 0 ? "" : (saved == 0 ? "" : " ") + "Kept recovery copies of " + unnamed + " unnamed scene" + (unnamed == 1 ? "." : "s."));
            }
            catch (Exception exception)
            {
                status = "Autosave failed: " + exception.Message;
                Debug.LogWarning("[VRCForward] " + status);
            }
            finally
            {
                saving = false;
                Schedule(); // A failed save retries at the next interval, never on every editor update.
                nextRecoveryRead = 0;
                Changed?.Invoke();
            }
        }

        private static void WriteSnapshot(Scene scene)
        {
            var snapshot = new Snapshot
            {
                id = Guid.NewGuid().ToString("N"), scenePath = scene.path, sceneName = scene.name,
                sceneGuid = SceneIdentity(scene),
                createdUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture)
            };
            string pending = RecoveryDirectory + "/pending-" + snapshot.id + ".unity";
            string temporaryRecord = snapshot.RecordPath + ".tmp";
            try
            {
                if (!VrcForwardAutoSaveAssetScope.Save(scene, pending, true)) throw new IOException("Unity could not create a recovery copy of " + scene.name + ".");
                if (new FileInfo(pending).Length > MaximumSnapshotBytes)
                {
                    throw new IOException("The scene recovery copy exceeds 64 MiB; save this scene manually.");
                }
                File.Move(pending, snapshot.Path);
                File.WriteAllText(temporaryRecord, JsonUtility.ToJson(snapshot));
                File.Move(temporaryRecord, snapshot.RecordPath);
                ReadRecovery(true);
                PruneRecovery();
            }
            finally
            {
                if (File.Exists(temporaryRecord)) File.Delete(temporaryRecord);
                if (File.Exists(pending)) File.Delete(pending);
            }
        }

        private static string SceneIdentity(Scene scene)
        {
            if (!string.IsNullOrEmpty(scene.path)) return AssetDatabase.AssetPathToGUID(scene.path);
            string key = "VRCForward.AutoSave.Unnamed." + scene.handle;
            string id = SessionState.GetString(key, "");
            if (!string.IsNullOrEmpty(id)) return id;
            id = Guid.NewGuid().ToString("N");
            SessionState.SetString(key, id);
            return id;
        }

        private static void ReadRecovery(bool requireComplete = false)
        {
            var entries = new List<Snapshot>();
            try
            {
                if (Directory.Exists(RecoveryDirectory))
                foreach (string path in Directory.EnumerateFiles(RecoveryDirectory, "snapshot-*.unity"))
                {
                    string filename = System.IO.Path.GetFileNameWithoutExtension(path);
                    string id = filename.Substring("snapshot-".Length);
                    if (!Guid.TryParseExact(id, "N", out _)) continue;
                    // A crash between scene serialization and metadata must not hide the serialized copy.
                    var entry = new Snapshot { id = id, sceneName = "Recovered scene", sceneGuid = "orphan-" + id,
                        createdUtc = File.GetLastWriteTimeUtc(path).ToString("O", CultureInfo.InvariantCulture) };
                    try
                    {
                        if (File.Exists(entry.RecordPath) && new FileInfo(entry.RecordPath).Length <= 32768)
                        {
                            var recorded = JsonUtility.FromJson<Snapshot>(File.ReadAllText(entry.RecordPath));
                            if (recorded != null && recorded.version == 1 && recorded.id == id &&
                                DateTime.TryParse(recorded.createdUtc, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out _)) entry = recorded;
                        }
                    }
                    catch (ArgumentException) { }
                    catch (IOException) { }
                    entries.Add(entry);
                }
            }
            catch (IOException exception)
            {
                recoveryStatus = "Could not read recovery copies: " + exception.Message;
                if (requireComplete) throw;
            }
            catch (UnauthorizedAccessException exception)
            {
                recoveryStatus = "Could not read recovery copies: " + exception.Message;
                if (requireComplete) throw;
            }
            recovery = entries.OrderByDescending(entry => entry.createdUtc, StringComparer.Ordinal).ToList();
            nextRecoveryRead = EditorApplication.timeSinceStartup + 5;
        }

        private static void PruneRecovery()
        {
            long bytes = 0;
            int count = 0;
            var perScene = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var entry in recovery)
            {
                string key = string.IsNullOrEmpty(entry.sceneGuid) ? entry.scenePath ?? "" : entry.sceneGuid;
                perScene.TryGetValue(key, out int sceneCount);
                long size = new FileInfo(entry.Path).Length;
                if (sceneCount >= Mathf.Clamp(VrcForwardAutoSaveSettings.instance.snapshotsPerScene, 1, 10) ||
                    count >= MaximumSnapshots || bytes + size > MaximumRecoveryBytes)
                {
                    File.Delete(entry.Path);
                    File.Delete(entry.RecordPath);
                    continue;
                }
                perScene[key] = sceneCount + 1;
                count++;
                bytes += size;
            }
            nextRecoveryRead = 0;
        }

        internal static void OpenRecovery(Snapshot snapshot)
        {
            try
            {
                if (PauseReason != null) { recoveryStatus = PauseReason; return; }
                ReadRecovery();
                var owned = recovery.FirstOrDefault(entry => entry.id == snapshot?.id);
                if (owned == null) throw new IOException("This recovery copy is no longer available.");
                if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
                const string destination = "Assets/VRCForwardRecovery";
                Directory.CreateDirectory(destination);
                string copy = destination + "/Recovered-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + "-" + owned.id.Substring(0, 8) + ".unity";
                copy = AssetDatabase.GenerateUniqueAssetPath(copy);
                File.Copy(owned.Path, copy, false);
                AssetDatabase.ImportAsset(copy, ImportAssetOptions.ForceSynchronousImport);
                EditorSceneManager.OpenScene(copy, OpenSceneMode.Single);
                recoveryStatus = "Opened recovery copy at " + copy + ".";
            }
            catch (Exception exception) { recoveryStatus = "Could not open recovery copy: " + exception.Message; }
            finally { Changed?.Invoke(); }
        }

        internal static void ShowRecoveryFolder()
        {
            try
            {
                Directory.CreateDirectory(RecoveryDirectory);
                EditorUtility.RevealInFinder(System.IO.Path.GetFullPath(RecoveryDirectory));
            }
            catch (Exception exception) { recoveryStatus = "Could not show recovery folder: " + exception.Message; Changed?.Invoke(); }
        }
    }

    // Request callbacks can precede the SDK start event; a short hold bridges that transition and rejected requests.
    public sealed class VrcForwardAutoSaveBuildGuard : IVRCSDKBuildRequestedCallback
    {
        public int callbackOrder => int.MinValue;
        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            VrcForwardAutoSave.HoldBuildRequest();
            return true;
        }
    }
}
