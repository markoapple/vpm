using System;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

namespace VrcForward.Editor
{
    // Unity's scene-copy API also flushes dirty assets. Limit this service's synchronous saves to their scene file.
    public sealed class VrcForwardAutoSaveAssetScope : AssetModificationProcessor
    {
        private static string allowedScene;

        internal static bool Save(Scene scene, string destination = "", bool copy = false)
        {
            string previous = allowedScene;
            allowedScene = (string.IsNullOrEmpty(destination) ? scene.path : destination).Replace('\\', '/');
            try { return EditorSceneManager.SaveScene(scene, destination, copy); }
            finally { allowedScene = previous; }
        }

        private static string[] OnWillSaveAssets(string[] paths) => string.IsNullOrEmpty(allowedScene) ? paths :
            paths.Where(path => string.Equals(path.Replace('\\', '/'), allowedScene, StringComparison.Ordinal)).ToArray();
    }
}
