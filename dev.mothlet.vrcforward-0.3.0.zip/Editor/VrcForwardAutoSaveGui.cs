using System;
using System.Globalization;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // Draw inside the existing VRCForward window; the saving service does not depend on this foldout.
    internal static class VrcForwardAutoSaveGui
    {
        private static bool expanded, showRecovery;

        internal static void Draw()
        {
            if (!VrcForwardWindow.Section(ref expanded, "Scene autosave")) return;
            var settings = VrcForwardAutoSaveSettings.instance;
            bool enabled = EditorGUILayout.Toggle(new GUIContent("Enabled",
                "Save changed scenes while editing is idle and keep recovery copies. Assets and Prefab Mode use Unity's normal saving."), settings.enabled);
            int interval = settings.intervalSeconds;
            int retention = settings.snapshotsPerScene;
            using (new EditorGUI.DisabledScope(!enabled))
            {
                interval = EditorGUILayout.IntSlider("Interval (minutes)", Mathf.Clamp(interval / 60, 1, 30), 1, 30) * 60;
                retention = EditorGUILayout.IntSlider("Copies per scene", retention, 1, 10);
            }
            if (enabled != settings.enabled || interval != settings.intervalSeconds || retention != settings.snapshotsPerScene)
                VrcForwardAutoSave.Configure(enabled, interval, retention);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(VrcForwardAutoSave.Status, EditorStyles.wordWrappedLabel);
                using (new EditorGUI.DisabledScope(!enabled || VrcForwardAutoSave.PauseReason != null))
                    if (GUILayout.Button("Save now", EditorStyles.miniButton, GUILayout.Width(70))) VrcForwardAutoSave.SaveNow();
            }
            if (DateTime.TryParse(settings.lastSaveUtc, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var last))
                EditorGUILayout.LabelField("Last saved", last.ToLocalTime().ToString("g", CultureInfo.CurrentCulture));
            showRecovery = EditorGUILayout.Foldout(showRecovery, "Recovery copies", true);
            if (!showRecovery) { VrcForwardWindow.SectionEnd(); return; }
            foreach (var snapshot in VrcForwardAutoSave.Recovery.ToArray())
            {
                string name = string.IsNullOrEmpty(snapshot.sceneName) ? "Unnamed scene" : snapshot.sceneName;
                DateTime.TryParse(snapshot.createdUtc, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var created);
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(name + " · " + created.ToLocalTime().ToString("g", CultureInfo.CurrentCulture), snapshot.scenePath), EditorStyles.wordWrappedLabel);
                    using (new EditorGUI.DisabledScope(VrcForwardAutoSave.PauseReason != null))
                        if (GUILayout.Button(new GUIContent("Open copy", "Open as a separate scene; the original scene file is untouched."),
                            GUILayout.Width(80))) VrcForwardAutoSave.OpenRecovery(snapshot);
                }
            }
            if (VrcForwardAutoSave.Recovery.Count == 0) EditorGUILayout.LabelField("No recovery copies yet.");
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Show folder", EditorStyles.miniButton, GUILayout.Width(90))) VrcForwardAutoSave.ShowRecoveryFolder();
                GUILayout.FlexibleSpace();
            }
            VrcForwardWindow.SectionEnd();
        }
    }
}
