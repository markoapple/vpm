using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // Saving preferences and recovery history belong to this user, not the avatar package.
    [FilePath("UserSettings/VRCForwardAutoSave.asset", FilePathAttribute.Location.ProjectFolder)]
    internal sealed class VrcForwardAutoSaveSettings : ScriptableSingleton<VrcForwardAutoSaveSettings>
    {
        [SerializeField] internal bool enabled;
        [SerializeField] internal int intervalSeconds = 300;
        [SerializeField] internal int snapshotsPerScene = 5;
        [SerializeField] internal string lastSaveUtc = "";

        internal void Persist()
        {
            intervalSeconds = Mathf.Clamp(intervalSeconds, 60, 1800);
            snapshotsPerScene = Mathf.Clamp(snapshotsPerScene, 1, 10);
            Save(true);
        }
    }
}
