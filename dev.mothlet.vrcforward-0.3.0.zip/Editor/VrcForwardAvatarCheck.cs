using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    // An explicit snapshot of authored runtime consumers. Never prepare assets
    // here: MA/NDMF's eventual build clone still gets the final SDK checks.
    [Serializable]
    internal sealed class VrcForwardAvatarCheck
    {
        [SerializeField] private VRCAvatarDescriptor avatar;
        [SerializeField] private bool showResources;
        [NonSerialized] private Report report;
        [NonSerialized] private GUIStyle wrapped;

        internal sealed class Finding
        {
            internal string Code, Message;
            internal MessageType Severity;
            internal Object Context;
            internal readonly List<Object> Related = new List<Object>();
        }

        internal sealed class Report
        {
            internal GameObject Avatar;
            internal string CheckedAt;
            internal int ArrayCount, GroupedArrayCount, AudioResourceCount, PreparedAudioCount;
            internal long StagingBytes;
            internal readonly List<Finding> Findings = new List<Finding>();
            internal int Errors => Findings.Count(f => f.Severity == MessageType.Error);
            internal int Warnings => Findings.Count(f => f.Severity == MessageType.Warning);
            internal string Summary => (ArrayCount + AudioResourceCount == 0 ? "No texture arrays or native audio resources." :
                Count(ArrayCount, "texture array") + ", " + Count(AudioResourceCount, "native audio resource") + ".") + " " +
                (Errors + Warnings == 0 ? "No problems." : Count(Errors, "error") + ", " + Count(Warnings, "warning") + ".");

            internal string Text()
            {
                var text = new StringBuilder("VRCForward avatar check\n");
                text.AppendLine(Avatar == null ? "Avatar unavailable" : Avatar.name).AppendLine(CheckedAt)
                    .AppendLine(Summary)
                    .AppendLine("Grouped arrays: " + GroupedArrayCount + "; audio resources needing preparation: " + PreparedAudioCount);
                if (StagingBytes > 0) text.AppendLine("Temporary build memory for negative mip offsets: " + Bytes(StagingBytes));
                foreach (var finding in Findings)
                {
                    text.AppendLine().AppendLine(finding.Severity + " — " + finding.Code + ": " + finding.Message);
                    foreach (var context in Contexts(finding))
                    {
                        string path = AssetDatabase.GetAssetPath(context);
                        text.AppendLine("Resource: " + context.name + (string.IsNullOrEmpty(path) ? "" : " — " + path));
                    }
                }
                return text.ToString();
            }
        }

        internal void Draw(bool busy)
        {
            if (wrapped == null) wrapped = new GUIStyle(EditorStyles.label) { wordWrap = true };
            if (avatar == null && Selection.activeGameObject != null)
                avatar = Selection.activeGameObject.GetComponentInParent<VRCAvatarDescriptor>(true);
            GUILayout.Label("Avatar check", EditorStyles.boldLabel);
            using (new EditorGUI.DisabledScope(busy || EditorApplication.isPlayingOrWillChangePlaymode))
            using (new EditorGUILayout.HorizontalScope())
            {
                avatar = (VRCAvatarDescriptor)EditorGUILayout.ObjectField("Avatar", avatar, typeof(VRCAvatarDescriptor), true);
                using (new EditorGUI.DisabledScope(avatar == null))
                    if (GUILayout.Button(report == null ? "Check" : "Check again", EditorStyles.miniButton, GUILayout.Width(80)))
                        report = Analyze(avatar.gameObject);
            }
            // A report for a different avatar is never useful; drop it rather than explain it.
            if (report != null && (avatar == null || report.Avatar != avatar.gameObject)) report = null;
            if (report == null)
            {
                GUILayout.Label("Lists what VRCForward will prepare on this avatar and anything that blocks it.", wrapped);
                return;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(new GUIContent(report.Summary, "Checked " + report.CheckedAt), wrapped);
                if (GUILayout.Button(new GUIContent("Copy", "Copy this report"), EditorStyles.miniButton, GUILayout.Width(50)))
                    EditorGUIUtility.systemCopyBuffer = VrcForwardSupportText.Copy(report.Text());
            }
            if (report.StagingBytes > 0)
                GUILayout.Label("Temporary build memory for negative mip offsets: " + Bytes(report.StagingBytes), wrapped);
            foreach (var finding in report.Findings.Where(VisibleStatus)) DrawFinding(finding, report.Avatar);
            var details = report.Findings.Where(f => !VisibleStatus(f)).ToArray();
            if (details.Length == 0) return;
            showResources = EditorGUILayout.Foldout(showResources, "What will be prepared (" + details.Length + ")", true);
            if (showResources)
                foreach (var finding in details) DrawFinding(finding, report.Avatar);
        }

        private static bool VisibleStatus(Finding finding) => finding.Severity != MessageType.Info ||
            finding.Code == "no-preparation" || finding.Code == "preparation-inactive";

        private static IEnumerable<Object> Contexts(Finding finding)
        {
            if (finding.Context != null) yield return finding.Context;
            foreach (var context in finding.Related)
                if (context != null && context != finding.Context) yield return context;
        }

        private static void DrawFinding(Finding finding, GameObject checkedAvatar)
        {
            EditorGUILayout.HelpBox(finding.Message, finding.Severity);
            // The checked avatar is already in the field above; list only the resources involved.
            foreach (var context in Contexts(finding).Where(context => context != checkedAvatar))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label(context.name, EditorStyles.miniLabel);
                    if (GUILayout.Button("Select", EditorStyles.miniButton, GUILayout.Width(60)))
                    { Selection.activeObject = context; EditorGUIUtility.PingObject(context); }
                }
            }
        }

        internal static Report Analyze(GameObject avatar)
        {
            var result = new Report { Avatar = avatar, CheckedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) };
            if (avatar == null)
            {
                Add(result, "avatar-missing", "Choose an avatar before checking resources.", MessageType.Error, null);
                return result;
            }
            if (!VrcForwardBuildContext.HandlesCurrentTarget)
                Add(result, "preparation-inactive", "VRCForward is inactive. Turn on VRChat project and switch to Windows 64-bit " +
                    "to use its avatar features.", MessageType.Info, avatar);
            try { CheckArrays(avatar, result); }
            catch (Exception error)
            { Add(result, "array-inspection", "Could not finish inspecting the avatar's texture-array dependencies: " + error.Message, MessageType.Error, avatar); }
            try { CheckAudio(avatar, result); }
            catch (Exception error)
            { Add(result, "audio-inspection", "Could not finish inspecting the avatar's native audio resources: " + error.Message, MessageType.Error, avatar); }
            if (result.GroupedArrayCount == 0 && result.PreparedAudioCount == 0 && result.Errors == 0)
                Add(result, "no-preparation", "Nothing on this avatar needs VRCForward preparation.", MessageType.Info, avatar);
            return result;
        }

        private static void CheckArrays(GameObject avatar, Report result)
        {
            var assets = VrcForwardTextureArrayCompatibility.AuthoringAssets(avatar, false).ToArray();
            var arrays = assets.OfType<Texture2DArray>().Distinct()
                .OrderBy(t => AssetDatabase.GetAssetPath(t), StringComparer.Ordinal).ThenBy(t => t.name, StringComparer.Ordinal).ToArray();
            result.ArrayCount = arrays.Length;
            var reduced = new HashSet<Texture2DArray>();
            foreach (var texture in arrays)
            {
                var array = VrcForwardArrayPreflight.Evaluate(texture, result.StagingBytes);
                if (string.IsNullOrEmpty(array.Group)) continue;
                result.GroupedArrayCount++;
                AddCompatibility(result, texture);
                if (array.Problem != null)
                {
                    Add(result, array.ProblemCode, "Texture array '" + texture.name + "': " + array.Problem +
                        " The build copy will use the global mip policy until this is resolved.", MessageType.Warning, texture);
                    continue;
                }
                result.StagingBytes += array.StagingBytes;
                bool reduces = !array.Ignore && array.Mips > 1;
                var policy = reduces ? VrcForwardMipPolicies.Read(array.Group, out _) : null;
                if (reduces && !policy.HasValue)
                {
                    Add(result, "array-policy-unavailable", "Texture array '" + texture.name +
                        "': Unity's texture-array quality policy could not be read. Check the group's desktop quality settings before building.",
                        MessageType.Error, texture);
                    continue;
                }
                if (array.NeedsShader) reduced.Add(texture);
                string detail = array.Ignore ? "Ignores mip limits; its authored group is removed on the build copy." :
                    array.Mips <= 1 ? "A single mip needs no reduction; its authored group is removed on the build copy." :
                    "Group '" + array.Group + "' uses " + (policy.Value.IgnoreGlobalLimit ? "fixed limit " : "global offset ") + policy.Value.Bias + ". " +
                    (array.NeedsShader ? "Top-mip reduction also needs an adapted material shader." : "No shader adaptation is needed.");
                Add(result, "array-preparation", "Texture array '" + texture.name + "': " + detail +
                    (array.StagingBytes == 0 ? "" : " Temporary build memory: " + Bytes(array.StagingBytes) + "."), MessageType.Info, texture);
            }
            foreach (var material in assets.OfType<Material>().Distinct().OrderBy(m => m.name, StringComparer.Ordinal))
            {
                var properties = VrcForwardArrayPreflight.Properties(material, reduced);
                if (properties.Length == 0) continue;
                if (!VrcForwardArrayPreflight.CheckShader(material, reduced, out var reason))
                    Add(result, "array-shader", "Material '" + material.name + "' (" + string.Join(", ", properties) + "): " + reason,
                        MessageType.Error, material);
                else Add(result, "array-shader-preparation", "Material '" + material.name + "': the build will adapt " +
                    string.Join(", ", properties) + " on a shader copy for the reduced array.", MessageType.Info, material);
            }
        }

        private static void CheckAudio(GameObject avatar, Report result)
        {
            foreach (var inspection in VrcForwardAudioResourceValidation.Inspect(avatar))
            {
                result.AudioResourceCount++;
                var resource = inspection.Resource;
                if (inspection.Error != null)
                { Add(result, "audio-inspection", inspection.Error, MessageType.Error, resource); continue; }
                var clips = inspection.ClipsNeedingBackgroundLoading;
                if (clips.Length == 0)
                {
                    Add(result, "audio-ready", "Audio resource '" + resource.name + "' is ready.", MessageType.Info, resource);
                    continue;
                }
                result.PreparedAudioCount++;
                bool container = resource.GetType().FullName == VrcForwardAudioResourceCompatibility.ContainerType;
                if (container) AddCompatibility(result, resource);
                foreach (var clip in clips)
                    Add(result, container ? "audio-preparation" : "audio-unsupported-resource",
                        "Clip '" + clip.name + "' in '" + resource.name + "' is Decompress On Load without Load In Background. " +
                        (container ? "The build enables background loading on a copy; enable it in the clip importer to skip this step." :
                        "Enable Load In Background in the clip importer before building."),
                        container ? MessageType.Info : MessageType.Error, clip).Related.Add(resource);
            }
        }

        private static void AddCompatibility(Report result, Object resource)
        {
            if (!VrcForwardBuildContext.HandlesCurrentTarget ||
                VrcForwardBuildContext.RequireCompatibility("This avatar", out var error)) return;
            var existing = result.Findings.FirstOrDefault(f => f.Code == "preparation-version");
            if (existing == null)
            {
                Add(result, "preparation-version", error, MessageType.Error, resource);
                return;
            }
            if (existing.Context != resource && !existing.Related.Contains(resource)) existing.Related.Add(resource);
        }

        private static Finding Add(Report result, string code, string message, MessageType severity, Object context)
        {
            var finding = new Finding { Code = code, Message = message, Severity = severity, Context = context };
            result.Findings.Add(finding);
            return finding;
        }

        private static string Bytes(long bytes) => (bytes / 1048576d).ToString("0.00", CultureInfo.InvariantCulture) + " MiB";
        private static string Count(int value, string name) => value + " " + name + (value == 1 ? "" : "s");
    }
}
