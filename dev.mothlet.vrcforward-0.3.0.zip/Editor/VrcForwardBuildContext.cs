using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

namespace VrcForward.Editor
{
    // The SDK build-start event follows its request gates. Preprocessors share
    // this state so manual bakes and rejected requests cannot arm an export.
    internal static class VrcForwardBuildContext
    {
        internal static bool Active { get; private set; }
        internal static string Failure { get; private set; }
        private static readonly HashSet<string> adjustments = new HashSet<string>();
        internal static string[] Adjustments => adjustments.ToArray();
        internal static bool AddAdjustment(string message) => adjustments.Add(message);
        // What this build prepared, e.g. "2 texture arrays", for the receipt.
        private static readonly List<string> prepared = new List<string>();
        internal static string[] Prepared => prepared.ToArray();
        internal static void AddPrepared(int count, string one, string many)
        { if (count > 0) prepared.Add(count + " " + (count == 1 ? one : many)); }
        internal static bool HandlesCurrentTarget => VrcForwardSettings.IsVRChatProject &&
            EditorUserBuildSettings.activeBuildTarget == BuildTarget.StandaloneWindows64;
        internal static bool Preparing => Active && HandlesCurrentTarget &&
            !EditorApplication.isPlayingOrWillChangePlaymode;
        internal static bool Compatible => Application.unityVersion == VrcForwardClient.TargetEngine &&
            VrcForwardSdkBridge.InstalledSdkVersion() == VrcForwardClient.TargetSdk &&
            VrcForwardSdkBridge.InstalledPackageVersion("com.vrchat.base") == VrcForwardClient.TargetSdk;

        internal static void Request() { Failure = null; adjustments.Clear(); prepared.Clear(); }
        internal static void Begin() { Failure = null; adjustments.Clear(); prepared.Clear(); Active = HandlesCurrentTarget; }
        internal static void End()
        {
            // The SDK finish event owns the transaction, including early rejection
            // and failures after a different tool's preprocessor has run.
            try { VrcForwardAudioResourceCompatibility.Cleanup(); }
            finally
            {
                try { VrcForwardTextureArrayCompatibility.Cleanup(); }
                finally { Active = false; Failure = null; adjustments.Clear(); prepared.Clear(); }
            }
        }

        internal static bool Fail(string message, Object context = null)
        {
            Failure = message;
            Debug.LogError("[VRCForward] " + message, context);
            return false;
        }

        // Called only after a resource requiring adaptation has been found.
        internal static bool RequireCompatibility(string resource, out string error)
        {
            error = Compatible ? null : resource + " needs VRCForward build preparation. Use Unity " +
                VrcForwardClient.TargetEngine + " with VRChat Base and Avatars SDK " + VrcForwardClient.TargetSdk +
                ". This project uses Unity " + Application.unityVersion + ", Base SDK " +
                (VrcForwardSdkBridge.InstalledPackageVersion("com.vrchat.base") ?? "not installed") +
                " and Avatars SDK " + VrcForwardSdkBridge.InstalledSdkVersion() + ".";
            return error == null;
        }
    }
}
