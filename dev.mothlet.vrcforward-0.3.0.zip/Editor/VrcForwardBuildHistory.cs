using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace VrcForward.Editor
{
    internal static class VrcForwardBuildHistory
    {
        internal const string DirectoryPath = "Library/VRCForward/Receipts";
        internal const int MaximumEntries = 200;
        internal sealed class Entry
        {
            internal string Path;
            internal VrcForwardBuildReceipt Receipt;
        }

        // Read only bounded receipts, never avatar bundles. Partial records after
        // an interrupted write must not hide the remaining build history.
        internal static List<Entry> Read(out string error, int limit = MaximumEntries, string directory = DirectoryPath)
        {
            error = null;
            var entries = new List<Entry>();
            try
            {
                if (!Directory.Exists(directory)) return entries;
                var paths = new DirectoryInfo(directory).EnumerateFiles("*.json")
                    .OrderByDescending(file => file.LastWriteTimeUtc).ThenBy(file => file.Name, StringComparer.Ordinal)
                    .Take(Math.Max(0, Math.Min(MaximumEntries, limit)));
                foreach (var file in paths)
                {
                    try
                    {
                        if (file.Length > 32768) continue;
                        var receipt = JsonUtility.FromJson<VrcForwardBuildReceipt>(File.ReadAllText(file.FullName));
                        if (receipt == null || string.IsNullOrEmpty(receipt.id) || receipt.bytes < 0 || receipt.elapsedMilliseconds < 0) continue;
                        entries.Add(new Entry { Path = file.FullName, Receipt = receipt });
                    }
                    catch (ArgumentException) { }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
            }
            catch (IOException exception) { error = exception.Message; }
            catch (UnauthorizedAccessException exception) { error = exception.Message; }
            return entries;
        }

        // Keep only the newest receipts; Read never looks past MaximumEntries.
        internal static void Prune(string directory = DirectoryPath)
        {
            if (!Directory.Exists(directory)) return;
            foreach (var file in new DirectoryInfo(directory).EnumerateFiles("*.json")
                .OrderByDescending(file => file.LastWriteTimeUtc).ThenBy(file => file.Name, StringComparer.Ordinal)
                .Skip(MaximumEntries).ToArray())
            {
                try { file.Delete(); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        internal static string SizeAndTime(VrcForwardBuildReceipt receipt) =>
            (receipt.bytes / 1048576d).ToString("0.00") + " MiB · " + (receipt.elapsedMilliseconds / 1000d).ToString("0.0") + " s";

        internal static string Date(VrcForwardBuildReceipt receipt) =>
            DateTimeOffset.TryParse(receipt.timestampUtc, out var date)
                ? date.ToLocalTime().ToString("dd MMM yyyy · HH:mm") : "Unknown time";

        internal static string[] AddedAdjustments(VrcForwardBuildReceipt selected, VrcForwardBuildReceipt comparison) =>
            (selected.adjustments ?? Array.Empty<string>()).Where(value => !string.IsNullOrEmpty(value))
                .Except(comparison.adjustments ?? Array.Empty<string>()).ToArray();

        internal static string[] RemovedAdjustments(VrcForwardBuildReceipt selected, VrcForwardBuildReceipt comparison) =>
            AddedAdjustments(comparison, selected);
    }
}
