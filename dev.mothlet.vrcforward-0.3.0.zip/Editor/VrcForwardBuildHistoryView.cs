using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    [Serializable]
    internal sealed class VrcForwardBuildHistoryView
    {
        [SerializeField] private bool expanded;
        [SerializeField] private string avatarName = "", selectedId = "", comparisonId = "";
        [NonSerialized] private List<VrcForwardBuildHistory.Entry> entries;
        [NonSerialized] private string readError;
        [NonSerialized] private double lastRead;

        internal void Invalidate() => entries = null;

        internal void Draw()
        {
            if (!VrcForwardWindow.Section(ref expanded, "Build history")) return;
            DrawBody();
            VrcForwardWindow.SectionEnd();
        }

        private void DrawBody()
        {
            if (entries == null || EditorApplication.timeSinceStartup - lastRead > 4)
            {
                entries = VrcForwardBuildHistory.Read(out readError);
                lastRead = EditorApplication.timeSinceStartup;
            }
            if (!string.IsNullOrEmpty(readError)) EditorGUILayout.HelpBox("Could not read build history: " + readError, MessageType.Warning);
            if (entries.Count == 0) { GUILayout.Label("No saved build receipts", EditorStyles.miniLabel); return; }

            var names = new[] { "" }.Concat(entries.Select(entry => entry.Receipt.avatarName)
                .Where(name => !string.IsNullOrEmpty(name)).Distinct().OrderBy(name => name, StringComparer.Ordinal)).ToArray();
            int filter = Math.Max(0, Array.IndexOf(names, avatarName));
            avatarName = names[filter];
            int chosenFilter = EditorGUILayout.Popup("Avatar name", filter,
                names.Select(name => string.IsNullOrEmpty(name) ? "All builds" : name).ToArray());
            if (chosenFilter != filter) { avatarName = names[chosenFilter]; selectedId = comparisonId = ""; }
            var visible = entries.Where(entry => string.IsNullOrEmpty(avatarName) || entry.Receipt.avatarName == avatarName).ToArray();
            if (visible.Length == 0) return;
            int selected = Math.Max(0, Array.FindIndex(visible, entry => entry.Receipt.id == selectedId));
            int chosen = EditorGUILayout.Popup("Build", selected, visible.Select(Label).ToArray());
            if (chosen != selected) comparisonId = "";
            var entry = visible[chosen];
            selectedId = entry.Receipt.id;
            DrawReceipt(entry);

            var comparisons = entries.Where(candidate => candidate.Receipt.id != selectedId &&
                candidate.Receipt.avatarName == entry.Receipt.avatarName).ToArray();
            if (comparisons.Length > 0)
            {
                int compare = Array.FindIndex(comparisons, candidate => candidate.Receipt.id == comparisonId) + 1;
                int chosenComparison = EditorGUILayout.Popup("Compare with", compare,
                    new[] { "Choose a build" }.Concat(comparisons.Select(Label)).ToArray());
                comparisonId = chosenComparison == 0 ? "" : comparisons[chosenComparison - 1].Receipt.id;
                if (chosenComparison > 0) DrawComparison(entry.Receipt, comparisons[chosenComparison - 1].Receipt);
            }
        }

        private static string Label(VrcForwardBuildHistory.Entry entry) => VrcForwardBuildHistory.Date(entry.Receipt) +
            " · " + (string.IsNullOrEmpty(entry.Receipt.avatarName) ? "Unnamed avatar" : entry.Receipt.avatarName) +
            " · " + (entry.Receipt.sdkBuildSucceeded ? "Complete" : "Failed");

        private static void DrawReceipt(VrcForwardBuildHistory.Entry entry)
        {
            var receipt = entry.Receipt;
            Row("SDK build", receipt.sdkBuildSucceeded ? "Complete" : "Failed");
            if (receipt.stagedForClient) Row("Local delivery", "Delivered");
            Row("Editor / SDK", (receipt.editorVersion ?? "Unknown") + " / " + (receipt.sdkVersion ?? "Unknown"));
            Row("Base SDK", receipt.baseSdkVersion ?? "Not recorded");
            Row("Size / time", VrcForwardBuildHistory.SizeAndTime(receipt));
            if (receipt.prepared != null && receipt.prepared.Length > 0) Row("Prepared", string.Join(", ", receipt.prepared));
            if (!string.IsNullOrEmpty(receipt.error)) EditorGUILayout.HelpBox(receipt.error, MessageType.None);
            foreach (string adjustment in (receipt.adjustments ?? Array.Empty<string>()).Where(value => !string.IsNullOrEmpty(value)))
                EditorGUILayout.HelpBox(adjustment, MessageType.Info);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Copy build details", EditorStyles.miniButton))
                    EditorGUIUtility.systemCopyBuffer = VrcForwardSupportText.Receipt(receipt);
                using (new EditorGUI.DisabledScope(!File.Exists(entry.Path)))
                    if (GUILayout.Button("Show receipt", EditorStyles.miniButton)) EditorUtility.RevealInFinder(entry.Path);
            }
        }

        private static void DrawComparison(VrcForwardBuildReceipt selected, VrcForwardBuildReceipt comparison)
        {
            GUILayout.Space(4);
            GUILayout.Label("Changes since that build", EditorStyles.boldLabel);
            Row("Editor", Change(comparison.editorVersion, selected.editorVersion));
            Row("Avatars SDK", Change(comparison.sdkVersion, selected.sdkVersion));
            Row("Base SDK", Change(comparison.baseSdkVersion, selected.baseSdkVersion));
            Row("Build target", Change(comparison.buildTarget, selected.buildTarget));
            if (selected.sdkBuildSucceeded && comparison.sdkBuildSucceeded)
                Row("Bundle size", Delta(((double)selected.bytes - comparison.bytes) / 1048576d, " MiB"));
            Row("Build time", Delta(((double)selected.elapsedMilliseconds - comparison.elapsedMilliseconds) / 1000d, " s"));
            var added = VrcForwardBuildHistory.AddedAdjustments(selected, comparison);
            var removed = VrcForwardBuildHistory.RemovedAdjustments(selected, comparison);
            foreach (string adjustment in added) EditorGUILayout.HelpBox("Added preparation adjustment: " + adjustment, MessageType.Info);
            foreach (string adjustment in removed) EditorGUILayout.HelpBox("Removed preparation adjustment: " + adjustment, MessageType.None);
            if (added.Length == 0 && removed.Length == 0) Row("Adjustments", "Unchanged");
        }

        private static string Change(string before, string after) => before == after ? (after ?? "Not recorded") + " (unchanged)" :
            (before ?? "Not recorded") + " → " + (after ?? "Not recorded");
        private static string Delta(double value, string unit) => value.ToString("+0.00;-0.00;0.00") + unit;
        private static void Row(string name, string value) => EditorGUILayout.LabelField(new GUIContent(name), new GUIContent(value, value));
    }
}
