using System;

namespace VrcForward.Editor
{
    [Serializable]
    public sealed class VrcForwardBuildReceipt
    {
        public string id;
        public string timestampUtc;
        public string editorVersion;
        public string sdkVersion;
        public string baseSdkVersion;
        public string buildTarget;
        public string avatarName;
        public string sdkBundle;
        public string bundleEngine;
        public long bytes;
        public long elapsedMilliseconds;
        public bool sdkBuildSucceeded;
        public bool stagedForClient;
        public string clientDirectory;
        public string clientEngine;
        public string deliveredBundle;
        public string error;
        public string[] adjustments;
        public string[] prepared;
    }
}
