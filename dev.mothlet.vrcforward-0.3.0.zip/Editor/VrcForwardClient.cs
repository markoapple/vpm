using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace VrcForward.Editor
{
    public sealed class ClientInstallation
    {
        public string Directory;
        public string AvatarDirectory;
        public string EngineVersion;
        public bool MatchesEditor => VrcForwardClient.IsTargetEngine(EngineVersion);
        public string Error;
    }

    public static class VrcForwardClient
    {
        public const string TargetEngine = VrcForwardSdkAdapter.Engine;
        public const string TargetSdk = VrcForwardSdkAdapter.Sdk;
        public static bool IsTargetEngine(string value) => value == TargetEngine ||
            (!string.IsNullOrEmpty(value) && value.StartsWith(TargetEngine + "-", StringComparison.Ordinal));

        public static string ReadClientEngine(string directory)
        {
            var path = Path.Combine(directory ?? "", "VRChat_Data", "globalgamemanagers");
            if (!File.Exists(path)) return "";
            // The serialized-file header embeds the engine string, before the object table.
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                var header = new byte[Math.Min(256, stream.Length)];
                int count = stream.Read(header, 0, header.Length);
                var match = Regex.Match(Encoding.ASCII.GetString(header, 0, count),
                    @"(?:6000|20\d{2})\.\d+\.\d+[abfp]\d+(?:-[A-Za-z0-9._]+)?");
                return match.Success ? match.Value : "";
            }
        }

        public static string ReadBundleEngine(string path)
        {
            using (var reader = new BinaryReader(File.OpenRead(path), Encoding.ASCII))
            {
                if (ReadCString(reader) != "UnityFS") throw new InvalidDataException("Not a UnityFS asset bundle.");
                reader.ReadBytes(4); // Big-endian bundle format number; not the engine version.
                ReadCString(reader); // Compatibility string, usually 5.x.x.
                var engine = ReadCString(reader);
                if (string.IsNullOrEmpty(engine)) throw new InvalidDataException("Asset bundle has no engine version.");
                return engine;
            }
        }

        private static string ReadCString(BinaryReader reader)
        {
            var bytes = new List<byte>();
            for (int i = 0; i < 128; i++)
            {
                byte b = reader.ReadByte();
                if (b == 0) return Encoding.ASCII.GetString(bytes.ToArray());
                bytes.Add(b);
            }
            throw new InvalidDataException("Invalid asset-bundle header string.");
        }

        public static ClientInstallation Locate(string configuredClient, string configuredAvatars) =>
            LocateForEditor(configuredClient, configuredAvatars, TargetEngine);

        internal static ClientInstallation LocateForEditor(string configuredClient, string configuredAvatars, string engine)
        {
            string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            bool windows = Path.DirectorySeparatorChar == '\\';
            string localLow = windows ? Path.GetFullPath(Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "..", "LocalLow", "VRChat", "VRChat", "Avatars")) : "";
            var roots = windows
                ? new[] { WindowsSteamPath() }.Concat(new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                    Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) }
                    .Where(p => !string.IsNullOrEmpty(p)).Select(p => Path.Combine(p, "Steam")))
                    .Where(p => !string.IsNullOrEmpty(p))
                : new[] { Path.Combine(home, ".local/share/Steam"), Path.Combine(home, ".steam/steam"),
                    Path.Combine(home, ".var/app/com.valvesoftware.Steam/.local/share/Steam") };
            return LocateInstallation(configuredClient, configuredAvatars, engine, roots, localLow, windows);
        }

        // Steam can live on any drive; it records its folder in the registry. Reflection keeps
        // this compiling when a project targets .NET Standard for editor assemblies.
        private static string WindowsSteamPath()
        {
            try
            {
                var registry = Type.GetType("Microsoft.Win32.Registry, mscorlib");
                var getValue = registry?.GetMethod("GetValue", new[] { typeof(string), typeof(string), typeof(object) });
                return getValue?.Invoke(null, new object[] { @"HKEY_CURRENT_USER\Software\Valve\Steam", "SteamPath", null }) as string;
            }
            catch (Exception) { return null; }
        }

        // Keep filesystem discovery independent from editor state, including explicit overrides.
        internal static ClientInstallation LocateInstallation(string configuredClient, string configuredAvatars,
            string engine, IEnumerable<string> steamRoots, string localLow, bool windows)
        {
            var result = new ClientInstallation();
            var libraries = new List<string>(steamRoots);
            foreach (var root in libraries.ToArray())
            {
                string vdf = Path.Combine(root, "steamapps", "libraryfolders.vdf");
                if (!File.Exists(vdf)) continue;
                foreach (Match match in Regex.Matches(File.ReadAllText(vdf), "\\\"path\\\"\\s+\\\"([^\\\"]+)\\\""))
                    libraries.Add(match.Groups[1].Value.Replace("\\\\", "\\"));
            }
            string client = configuredClient;
            if (string.IsNullOrWhiteSpace(client))
                client = libraries.Distinct().Select(p => Path.Combine(p, "steamapps", "common", "VRChat"))
                    .FirstOrDefault(p => File.Exists(Path.Combine(p, "VRChat_Data", "globalgamemanagers")));
            result.Directory = string.IsNullOrWhiteSpace(client) ? "" : Path.GetFullPath(client);
            result.AvatarDirectory = !string.IsNullOrWhiteSpace(configuredAvatars)
                ? Path.GetFullPath(configuredAvatars) : windows ? localLow : "";
            if (!windows && string.IsNullOrEmpty(result.AvatarDirectory) && !string.IsNullOrEmpty(result.Directory))
            {
                // Infer the prefix from the selected installation itself. A missing
                // prefix must never route an avatar to an unrelated Steam library.
                var common = System.IO.Directory.GetParent(result.Directory);
                var steamapps = common?.Parent;
                if (common?.Name == "common" && steamapps?.Name == "steamapps")
                {
                    string users = Path.Combine(steamapps.FullName, "compatdata", "438100", "pfx", "drive_c", "users");
                    string standard = Path.Combine(users, "steamuser");
                    if (System.IO.Directory.Exists(standard))
                        result.AvatarDirectory = Path.Combine(standard, "AppData", "LocalLow", "VRChat", "VRChat", "Avatars");
                    else if (System.IO.Directory.Exists(users))
                    {
                        var profiles = System.IO.Directory.GetDirectories(users)
                            .Select(p => Path.Combine(p, "AppData", "LocalLow", "VRChat", "VRChat"))
                            .Where(System.IO.Directory.Exists).ToArray();
                        if (profiles.Length == 1) result.AvatarDirectory = Path.Combine(profiles[0], "Avatars");
                    }
                }
            }
            result.EngineVersion = ReadClientEngine(result.Directory);
            string expected = (engine ?? "").Split('-')[0];
            string actual = (result.EngineVersion ?? "").Split('-')[0];
            if (string.IsNullOrEmpty(actual))
                result.Error = "Select the installed VRChat client directory (the folder containing VRChat.exe).";
            else if (actual != expected)
                result.Error = "This client uses Unity " + result.EngineVersion + ". Local Build & Test needs a client using Unity " + expected + ".";
            else if (string.IsNullOrEmpty(result.AvatarDirectory))
                result.Error = "Select this client's local Avatars folder in Locations. On Linux it is inside the client's Proton prefix.";
            return result;
        }
    }
}
