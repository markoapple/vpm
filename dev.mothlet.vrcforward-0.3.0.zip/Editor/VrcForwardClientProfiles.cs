using System;
using System.Collections.Generic;
using System.Linq;

namespace VrcForward.Editor
{
    [Serializable]
    internal sealed class VrcForwardClientProfile
    {
        public string id, name, clientDirectory, localAvatarDirectory;
    }

    // Profiles are named location choices. The legacy fields remain the active
    // configuration, so older settings and existing SDK delivery keep working.
    internal static class VrcForwardClientProfiles
    {
        internal static IEnumerable<VrcForwardClientProfile> All(VrcForwardSettings settings) =>
            (settings.clientProfiles ?? new List<VrcForwardClientProfile>())
                .Where(profile => profile != null && !string.IsNullOrEmpty(profile.id));

        internal static VrcForwardClientProfile Active(VrcForwardSettings settings) =>
            All(settings).FirstOrDefault(profile => profile.id == settings.activeClientProfileId);

        internal static bool Select(VrcForwardSettings settings, string id)
        {
            var profile = All(settings).FirstOrDefault(candidate => candidate.id == id);
            if (!string.IsNullOrEmpty(id) && profile == null) return false;
            settings.activeClientProfileId = profile?.id ?? "";
            if (profile != null)
            {
                settings.clientDirectory = profile.clientDirectory ?? "";
                settings.localAvatarDirectory = profile.localAvatarDirectory ?? "";
            }
            settings.Persist();
            return true;
        }

        internal static VrcForwardClientProfile Add(VrcForwardSettings settings, string detectedClient = null, string detectedAvatars = null)
        {
            if (settings.clientProfiles == null) settings.clientProfiles = new List<VrcForwardClientProfile>();
            int suffix = 1;
            while (!NameAvailable(settings, "Client " + suffix, null)) suffix++;
            var profile = new VrcForwardClientProfile { id = Guid.NewGuid().ToString("N"), name = "Client " + suffix };
            settings.clientProfiles.Add(profile);
            settings.activeClientProfileId = profile.id;
            // A new named installation captures the locations shown in the UI;
            // Auto can still be chosen afterward for either location.
            if (string.IsNullOrEmpty(settings.clientDirectory) && !string.IsNullOrEmpty(detectedClient))
                settings.clientDirectory = detectedClient;
            if (string.IsNullOrEmpty(settings.localAvatarDirectory) && !string.IsNullOrEmpty(detectedAvatars))
                settings.localAvatarDirectory = detectedAvatars;
            CaptureActive(settings);
            settings.Persist();
            return profile;
        }

        internal static bool Rename(VrcForwardSettings settings, string name)
        {
            var profile = Active(settings);
            name = (name ?? "").Trim();
            if (profile == null || !NameAvailable(settings, name, profile.id)) return false;
            profile.name = name;
            settings.Persist();
            return true;
        }

        private static bool NameAvailable(VrcForwardSettings settings, string name, string id) =>
            !string.IsNullOrWhiteSpace(name) && !All(settings).Any(profile => profile.id != id &&
                string.Equals(profile.name, name, StringComparison.OrdinalIgnoreCase));

        internal static void CaptureActive(VrcForwardSettings settings)
        {
            var profile = Active(settings);
            if (profile == null) return;
            profile.clientDirectory = settings.clientDirectory;
            profile.localAvatarDirectory = settings.localAvatarDirectory;
        }

        internal static void DeleteActive(VrcForwardSettings settings)
        {
            var profile = Active(settings);
            if (profile == null) return;
            settings.clientProfiles.Remove(profile);
            // Removing a saved choice leaves its current locations usable.
            settings.activeClientProfileId = "";
            settings.Persist();
        }
    }
}
