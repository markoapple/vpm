using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    // Register intent before creating anything in Assets. The record survives a
    // process crash and deletion remains limited to exact generated folder names.
    internal static class VrcForwardGeneratedAssets
    {
        private static readonly string RecordDirectory = Path.Combine("Library", "VRCForward");
        private static string RecordPath(string registry) => Path.Combine(RecordDirectory, "generated-" + registry + ".txt");

        // Any registry with a record still owns generated folders awaiting cleanup.
        internal static bool CleanupPending => Directory.Exists(RecordDirectory) &&
            Directory.EnumerateFiles(RecordDirectory, "generated-*.txt").Any();

        internal static string CreateFolder(string registry, string prefix)
        {
            string folder = prefix + Guid.NewGuid().ToString("N");
            var owned = Read(registry);
            owned.Add(folder);
            Write(registry, owned);
            if (string.IsNullOrEmpty(AssetDatabase.CreateFolder("Assets", folder.Substring("Assets/".Length))))
                throw new IOException("Unity could not create " + folder + ".");
            return folder;
        }

        // A build-local copy that keeps its authored name and can be saved as an asset.
        internal static T Clone<T>(T source) where T : Object
        {
            var copy = Object.Instantiate(source);
            if (copy == null) throw new InvalidOperationException("Could not copy '" + source.name + "'.");
            copy.name = source.name;
            copy.hideFlags = HideFlags.None;
            return copy;
        }

        // Save copies as sub-assets of main in one generated asset file.
        internal static void SaveCopies(string folder, Object main, IEnumerable<Object> copies, string fallbackName)
        {
            string name = main.name;
            string filename = new string(name.Select(c => c < 32 || "<>:\"/\\|?*".IndexOf(c) >= 0 ? '_' : c).ToArray()).Trim(' ', '.');
            AssetDatabase.CreateAsset(main, folder + "/" + (filename.Length == 0 ? fallbackName : filename) + ".asset");
            foreach (var copy in copies) if (copy != main) AssetDatabase.AddObjectToAsset(copy, main);
            // CreateAsset renames the main object after its file. Keep the authored name.
            main.name = name;
            EditorUtility.SetDirty(main);
            AssetDatabase.SaveAssetIfDirty(main);
            if (!EditorUtility.IsPersistent(main)) throw new InvalidOperationException("Unity did not save the generated assets in " + folder + ".");
        }

        internal static void Cleanup(string registry, string prefix, string legacySessionKey)
        {
            try
            {
                var owned = Read(registry);
                // Adopt old session records once, before clearing their source.
                foreach (string folder in SessionState.GetString(legacySessionKey, "").Split('\n'))
                    if (!string.IsNullOrEmpty(folder)) owned.Add(folder);
                if (owned.Count == 0) return;
                Write(registry, owned);
                SessionState.EraseString(legacySessionKey);
                foreach (string folder in owned.ToArray())
                {
                    if (!folder.StartsWith(prefix, StringComparison.Ordinal) ||
                        !Guid.TryParseExact(folder.Substring(prefix.Length), "N", out _))
                    {
                        Debug.LogWarning("[VRCForward] Invalid generated-folder record: " + folder + ". Check " + RecordPath(registry) + ".");
                        continue;
                    }
                    if (AssetDatabase.IsValidFolder(folder))
                    {
                        if (!AssetDatabase.DeleteAsset(folder)) continue;
                    }
                    else if (Directory.Exists(folder) || File.Exists(folder + ".meta"))
                        continue; // Wait for import; do not forget an existing folder.
                    owned.Remove(folder);
                }
                Write(registry, owned);
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[VRCForward] Could not finish generated-asset cleanup. " +
                    "The ownership record remains at " + RecordPath(registry) + ". " + exception.Message);
            }
        }

        private static HashSet<string> Read(string registry)
        {
            string path = RecordPath(registry);
            return new HashSet<string>(File.Exists(path) ? File.ReadAllLines(path).Where(s => s.Length > 0)
                : Enumerable.Empty<string>(), StringComparer.Ordinal);
        }

        private static void Write(string registry, IEnumerable<string> folders)
        {
            string path = RecordPath(registry);
            string[] values = folders.OrderBy(s => s, StringComparer.Ordinal).ToArray();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if (values.Length == 0) { File.Delete(path); return; }
            string temporary = path + ".tmp";
            using (var stream = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                byte[] content = System.Text.Encoding.UTF8.GetBytes(string.Join("\n", values) + "\n");
                stream.Write(content, 0, content.Length);
                stream.Flush(true);
            }
            if (File.Exists(path)) File.Replace(temporary, path, null);
            else File.Move(temporary, path);
        }
    }
}
