using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // One source of policy interpretation for authoring, explicit linking and export.
    internal static class VrcForwardMipPolicies
    {
        internal readonly struct Policy
        {
            internal readonly int Bias;
            internal readonly bool IgnoreGlobalLimit;
            internal Policy(int bias, bool ignoreGlobalLimit)
            { Bias = bias; IgnoreGlobalLimit = ignoreGlobalLimit; }
        }
        internal sealed class Edit { internal string Group; internal int Mode, Bias; }
        private static readonly Regex QualityEntry = new Regex(@"^m_QualitySettings\.Array\.data\[(\d+)\]\.textureMipmapLimitSettings\.Array\.data\[(\d+)\]\.limitBias(?:Mode)?$", RegexOptions.CultureInvariant);
        internal static Policy? Read(string group, out string unsupported)
        {
            unsupported = null;
            // Read all desktop levels without switching the author's active
            // quality level or touching global rendering settings during a build.
            var settings = QualityAsset();
            if (settings == null) return null;
            using (var serialized = new SerializedObject(settings))
            {
                var names = serialized.FindProperty("m_TextureMipmapLimitGroupNames");
                var levels = serialized.FindProperty("m_QualitySettings");
                if (names == null || levels == null) return null;
                int index = GroupIndex(names, group);
                if (index < 0) return new Policy(0, false); // Unity treats a missing group as the global policy.
                Policy? common = null;
                for (int i = 0; i < levels.arraySize; i++)
                {
                    var level = levels.GetArrayElementAtIndex(i);
                    if (!Included(level)) continue;
                    var entries = level.FindPropertyRelative("textureMipmapLimitSettings");
                    if (entries == null || entries.arraySize <= index) return null;
                    var entry = entries.GetArrayElementAtIndex(index);
                    var bias = entry.FindPropertyRelative("limitBias");
                    var mode = entry.FindPropertyRelative("limitBiasMode");
                    if (bias == null || mode == null) return null;
                    Policy policy;
                    if (mode.intValue == (int)TextureMipmapLimitBiasMode.OverrideGlobalLimit)
                        policy = new Policy(Math.Max(0, bias.intValue), true);
                    else if (mode.intValue == (int)TextureMipmapLimitBiasMode.OffsetGlobalLimit)
                        // Retain global limiting on the rebased array: its
                        // remaining native mip range composes with this offset.
                        policy = new Policy(bias.intValue, false);
                    else return null;
                    if (common.HasValue && (common.Value.Bias != policy.Bias ||
                        common.Value.IgnoreGlobalLimit != policy.IgnoreGlobalLimit))
                    {
                        unsupported = "Group '" + group + "' has different mip policies on different desktop quality levels. " +
                            "Give them the same fixed limit or offset, or link the group in VRChat SDK > VRCForward.";
                        return null;
                    }
                    common = policy;
                }
                return common;
            }
        }

        internal const string QualityAssetPath = "ProjectSettings/QualitySettings.asset";
        internal static UnityEngine.Object QualityAsset() => AssetDatabase.LoadAllAssetsAtPath(QualityAssetPath).FirstOrDefault();

        internal static int GroupIndex(SerializedProperty names, string group)
        {
            if (names == null) return -1;
            for (int i = 0; i < names.arraySize; i++)
                if (names.GetArrayElementAtIndex(i).stringValue == group) return i;
            return -1;
        }

        // Whether a quality level applies to desktop (Standalone) builds.
        internal static bool Included(SerializedProperty level)
        {
            var excluded = level.FindPropertyRelative("excludedTargetPlatforms");
            if (excluded != null)
                for (int i = 0; i < excluded.arraySize; i++)
                    if (excluded.GetArrayElementAtIndex(i).stringValue == "Standalone") return false;
            return true;
        }

        internal static Edit Capture(UndoPropertyModification[] changes)
        {
            var asset = QualityAsset();
            var entries = ChangedEntries(changes, asset);
            if (entries.Length == 0 || entries.Any(e => e.Groups[1].Value != entries[0].Groups[1].Value ||
                e.Groups[2].Value != entries[0].Groups[2].Value)) return null;
            using (var so = new SerializedObject(asset))
                return ReadEdit(so, int.Parse(entries[0].Groups[2].Value), int.Parse(entries[0].Groups[1].Value));
        }

        private static Match[] ChangedEntries(UndoPropertyModification[] changes, UnityEngine.Object asset) =>
            asset == null ? Array.Empty<Match>() : changes.Where(c => c.currentValue?.target == asset)
                .Select(c => QualityEntry.Match(c.currentValue.propertyPath)).Where(m => m.Success).ToArray();

        private static Edit ReadEdit(SerializedObject so, int group, int row)
        {
            var names = so.FindProperty("m_TextureMipmapLimitGroupNames");
            var levels = so.FindProperty("m_QualitySettings");
            if (names == null || levels == null || group < 0 || group >= names.arraySize || row < 0 || row >= levels.arraySize) return null;
            var level = levels.GetArrayElementAtIndex(row);
            if (!Included(level)) return null;
            var policies = level.FindPropertyRelative("textureMipmapLimitSettings");
            if (policies == null || group >= policies.arraySize) return null;
            var policy = policies.GetArrayElementAtIndex(group);
            return new Edit {
                Group = names.GetArrayElementAtIndex(group).stringValue,
                Bias = policy.FindPropertyRelative("limitBias").intValue,
                Mode = policy.FindPropertyRelative("limitBiasMode").intValue
            };
        }

        private static Edit[] CaptureGroups(UndoPropertyModification[] changes)
        {
            var asset = QualityAsset();
            var entries = ChangedEntries(changes, asset);
            if (entries.Length == 0) return Array.Empty<Edit>();
            var edits = new List<Edit>();
            using (var so = new SerializedObject(asset))
            {
                foreach (var group in entries.GroupBy(e => int.Parse(e.Groups[2].Value)).OrderBy(g => g.Key))
                    // A linked group has one desktop policy. Conflicting bulk
                    // rows normalize from its lowest changed included row.
                    foreach (int row in group.Select(e => int.Parse(e.Groups[1].Value)).Distinct().OrderBy(r => r))
                    {
                        var edit = ReadEdit(so, group.Key, row);
                        if (edit == null) continue;
                        edits.Add(edit);
                        break;
                    }
            }
            return edits.ToArray();
        }

        internal static Edit At(string group, int qualityLevel)
        {
            var asset = QualityAsset();
            if (asset == null) return null;
            using (var so = new SerializedObject(asset))
            {
                var names = so.FindProperty("m_TextureMipmapLimitGroupNames");
                return names == null ? null : ReadEdit(so, GroupIndex(names, group), qualityLevel);
            }
        }

        internal static Dictionary<string, int> Set(Edit policy, bool undo)
        {
            var previous = new Dictionary<string, int>();
            using (var so = new SerializedObject(QualityAsset()))
            {
                int group = GroupIndex(so.FindProperty("m_TextureMipmapLimitGroupNames"), policy.Group);
                if (group < 0) return previous;
                var levels = so.FindProperty("m_QualitySettings");
                for (int i = 0; i < levels.arraySize; i++)
                {
                    var level = levels.GetArrayElementAtIndex(i);
                    if (!Included(level)) continue;
                    var entry = level.FindPropertyRelative("textureMipmapLimitSettings").GetArrayElementAtIndex(group);
                    foreach (var (field, value) in Fields(policy))
                    {
                        var property = entry.FindPropertyRelative(field);
                        previous.Add(property.propertyPath, property.intValue);
                        property.intValue = value;
                    }
                }
                if (undo) { Undo.SetCurrentGroupName("Change desktop texture policy"); so.ApplyModifiedProperties(); }
                else so.ApplyModifiedPropertiesWithoutUndo();
            }
            return previous;
        }

        private static (string Field, int Value)[] Fields(Edit edit) => new[] { ("limitBias", edit.Bias), ("limitBiasMode", edit.Mode) };

        internal static string[] Groups()
        {
            var asset = QualityAsset();
            if (asset == null) return Array.Empty<string>();
            using (var so = new SerializedObject(asset))
            {
                var names = so.FindProperty("m_TextureMipmapLimitGroupNames");
                return names == null ? Array.Empty<string>() : Enumerable.Range(0, names.arraySize)
                    .Select(i => names.GetArrayElementAtIndex(i).stringValue).ToArray();
            }
        }

        // Add the propagated fields to the same Undo transaction as the original edit.
        // This works without any open avatar and preserves excluded quality levels.
        internal static UndoPropertyModification[] ExpandLinked(UndoPropertyModification[] modifications)
        {
            var edits = CaptureGroups(modifications)
                .Where(edit => VrcForwardProjectSettings.instance.sharedDesktopGroups.Contains(edit.Group)).ToArray();
            if (edits.Length == 0) return modifications;
            var normalized = modifications.ToArray();
            var added = new List<UndoPropertyModification>();
            var asset = QualityAsset();
            var existing = new HashSet<string>(modifications.Where(m => m.currentValue?.target == asset)
                .Select(m => m.currentValue.propertyPath));
            using (var so = new SerializedObject(asset))
            {
                var names = so.FindProperty("m_TextureMipmapLimitGroupNames");
                var levels = so.FindProperty("m_QualitySettings");
                foreach (var edit in edits)
                {
                    int group = GroupIndex(names, edit.Group);
                    if (group < 0) continue;
                    for (int i = 0; i < levels.arraySize; i++)
                    {
                        var level = levels.GetArrayElementAtIndex(i);
                        if (!Included(level)) continue;
                        var entry = level.FindPropertyRelative("textureMipmapLimitSettings").GetArrayElementAtIndex(group);
                        foreach (var (field, value) in Fields(edit))
                        {
                            var property = entry.FindPropertyRelative(field);
                            if (property.intValue == value) continue;
                            string text = value.ToString(System.Globalization.CultureInfo.InvariantCulture);
                            if (existing.Contains(property.propertyPath))
                                NormalizeCurrent(normalized, asset, property.propertyPath, text);
                            else
                                added.Add(new UndoPropertyModification {
                                    previousValue = new PropertyModification { target = asset, propertyPath = property.propertyPath,
                                        value = property.intValue.ToString(System.Globalization.CultureInfo.InvariantCulture) },
                                    currentValue = new PropertyModification { target = asset, propertyPath = property.propertyPath, value = text }
                                });
                            property.intValue = value;
                        }
                    }
                }
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            return normalized.Concat(added).ToArray();
        }

        private static void NormalizeCurrent(UndoPropertyModification[] modifications, UnityEngine.Object asset, string path, string value)
        {
            // A bulk transaction may explicitly edit a normalized row too.
            // Keep its original Undo value and metadata; record the final Redo value.
            for (int index = 0; index < modifications.Length; index++)
                if (modifications[index].currentValue?.target == asset && modifications[index].currentValue.propertyPath == path)
                    modifications[index].currentValue = new PropertyModification { target = asset, propertyPath = path, value = value };
        }

        // Unity stops reducing at an eight-pixel side and at the last mip, so
        // arrays with one mip or a side under 16 pixels never lose a mip.
        internal static bool CanReduce(Texture2DArray texture, int mipCount) =>
            mipCount > 1 && Math.Min(texture.width, texture.height) >= 16;

        internal static int Reduction(Texture2DArray texture, int bias, int mipCount)
        {
            int dimensionLimit = 0;
            for (int size = Math.Min(texture.width, texture.height); size >= 16; size >>= 1) dimensionLimit++;
            return Math.Max(0, Math.Min(bias, Math.Min(mipCount - 1, dimensionLimit)));
        }
    }
}
