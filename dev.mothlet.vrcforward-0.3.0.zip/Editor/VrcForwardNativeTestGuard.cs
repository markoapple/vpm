using System;
using UnityEditor;
using UnityEngine;
using VRC.SDKBase.Editor;
using VRC.SDKBase.Editor.BuildPipeline;

namespace VrcForward.Editor
{
    /// <summary>
    /// Check the normal SDK's local-test route before it writes a bundle. In a
    /// Windows editor that output is already inside the client's watched folder;
    /// detecting a mismatch only in OnSdkBuildSuccess would be too late.
    /// </summary>
    public sealed class VrcForwardNativeTestGuard : IVRCSDKBuildRequestedCallback
    {
        public int callbackOrder => -100000;

        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            if (requestedBuildType != VRCSDKRequestedBuildType.Avatar) return true;
            VrcForwardBuildContext.Request();
            // Attach before the SDK raises its build-start event, including direct Build().
            VrcForwardSdkBridge.Attach();
            if (!VrcForwardBuildContext.HandlesCurrentTarget ||
                VRC_SdkBuilder.ActiveBuildType != VRC_SdkBuilder.BuildType.Test ||
                !VrcForwardSettings.instance.stageNativeBuildAndTest) return true;
            if (ValidateEnvironment(out var error)) return true;
            return VrcForwardBuildContext.Fail(error);
        }

        public static bool ValidateEnvironment(out string error)
        {
            error = null;
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.StandaloneWindows64)
                error = "Switch the active build target to Windows 64-bit.";
            else
            {
                try
                {
                    var settings = VrcForwardSettings.instance;
                    error = VrcForwardClient.LocateForEditor(settings.clientDirectory, settings.localAvatarDirectory, Application.unityVersion).Error;
                }
                catch (Exception exception)
                {
                    error = "Cannot inspect the selected client installation: " + exception.Message;
                }
            }
            return string.IsNullOrEmpty(error);
        }
    }
}
