using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using VRC.SDKBase.Editor;
using VRC.SDK3A.Editor;
using VRC.SDKBase.Editor.BuildPipeline;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    /// <summary>
    /// Native mip stripping records a per-resource base mip. At runtime that base
    /// is subtracted from the global limit. Padding and stripping only build
    /// copies therefore represents a negative offset without a shader emulator.
    /// </summary>
    [InitializeOnLoad]
    public sealed class VrcForwardNegativeMipCompatibility :
        IVRCSDKBuildRequestedCallback, IVRCSDKPreprocessAvatarCallback
    {
        private const string GroupPrefix = "VRCForward_NativeMip_";
        private const string QualityPrefix = "VRCForward_FullMips_";
        private const long MaximumStagingBytes = 256L * 1024 * 1024;
        private sealed class Entry
        {
            internal Texture2DArray Copy;
            internal int Padding;
            internal string Group;
        }
        [Serializable] private sealed class Journal
        {
            public int version = 2;
            public int previousQuality;
            public bool previousStripping;
            public string[] groups;
            public string[] folders;
            public string quality;
        }
        private static readonly List<Entry> Pending = new List<Entry>();
        private static bool hookRegistered, exported;
        private static IVRCSdkAvatarBuilderApi sdkBuilder;
        private static VrcForwardSdkAdapter.NativeExportEvents nativeExport;
        internal static string JournalPath => Path.GetFullPath(Path.Combine(Application.dataPath,
            "../Library/VRCForward/native-mip-export.json"));

        static VrcForwardNegativeMipCompatibility()
        {
            AssemblyReloadEvents.beforeAssemblyReload += Cleanup;
            EditorApplication.quitting += Cleanup;
            EditorApplication.delayCall += () =>
            {
                if (!VrcForwardBuildContext.Active) Cleanup();
            };
        }

        public int callbackOrder => 1000000;
        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            if (requestedBuildType != VRCSDKRequestedBuildType.Avatar) return true;
            // A corrupt or unrecoverable record means the previous settings are
            // not known to be restored. This also gates avatars with no negative
            // arrays: exporting under that unknown state would not be safe.
            try { RestoreScope(); }
            catch (Exception exception)
            {
                return VrcForwardBuildContext.Fail("Restore the previous native-mip settings before building: " +
                    exception.Message + " Recovery record: " + JournalPath);
            }
            return true;
        }

        public bool OnPreprocessAvatar(GameObject avatar)
        {
            if (!VrcForwardBuildContext.Active || Pending.Count == 0) return true;
            var used = new HashSet<Object>(EditorUtility.CollectDependencies(new Object[] { avatar }));
            Pending.RemoveAll(entry => entry.Copy == null || !used.Contains(entry.Copy));
            if (Pending.Count == 0 || hookRegistered) return true;
            // The SDK reports this immediately before its ordinary native bundle
            // build, after prefab creation and its own validation/scanner pass.
            if (!VRCSdkControlPanel.TryGetBuilder<IVRCSdkAvatarBuilderApi>(out sdkBuilder))
            {
                Debug.LogError("[VRCForward] Could not attach the native-mip export hook to the SDK builder.");
                return false;
            }
            // SDK 3.10.5 catches exceptions from its native export delegate but
            // assumes they have already notified its error callback. Capture that
            // existing sink; do not replace the builder or its event subscribers.
            try { nativeExport = new VrcForwardSdkAdapter.NativeExportEvents(); }
            catch (Exception exception)
            {
                return VrcForwardBuildContext.Fail(exception.Message);
            }
            sdkBuilder.OnSdkBuildProgress += OnProgress;
            nativeExport.Attach(GuardNativeProgress);
            hookRegistered = true;
            // Export and postprocessing are synchronous in this SDK. A callback
            // that unwinds that stack must not leave settings or build copies
            // behind while the SDK awaits a completion event it will never get.
            EditorApplication.delayCall += RecoverInterruptedExport;
            return true;
        }

        internal static bool IsPrepared(Texture2DArray texture) => Pending.Any(p => p.Copy == texture);

        internal static bool CanPrepare(Texture2DArray source, int bias, out string reason)
            => CanPrepareWithBudget(source, bias,
                Pending.Where(e => e.Copy != null).Sum(e => PayloadBytes(e.Copy, e.Padding)), out reason);

        internal static long StagingBytes(Texture2DArray source, int bias, int mipCount = -1) =>
            bias >= 0 || !VrcForwardMipPolicies.CanReduce(source, mipCount < 0 ? source.mipmapCount : mipCount)
                ? 0 : PayloadBytes(source, checked(-bias), mipCount);

        internal static bool CanPrepareWithBudget(Texture2DArray source, int bias, long pending, out string reason, int mipCount = -1)
        {
            reason = null;
            long padding = -(long)bias;
            if (padding <= 0) return true;
            if (!VrcForwardMipPolicies.CanReduce(source, mipCount < 0 ? source.mipmapCount : mipCount)) return true;
            long remaining = Math.Max(0, MaximumStagingBytes - pending);
            int allowed = 0;
            while (allowed < 14 && ((long)source.width << (allowed + 1)) <= SystemInfo.maxTextureSize &&
                ((long)source.height << (allowed + 1)) <= SystemInfo.maxTextureSize &&
                PayloadBytes(source, allowed + 1, mipCount) <= remaining) allowed++;
            if (padding > 14 || (padding <= 14 &&
                (((long)source.width << (int)padding) > SystemInfo.maxTextureSize ||
                 ((long)source.height << (int)padding) > SystemInfo.maxTextureSize)))
            {
                string dimensions = padding < 31
                    ? ((long)source.width << (int)padding) + "×" + ((long)source.height << (int)padding)
                    : source.width + "×" + source.height + " scaled by 2^" + padding;
                reason = "Offset " + bias + " requires " + dimensions + " pixels; this editor supports up to " +
                    SystemInfo.maxTextureSize + "×" + SystemInfo.maxTextureSize + ". Use offset " + (-allowed) + " or higher.";
            }
            else
            {
                long bytes = PayloadBytes(source, (int)padding, mipCount);
                if (bytes > remaining)
                    reason = "Offset " + bias + " needs " + (bytes / 1048576d).ToString("0.0") +
                        " MiB of temporary array data; " + (remaining / 1048576d).ToString("0.0") +
                        " MiB remains in the 256 MiB build budget. Use offset " + (-allowed) + " or higher, or reduce the array size.";
            }
            return reason == null;
        }

        internal static Texture2DArray Prepare(Texture2DArray source, int bias)
        {
            var copy = VrcForwardGeneratedAssets.Clone(source);
            if (!VrcForwardMipPolicies.CanReduce(source, source.mipmapCount))
            {
                using (var serialized = new SerializedObject(copy))
                {
                    serialized.FindProperty("m_MipmapLimitGroupName").stringValue = "";
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                return copy;
            }
            Pending.Add(new Entry { Copy = copy, Padding = checked(-bias),
                Group = GroupPrefix + Guid.NewGuid().ToString("N") });
            // Keep the logical source representation until native export. This
            // also keeps SDK texture accounting and downstream validation honest.
            return copy;
        }

        private static long PayloadBytes(Texture2DArray source, int padding, int mipCount = -1)
        {
            uint blockWidth = GraphicsFormatUtility.GetBlockWidth(source.graphicsFormat);
            uint blockHeight = GraphicsFormatUtility.GetBlockHeight(source.graphicsFormat);
            uint blockSize = GraphicsFormatUtility.GetBlockSize(source.graphicsFormat);
            if (blockWidth == 0 || blockHeight == 0 || blockSize == 0)
                throw new InvalidOperationException("The native array format has no fixed-size storage layout.");
            checked
            {
                long bytes = 0;
                for (int mip = 0; mip < padding + (mipCount < 0 ? source.mipmapCount : mipCount); mip++)
                {
                    long width = Math.Max(1L, ((long)source.width << padding) >> mip);
                    long height = Math.Max(1L, ((long)source.height << padding) >> mip);
                    bytes += ((width + blockWidth - 1) / blockWidth) *
                             ((height + blockHeight - 1) / blockHeight) * blockSize * source.depth;
                }
                return bytes;
            }
        }

        private static void OnProgress(object sender, string message)
        {
            if (message == VrcForwardSdkAdapter.ExportFinished)
            {
                RestoreScope();
                return;
            }
            if (message != VrcForwardSdkAdapter.ExportStarting || exported || Pending.Count == 0) return;
            try
            {
                // Recheck after other preprocessors, and stage one resource at a
                // time instead of retaining a second full list of padded arrays.
                if (Pending.Any(e => e.Copy == null || !EditorUtility.IsPersistent(e.Copy)) ||
                    Pending.Sum(e => PayloadBytes(e.Copy, e.Padding)) > MaximumStagingBytes)
                    throw new InvalidOperationException("The native-mip resources changed or exceeded the aggregate staging budget before export.");
                BeginScope();
                foreach (var entry in Pending)
                {
                    var staging = Pad(entry);
                    try
                    {
                        EditorUtility.CopySerialized(staging, entry.Copy);
                        EditorUtility.SetDirty(entry.Copy);
                        AssetDatabase.SaveAssetIfDirty(entry.Copy);
                    }
                    finally { if (staging != null) Object.DestroyImmediate(staging); }
                }
                exported = true;
            }
            catch (Exception exception)
            {
                try { RestoreScope(); }
                finally { SignalFailure("Native-mip preparation failed: " + exception.Message); }
                throw;
            }
        }

        private static void GuardNativeProgress(object sender, string message)
        {
            // This runs after the SDK's public progress subscribers. Removing or
            // skipping preparation cannot silently export the logical placeholders.
            if (Pending.Count > 0 && !exported &&
                (message == VrcForwardSdkAdapter.ExportStarting || message == VrcForwardSdkAdapter.ExportFinished))
            {
                const string error = "The SDK skipped native-mip preparation; the avatar build was stopped.";
                SignalFailure(error);
                throw new InvalidOperationException(error);
            }
        }

        private static void SignalFailure(string message)
        {
            VrcForwardBuildContext.Fail(message);
            nativeExport?.Fail("[VRCForward] " + message);
        }

        private static void RecoverInterruptedExport()
        {
            if (!hookRegistered) return;
            var export = nativeExport;
            bool unsettled = sdkBuilder != null && sdkBuilder.BuildState == SdkBuildState.Building;
            VrcForwardTextureArrayCompatibility.Cleanup();
            VrcForwardAudioResourceCompatibility.Cleanup();
            if (unsettled)
            {
                const string message = "Native avatar export was interrupted. Check the Console for export and cleanup errors before rebuilding.";
                VrcForwardBuildContext.Fail(message);
                export?.Fail(message);
            }
        }

        private static Texture2DArray Pad(Entry entry)
        {
            Texture2DArray readable = null, padded = null;
            try
            {
                var source = entry.Copy;
                readable = VrcForwardTextureArrayCompatibility.ReadableCopy(source);
                readable.ignoreMipmapLimit = true;
                readable.Apply(false, false);
                int count = source.mipmapCount + entry.Padding;
                padded = new Texture2DArray(source.width << entry.Padding, source.height << entry.Padding,
                    source.depth, source.graphicsFormat, TextureCreationFlags.MipChain, count)
                    { name = source.name, hideFlags = HideFlags.None };
                if (padded.graphicsFormat != source.graphicsFormat)
                    throw new InvalidOperationException("The native array format changed during negative-mip preparation.");
                for (int layer = 0; layer < source.depth; layer++)
                    for (int mip = 0; mip < count; mip++)
                    {
                        if (mip < entry.Padding)
                            padded.SetPixelData(new byte[padded.GetPixelData<byte>(mip, layer).Length], mip, layer);
                        else
                        {
                            var bytes = readable.GetPixelData<byte>(mip - entry.Padding, layer);
                            if (bytes.Length != padded.GetPixelData<byte>(mip, layer).Length)
                                throw new InvalidOperationException("Negative-mip array payload size changed.");
                            padded.SetPixelData(bytes, mip, layer);
                        }
                    }
                using (var destination = new SerializedObject(padded))
                {
                    VrcForwardTextureArrayCompatibility.CopyTextureSettings(source, destination);
                    destination.FindProperty("m_MipmapLimitGroupName").stringValue = entry.Group;
                    destination.FindProperty("m_IgnoreMipmapLimit").boolValue = false;
                    destination.ApplyModifiedPropertiesWithoutUndo();
                }
                padded.Apply(false, true);
                var result = padded; padded = null; return result;
            }
            finally
            {
                if (readable != null) Object.DestroyImmediate(readable);
                if (padded != null) Object.DestroyImmediate(padded);
            }
        }

        private static void BeginScope()
        {
            if (File.Exists(JournalPath))
                throw new InvalidOperationException("An earlier native-mip export has not been recovered.");
            var journal = new Journal { previousStripping = PlayerSettings.mipStripping,
                previousQuality = QualitySettings.GetQualityLevel(),
                groups = Pending.Select(p => p.Group).ToArray(),
                folders = Pending.Select(p => Path.GetDirectoryName(AssetDatabase.GetAssetPath(p.Copy)).Replace('\\', '/'))
                    .Where(OwnedFolder).Distinct().ToArray(),
                quality = PlayerSettings.mipStripping ? "" : QualityPrefix + Guid.NewGuid().ToString("N") };
            Directory.CreateDirectory(Path.GetDirectoryName(JournalPath));
            // Write the recovery record before touching project settings. It also
            // survives an interrupted editor, unlike SessionState alone.
            string temporaryJournal = JournalPath + ".tmp";
            if (File.Exists(temporaryJournal)) File.Delete(temporaryJournal);
            using (var stream = new FileStream(temporaryJournal, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
            using (var writer = new StreamWriter(stream))
            {
                writer.Write(JsonUtility.ToJson(journal)); writer.Flush(); stream.Flush(true);
            }
            File.Move(temporaryJournal, JournalPath);
            foreach (var entry in Pending) TextureMipmapLimitGroups.CreateGroup(entry.Group);
            var settings = QualityObject();
            using (var serialized = new SerializedObject(settings))
            {
                var names = serialized.FindProperty("m_TextureMipmapLimitGroupNames");
                var levels = serialized.FindProperty("m_QualitySettings");
                if (names == null || levels == null || levels.arraySize == 0)
                    throw new InvalidOperationException("Unity's quality-setting schema changed.");
                // Preserve native stripping that the original project already
                // requested, in addition to removing our temporary top padding.
                var padding = Pending.ToDictionary(e => e.Group,
                    e => checked(e.Padding + VrcForwardTextureArrayCompatibility.ExportMipSkip(e.Copy)));
                if (!journal.previousStripping)
                {
                    int index = levels.arraySize;
                    levels.InsertArrayElementAtIndex(index);
                    var full = levels.GetArrayElementAtIndex(index);
                    full.FindPropertyRelative("name").stringValue = journal.quality;
                    full.FindPropertyRelative("globalTextureMipmapLimit").intValue = 0;
                    full.FindPropertyRelative("excludedTargetPlatforms").ClearArray();
                    var entries = full.FindPropertyRelative("textureMipmapLimitSettings");
                    for (int i = 0; i < entries.arraySize; i++) SetLimit(entries.GetArrayElementAtIndex(i), 0);
                }
                for (int q = 0; q < levels.arraySize; q++)
                {
                    var entries = levels.GetArrayElementAtIndex(q).FindPropertyRelative("textureMipmapLimitSettings");
                    for (int i = 0; i < names.arraySize; i++)
                        if (padding.TryGetValue(names.GetArrayElementAtIndex(i).stringValue, out int count))
                            SetLimit(entries.GetArrayElementAtIndex(i), count);
                }
                serialized.ApplyModifiedPropertiesWithoutUndo();
            }
            PlayerSettings.mipStripping = true;
        }

        private static void SetLimit(SerializedProperty property, int count)
        {
            property.FindPropertyRelative("limitBiasMode").intValue = (int)TextureMipmapLimitBiasMode.OverrideGlobalLimit;
            property.FindPropertyRelative("limitBias").intValue = count;
        }
        private static Object QualityObject() => VrcForwardMipPolicies.QualityAsset()
            ?? throw new InvalidOperationException("Unity's quality settings could not be loaded.");

        internal static void RequireExported()
        {
            if (hookRegistered && Pending.Count > 0 && !exported)
            {
                const string message = "The SDK did not invoke the native-mip export hook. The negative-offset avatar build is not valid.";
                SignalFailure(message);
                throw new InvalidOperationException(message);
            }
        }

        public static void Cleanup()
        {
            EditorApplication.delayCall -= RecoverInterruptedExport;
            if (sdkBuilder != null) sdkBuilder.OnSdkBuildProgress -= OnProgress;
            nativeExport?.Dispose();
            sdkBuilder = null; nativeExport = null;
            try { RestoreScope(); }
            catch (Exception exception) { Debug.LogError("[VRCForward] Could not recover native-mip export settings: " + exception.Message); }
            Pending.Clear(); hookRegistered = false; exported = false;
        }
        private static void RestoreScope()
        {
            if (!File.Exists(JournalPath)) return;
            var journal = JsonUtility.FromJson<Journal>(File.ReadAllText(JournalPath));
            if (journal == null || (journal.version != 1 && journal.version != 2) || journal.groups == null ||
                journal.groups.Any(g => !OwnedName(g, GroupPrefix)) ||
                (!string.IsNullOrEmpty(journal.quality) && !OwnedName(journal.quality, QualityPrefix)))
                throw new InvalidOperationException("Invalid native-mip recovery journal; no project settings were changed.");
            if (journal.folders != null && journal.folders.Any(folder => !OwnedFolder(folder)))
                throw new InvalidOperationException("Invalid native-mip recovery folder; no project settings were changed.");
            var settings = QualityObject();
            if (!string.IsNullOrEmpty(journal.quality) && journal.version >= 2 &&
                QualitySettings.names[QualitySettings.GetQualityLevel()] == journal.quality)
                QualitySettings.SetQualityLevel(Mathf.Clamp(journal.previousQuality, 0, QualitySettings.names.Length - 2), false);
            if (!string.IsNullOrEmpty(journal.quality))
                using (var serialized = new SerializedObject(settings))
                {
                    var levels = serialized.FindProperty("m_QualitySettings");
                    for (int i = levels.arraySize - 1; i >= 0; i--)
                        if (levels.GetArrayElementAtIndex(i).FindPropertyRelative("name").stringValue == journal.quality)
                            levels.DeleteArrayElementAtIndex(i);
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
            foreach (var group in journal.groups)
                if (TextureMipmapLimitGroups.HasGroup(group)) TextureMipmapLimitGroups.RemoveGroup(group);
            PlayerSettings.mipStripping = journal.previousStripping;
            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssetIfDirty(settings);
            if (!hookRegistered && journal.folders != null)
                foreach (var folder in journal.folders)
                    if (AssetDatabase.IsValidFolder(folder) && !AssetDatabase.DeleteAsset(folder))
                        throw new IOException("Could not recover generated native-mip assets at " + folder);
            File.Delete(JournalPath);
        }
        private static bool OwnedFolder(string value) => OwnedName(value, VrcForwardTextureArrayCompatibility.FolderPrefix);
        private static bool OwnedName(string value, string prefix) => value != null &&
            value.StartsWith(prefix, StringComparison.Ordinal) && Guid.TryParseExact(value.Substring(prefix.Length), "N", out _);
    }
}
