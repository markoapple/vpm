using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // Project intent is shared; paths and one-time warning acknowledgements are not.
    [FilePath("ProjectSettings/VRCForward.asset", FilePathAttribute.Location.ProjectFolder)]
    internal sealed class VrcForwardProjectSettings : ScriptableSingleton<VrcForwardProjectSettings>
    {
        [SerializeField] internal bool vrchatProject = true;
        [SerializeField] internal List<string> sharedDesktopGroups = new List<string>();
        internal void ShareGroup(string group)
        {
            if (!sharedDesktopGroups.Contains(group)) sharedDesktopGroups.Add(group);
            Persist();
        }
        internal void Persist() => Save(true);
    }
}
