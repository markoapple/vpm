using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using VRC.SDKBase.Editor.BuildPipeline;

namespace VrcForward.Editor
{
    /// <summary>
    /// SDK 3.10.5 can reset each quality preset's mip-group table on editor startup
    /// and reload. Unity 6 arrays use that authored table, so clearing it loses
    /// the policy before the avatar build-copy adapter can read it.
    /// </summary>
    [InitializeOnLoad]
    public sealed class VrcForwardQualitySettingsCompatibility : IVRCSDKBuildRequestedCallback
    {
        private const string GroupSettings = "textureMipmapLimitSettings";
        private static bool warned;
        private static readonly List<KeyValuePair<IDictionary<string, object>, object>> Changes =
            new List<KeyValuePair<IDictionary<string, object>, object>>();

        // EnvConfig configures the project on EditorApplication.update. Remove
        // only its obsolete empty-table reset during domain initialization,
        // before that first update, rather than restoring project assets later.
        static VrcForwardQualitySettingsCompatibility() => Refresh();

        internal static void Refresh()
        {
            // Quality presets belong to the project, across build targets.
            if (VrcForwardSettings.IsVRChatProject && VrcForwardBuildContext.Compatible) Apply();
            else
            {
                for (int i = Changes.Count - 1; i >= 0; i--)
                {
                    var change = Changes[i];
                    if (!change.Key.ContainsKey(GroupSettings)) change.Key.Add(GroupSettings, change.Value);
                    Changes.RemoveAt(i);
                }
            }
        }

        public int callbackOrder => -100030;

        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            if (requestedBuildType == VRCSDKRequestedBuildType.Avatar) Refresh();
            return true;
        }

        /// <summary>
        /// Preserve authored group entries without changing any other SDK preset
        /// value, quality default, project asset, or runtime rendering setting.
        /// Idempotent; a future SDK's non-empty policy is left untouched.
        /// </summary>
        public static int Apply()
        {
            if (!VrcForwardSettings.IsVRChatProject || !VrcForwardBuildContext.Compatible) return 0;
            try
            {
                var presets = VrcForwardSdkAdapter.QualityPresets();

                int removed = 0;
                foreach (var preset in presets)
                {
                    if (preset == null || !preset.TryGetValue(GroupSettings, out var value)) continue;
                    // This exact reset value belongs to the SDK version being
                    // adapted. Do not replace new vendor behavior or other tools.
                    if (!(value is string[] empty) || empty.Length != 0) continue;
                    if (preset.Remove(GroupSettings))
                    {
                        Changes.Add(new KeyValuePair<IDictionary<string, object>, object>(preset, value));
                        removed++;
                    }
                }
                return removed;
            }
            catch (Exception exception)
            {
                if (!warned)
                {
                    warned = true;
                    Debug.LogWarning("[VRCForward] Could not preserve authored mip-group settings during SDK setup. " +
                        "The SDK's original quality setup remains in use. " + exception.Message);
                }
                return 0;
            }
        }
    }
}
