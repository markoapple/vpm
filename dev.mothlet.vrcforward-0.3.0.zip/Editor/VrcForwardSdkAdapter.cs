using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using VRC.SDKBase.Editor;
using VRC.SDKBase.Validation.Performance.Scanners;

namespace VrcForward.Editor
{
    // Version-specific SDK internals live here; feature passes own their policies
    // and restore only the values they changed in these vendor-owned tables.
    internal static class VrcForwardSdkAdapter
    {
        internal const string Engine = "6000.0.67f1", Sdk = "3.10.5";
        internal const string ExportStarting = "Building the Asset Bundle", ExportFinished = "Bundle Built";

        internal static IDictionary<string, object>[] QualityPresets() =>
            typeof(VRC.Editor.EnvConfig).GetField("_graphicsPresets", BindingFlags.Static | BindingFlags.NonPublic)
                ?.GetValue(null) as IDictionary<string, object>[] ??
                throw new InvalidOperationException("The SDK quality-preset definitions are unavailable.");

        internal static IDictionary<TextureFormat, float> TextureFormats() =>
            typeof(MeshPerformanceScanner).GetField("_texture2DBytesPerPixelLookup", BindingFlags.Static | BindingFlags.NonPublic)
                ?.GetValue(null) as IDictionary<TextureFormat, float> ??
                throw new InvalidOperationException("The SDK texture-format lookup is unavailable.");

        internal sealed class NativeExportEvents : IDisposable
        {
            private readonly object builder;
            private readonly EventInfo progress;
            private readonly EventHandler<string> error;
            private EventHandler<string> handler;

            internal NativeExportEvents()
            {
                builder = typeof(VRC_SdkBuilder).GetField("_currentBuilder", BindingFlags.Static | BindingFlags.NonPublic)?.GetValue(null);
                var type = builder?.GetType();
                var field = type?.GetField("m_OnBuildError", BindingFlags.Instance | BindingFlags.NonPublic)
                    ?? type?.GetField("OnBuildError", BindingFlags.Instance | BindingFlags.NonPublic);
                error = field?.GetValue(builder) as EventHandler<string>;
                progress = type?.GetEvent("OnBuildProgress");
                if (error == null || progress == null)
                    throw new InvalidOperationException("This SDK does not expose the required native-mip failure guard. No export settings were changed.");
            }

            internal void Attach(EventHandler<string> callback)
            { progress.AddEventHandler(builder, callback); handler = callback; }
            internal void Fail(string message) => error.Invoke(builder, message);
            public void Dispose()
            {
                if (handler != null) progress.RemoveEventHandler(builder, handler);
                handler = null;
            }
        }
    }
}
