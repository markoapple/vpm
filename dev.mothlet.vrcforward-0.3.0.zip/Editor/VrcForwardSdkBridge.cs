using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using VRC.SDK3A.Editor;
using VRC.SDKBase.Editor;
using Debug = UnityEngine.Debug;

namespace VrcForward.Editor
{
    [InitializeOnLoad]
    public static class VrcForwardSdkBridge
    {
        private static IVRCSdkAvatarBuilderApi builder;
        private static Stopwatch elapsed;
        private static string avatarName;
        private static bool testing;
        public static VrcForwardBuildReceipt LastReceipt { get; private set; }
        public static string Status { get; private set; } = "Idle";
        // Set when the most recent handled build failed; cleared by the next build.
        public static string LastBuildError { get; private set; }
        public static event Action Changed;

        static VrcForwardSdkBridge()
        {
            VRCSdkControlPanel.OnSdkPanelEnable += OnPanelEnabled;
            VRCSdkControlPanel.OnSdkPanelDisable += OnPanelDisabled;
            AssemblyReloadEvents.beforeAssemblyReload += Detach;
            EditorApplication.delayCall += Attach;
        }
        private static void OnPanelEnabled(object sender, EventArgs e) => EditorApplication.delayCall += Attach;
        private static void OnPanelDisabled(object sender, EventArgs e)
        {
            // A running build still needs failure cleanup if its panel is closed.
            if (!VrcForwardBuildContext.Active) Detach();
        }
        public static void Attach()
        {
            if (VRCSdkControlPanel.window == null || !VRCSdkControlPanel.TryGetBuilder<IVRCSdkAvatarBuilderApi>(out var current)) return;
            if (ReferenceEquals(current, builder)) return;
            Detach();
            builder = current;
            builder.OnSdkBuildStart += OnBuildStarted;
            builder.OnSdkBuildProgress += OnProgress;
            builder.OnSdkBuildSuccess += OnSuccess;
            builder.OnSdkBuildError += OnError;
            builder.OnSdkBuildFinish += OnFinish;
        }
        private static void Detach()
        {
            if (builder == null) return;
            builder.OnSdkBuildStart -= OnBuildStarted;
            builder.OnSdkBuildProgress -= OnProgress;
            builder.OnSdkBuildSuccess -= OnSuccess;
            builder.OnSdkBuildError -= OnError;
            builder.OnSdkBuildFinish -= OnFinish;
            builder = null;
        }
        private static void OnBuildStarted(object sender, object target)
        {
            VrcForwardBuildContext.Begin();
            if (!VrcForwardBuildContext.Active) return;
            testing = VRC_SdkBuilder.ActiveBuildType == VRC_SdkBuilder.BuildType.Test;
            avatarName = (target as GameObject)?.name ?? "Avatar";
            elapsed = Stopwatch.StartNew();
            LastReceipt = null;
            LastBuildError = null;
            Status = "SDK is building " + avatarName;
            Changed?.Invoke();
        }
        private static void OnFinish(object sender, string message)
        {
            // An SDK callback can reject the next build before OnSdkBuildStart.
            // Never attribute that failure to the previous avatar or stopwatch.
            elapsed?.Stop();
            elapsed = null;
            avatarName = null;
            testing = false;
            VrcForwardBuildContext.End();
            if (VRCSdkControlPanel.window == null) Detach();
        }
        private static void OnProgress(object sender, string message)
        { if (VrcForwardBuildContext.Active) { Status = message; Changed?.Invoke(); } }
        private static void OnError(object sender, string message)
        {
            if (!VrcForwardBuildContext.HandlesCurrentTarget) return;
            var receipt = CreateReceipt();
            receipt.error = VrcForwardBuildContext.Failure ?? message;
            LastBuildError = "SDK build failed: " + receipt.error;
            Status = LastBuildError;
            PublishReceipt(receipt);
        }
        private static void OnSuccess(object sender, string path)
        {
            if (!VrcForwardBuildContext.Active || !VrcForwardBuildContext.HandlesCurrentTarget) return;
            var receipt = CreateReceipt();
            receipt.sdkBundle = path;
            receipt.sdkBuildSucceeded = true;
            try
            {
                receipt.bundleEngine = VrcForwardClient.ReadBundleEngine(path);
                receipt.bytes = new FileInfo(path).Length;
                if (testing && VrcForwardSettings.instance.stageNativeBuildAndTest &&
                    EditorUserBuildSettings.activeBuildTarget == BuildTarget.StandaloneWindows64)
                    DeliverToClient(receipt, path);
                Status = receipt.stagedForClient
                    ? "SDK build complete. Copied to the local client; choose it under Avatars > SDK Test Avatars."
                    : "SDK build complete.";
                // Successful builds stay quiet in the Console unless there is somewhere new to look.
                if (receipt.stagedForClient) Debug.Log("[VRCForward] " + Status);
            }
            catch (Exception e)
            {
                receipt.error = e.Message;
                Status = "SDK build complete. VRCForward could not finish processing the output: " + e.Message;
                Debug.LogError("[VRCForward] " + Status);
            }
            PublishReceipt(receipt);
        }
        // Copy a Build & Test bundle into the selected client's local test-avatar folder.
        private static void DeliverToClient(VrcForwardBuildReceipt receipt, string path)
        {
            var settings = VrcForwardSettings.instance;
            var client = VrcForwardClient.LocateForEditor(settings.clientDirectory, settings.localAvatarDirectory, receipt.bundleEngine);
            receipt.clientDirectory = client.Directory;
            receipt.clientEngine = client.EngineVersion;
            if (!string.IsNullOrEmpty(client.Error)) throw new InvalidOperationException(client.Error);
            Directory.CreateDirectory(client.AvatarDirectory);
            string destination = Path.Combine(client.AvatarDirectory, Path.GetFileName(path));
            if (!string.Equals(Path.GetFullPath(path), Path.GetFullPath(destination),
                Application.platform == RuntimePlatform.WindowsEditor ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal))
            {
                // Stage a complete bundle then replace. A client never observes a half-written .vrca.
                string temporary = destination + ".vrcforward-" + receipt.id + ".tmp";
                try
                {
                    File.Copy(path, temporary, false);
                    if (File.Exists(destination)) File.Replace(temporary, destination, null);
                    else File.Move(temporary, destination);
                }
                finally { if (File.Exists(temporary)) File.Delete(temporary); }
            }
            receipt.deliveredBundle = destination;
            receipt.stagedForClient = true;
        }

        private static VrcForwardBuildReceipt CreateReceipt() => new VrcForwardBuildReceipt {
            id = Guid.NewGuid().ToString("N"), timestampUtc = DateTime.UtcNow.ToString("O"),
            editorVersion = Application.unityVersion, sdkVersion = InstalledSdkVersion(),
            baseSdkVersion = InstalledPackageVersion("com.vrchat.base"), adjustments = VrcForwardBuildContext.Adjustments,
            prepared = VrcForwardBuildContext.Prepared,
            buildTarget = EditorUserBuildSettings.activeBuildTarget.ToString(), avatarName = avatarName,
            elapsedMilliseconds = elapsed?.ElapsedMilliseconds ?? 0,
        };

        private static void PublishReceipt(VrcForwardBuildReceipt receipt)
        {
            LastReceipt = receipt;
            string temporary = null;
            try
            {
                Directory.CreateDirectory(VrcForwardBuildHistory.DirectoryPath);
                string destination = Path.Combine(VrcForwardBuildHistory.DirectoryPath, receipt.id + ".json");
                temporary = destination + ".tmp";
                File.WriteAllText(temporary, JsonUtility.ToJson(receipt, true));
                File.Move(temporary, destination);
                VrcForwardBuildHistory.Prune();
            }
            catch (Exception e) { Debug.LogWarning("[VRCForward] Could not save build receipt: " + e.Message); }
            finally
            {
                try { if (temporary != null && File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
            Changed?.Invoke();
        }
        public static string InstalledPackageVersion(string name)
        {
            return UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages()
                .FirstOrDefault(p => p.name == name)?.version;
        }
        public static string InstalledSdkVersion() => InstalledPackageVersion("com.vrchat.avatars") ?? "unknown";

        public static string OptionalToolWarning()
        {
            string ma = InstalledPackageVersion("nadena.dev.modular-avatar");
            if (!string.IsNullOrEmpty(ma) && Version.TryParse(ma.Split('-')[0], out var version)
                && version < new Version(1, 18, 0))
                return "Modular Avatar " + ma + " predates the upstream Unity 6000.0 inspector fix. "
                    + "Update Modular Avatar through ALCOM/VCC.";
            return null;
        }

        public static async Task BuildAndTest(GameObject avatar)
        {
            if (avatar == null) throw new ArgumentNullException(nameof(avatar), "Select an avatar root.");
            if (VRCSdkControlPanel.window == null)
                EditorWindow.GetWindow<VRCSdkControlPanel>(false, "VRChat SDK", true);
            Attach();
            if (builder == null) throw new InvalidOperationException("Open the VRChat SDK panel and retry.");
            if (builder.BuildState == SdkBuildState.Building) throw new InvalidOperationException("An SDK build is already in progress.");
            // Public SDK API retains NDMF, Modular Avatar, validation, and all standard preprocess callbacks.
            await builder.BuildAndTest(avatar);
            if (VrcForwardBuildContext.HandlesCurrentTarget && VrcForwardSettings.instance.stageNativeBuildAndTest &&
                LastReceipt != null && !string.IsNullOrEmpty(LastReceipt.error))
                throw new InvalidOperationException(LastReceipt.error);
        }
    }
}
