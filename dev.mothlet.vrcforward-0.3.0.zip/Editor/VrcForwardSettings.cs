using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace VrcForward.Editor
{
    // Machine-specific paths belong in UserSettings, never in avatar assets or shared ProjectSettings.
    [FilePath("UserSettings/VRCForward.asset", FilePathAttribute.Location.ProjectFolder)]
    public sealed class VrcForwardSettings : ScriptableSingleton<VrcForwardSettings>
    {
        [SerializeField] public string clientDirectory = "";
        [SerializeField] public string localAvatarDirectory = "";
        [SerializeField] public bool stageNativeBuildAndTest = true;
        [SerializeField] internal List<VrcForwardClientProfile> clientProfiles = new List<VrcForwardClientProfile>();
        [SerializeField] internal string activeClientProfileId = "";
        [SerializeField] private List<string> acknowledgedWarnings = new List<string>();
        public static bool IsVRChatProject
        {
            get => VrcForwardProjectSettings.instance.vrchatProject;
            set
            {
                var project = VrcForwardProjectSettings.instance;
                if (project.vrchatProject == value) return;
                project.vrchatProject = value;
                project.Persist();
                VrcForwardAuthoringGuard.Refresh();
                VrcForwardQualitySettingsCompatibility.Refresh();
                VrcForwardTextureFormatCompatibility.Refresh();
            }
        }
        internal bool AcknowledgeWarning(string code)
        {
            if (acknowledgedWarnings.Contains(code)) return false;
            acknowledgedWarnings.Add(code);
            Persist();
            return true;
        }
        internal bool HasAcknowledgedWarnings => acknowledgedWarnings.Count > 0;
        internal void ResetWarnings() { acknowledgedWarnings.Clear(); Persist(); }
        public void Persist() => Save(true);
    }
}
