using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Linq;
using UnityEngine;

namespace VrcForward.Editor
{
    // Sanitize only copied support text; stored receipts retain usable paths.
    internal static class VrcForwardSupportText
    {
        internal static string Copy(string text) => Redact(text,
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            Path.DirectorySeparatorChar == '\\');

        internal static string Redact(string text, string home, bool windows)
        {
            if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(home)) return text ?? "";
            home = home.Replace('\\', '/').TrimEnd('/');
            if (home.Length == 0) return text;
            string pattern = Regex.Escape(home).Replace("/", @"[/\\]") + @"(?=$|[/\\\s""'])";
            return Regex.Replace(text, pattern, "~", windows ? RegexOptions.IgnoreCase | RegexOptions.CultureInvariant : RegexOptions.CultureInvariant);
        }

        internal static string Receipt(VrcForwardBuildReceipt receipt)
        {
            var copy = JsonUtility.FromJson<VrcForwardBuildReceipt>(JsonUtility.ToJson(receipt));
            copy.sdkBundle = Copy(copy.sdkBundle);
            copy.deliveredBundle = Copy(copy.deliveredBundle);
            copy.clientDirectory = Copy(copy.clientDirectory);
            copy.error = Copy(copy.error);
            if (copy.adjustments != null) copy.adjustments = copy.adjustments.Select(Copy).ToArray();
            return JsonUtility.ToJson(copy, true);
        }
    }
}
