using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using VRC.SDKBase.Editor.BuildPipeline;
using Object = UnityEngine.Object;

namespace VrcForward.Editor
{
    /// <summary>
    /// An avatar cannot carry its author's QualitySettings groups. Translate
    /// equivalent desktop-wide policies into native per-array data on build
    /// copies, including materials reached through animation assets.
    /// </summary>
    [InitializeOnLoad]
    public sealed class VrcForwardTextureArrayCompatibility :
        IVRCSDKPreprocessAvatarCallback, IVRCSDKPostprocessAvatarCallback
    {
        internal const string FolderPrefix = "Assets/_VRCForwardArrays_";
        private const string Registry = "texture-arrays";
        private const string FoldersKey = "VRCForward.GeneratedArrayFolders";
        private static readonly string[] TextureSettingFields = { "m_TextureSettings", "m_UsageMode", "m_ColorSpace", "m_IsAlphaChannelOptional" };
        private sealed class Change
        {
            public Object Target;
            public string Path;
            public Object Previous;
        }

        static VrcForwardTextureArrayCompatibility()
        {
            AssemblyReloadEvents.beforeAssemblyReload += Cleanup;
            EditorApplication.quitting += Cleanup;
            EditorApplication.delayCall += () =>
            {
                if (!VrcForwardBuildContext.Active) Cleanup();
            };
        }

        public int callbackOrder => 9998;
        public bool OnPreprocessAvatar(GameObject avatar)
        {
            if (!VrcForwardBuildContext.Preparing) return true;
            if (Prepare(avatar, out var error)) return true;
            return VrcForwardBuildContext.Fail(error, avatar);
        }
        public void OnPostprocessAvatar()
        {
            try { VrcForwardNegativeMipCompatibility.RequireExported(); }
            finally { Cleanup(); }
        }

        public static bool Prepare(GameObject avatar, out string error)
        {
            error = null;
            if (avatar == null || !VrcForwardBuildContext.HandlesCurrentTarget) return true;
            var copies = new Dictionary<Object, Object>();
            var changes = new List<Change>();
            string folder = null;
            try
            {
                var components = avatar.GetComponentsInChildren<Component>(true)
                    .Where(c => c != null && !VrcForwardAssetGraph.IsEditorOnly(c.transform)).Cast<Object>().ToArray();
                var dependencies = VrcForwardAssetGraph.Collect(VrcForwardAssetGraph.RootAssets(components));
                RequireAdaptableShaders(dependencies);
                var rebased = CopyArrays(dependencies, copies);
                if (copies.Count == 0) return true;
                var arrays = copies.Keys.OfType<Texture2DArray>().ToArray();
                folder = VrcForwardGeneratedAssets.CreateFolder(Registry, FolderPrefix);
                var adaptedShaders = CreateMaterialCopies(dependencies.OfType<Material>(), copies, rebased, folder);
                CopyAnimatedMetadata(dependencies.OfType<AnimationClip>(), copies, adaptedShaders.Values);
                CopyAffectedContainers(dependencies, copies);
                foreach (var copy in copies.Values) Rewrite(copy, copies, null);
                RefreshAnimatorCopies(copies);
                VrcForwardGeneratedAssets.SaveCopies(folder, copies[arrays[0]], copies.Values, "TextureArrays");
                foreach (var component in components) Rewrite(component, copies, changes);
                if (EditorUtility.CollectDependencies(VrcForwardAssetGraph.RootAssets(components)).OfType<Texture2DArray>().Any(arrays.Contains))
                    throw new InvalidOperationException("An affected texture-array reference could not be remapped without editing its source asset.");
                VrcForwardBuildContext.AddPrepared(arrays.Length, "texture array", "texture arrays");
                return true;
            }
            catch (Exception exception)
            {
                Rollback(changes, folder, copies);
                error = "Could not preserve texture-array quality policies: " + exception.Message;
                return false;
            }
        }

        // Reject an unadaptable shader before any build copy exists.
        private static void RequireAdaptableShaders(Object[] dependencies)
        {
            var reduced = new HashSet<Texture2DArray>(dependencies.OfType<Texture2DArray>()
                .Where(t => !VrcForwardNegativeMipCompatibility.IsPrepared(t) &&
                    VrcForwardArrayPreflight.NeedsShader(t, t.mipmapLimitGroup, t.ignoreMipmapLimit, t.mipmapCount)));
            foreach (var material in dependencies.OfType<Material>())
                if (!VrcForwardArrayPreflight.CheckShader(material, reduced, out var reason))
                    throw new InvalidOperationException("Material '" + material.name + "': " + reason);
        }

        // Copy every grouped array with its desktop policy baked in. Returns the
        // arrays whose copies lost top mips and therefore need adapted shaders.
        private static HashSet<Texture2DArray> CopyArrays(Object[] dependencies, Dictionary<Object, Object> copies)
        {
            var policies = new Dictionary<string, VrcForwardMipPolicies.Policy?>();
            var rebased = new HashSet<Texture2DArray>();
            foreach (var texture in dependencies.OfType<Texture2DArray>().Distinct())
            {
                if (VrcForwardNegativeMipCompatibility.IsPrepared(texture)) continue;
                var group = texture.mipmapLimitGroup;
                if (string.IsNullOrEmpty(group)) continue;
                if (!VrcForwardBuildContext.RequireCompatibility("Texture array '" + texture.name + "'", out var incompatible))
                    throw new InvalidOperationException(incompatible);
                int bias = 0;
                bool ignore = texture.ignoreMipmapLimit;
                if (!ignore && texture.mipmapCount > 1)
                {
                    if (!policies.TryGetValue(group, out var policy))
                    {
                        policy = VrcForwardMipPolicies.Read(group, out var unsupported);
                        policies.Add(group, policy);
                        if (!policy.HasValue)
                        {
                            if (unsupported == null) throw new InvalidOperationException("Unity's texture-array quality policy could not be read.");
                            VrcForwardAuthoringGuard.ReportBuildFallback(texture, unsupported);
                        }
                    }
                    bias = policy?.Bias ?? 0;
                    ignore = policy?.IgnoreGlobalLimit ?? false;
                }
                if (!ignore && bias < 0)
                {
                    if (VrcForwardNegativeMipCompatibility.CanPrepare(texture, bias, out var reason))
                    {
                        copies.Add(texture, VrcForwardNegativeMipCompatibility.Prepare(texture, bias));
                        continue;
                    }
                    VrcForwardAuthoringGuard.ReportBuildFallback(texture, reason);
                    bias = 0;
                }
                var copy = CopyArray(texture, bias, out bool reduced);
                copies.Add(texture, copy);
                if (reduced) rebased.Add(texture);
                using (var serialized = new SerializedObject(copy))
                {
                    var limit = serialized.FindProperty("m_IgnoreMipmapLimit");
                    var name = serialized.FindProperty("m_MipmapLimitGroupName");
                    if (limit == null || name == null) throw new InvalidOperationException("Unity's texture-array policy fields changed.");
                    limit.boolValue = ignore;
                    name.stringValue = "";
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
            }
            return rebased;
        }

        // Copy ancestors of affected material/texture references, not unrelated
        // mesh buffers, shaders, avatars or audio payloads.
        private static void CopyAffectedContainers(Object[] dependencies, Dictionary<Object, Object> copies)
        {
            bool added;
            do
            {
                added = false;
                foreach (var asset in dependencies)
                {
                    if (copies.ContainsKey(asset) || !CanCopyContainer(asset)) continue;
                    if (!VrcForwardAssetGraph.References(asset).Any(copies.ContainsKey)) continue;
                    copies.Add(asset, VrcForwardGeneratedAssets.Clone(asset));
                    added = true;
                }
            } while (added);
        }

        // Undo component reference swaps and discard every copy and generated folder.
        private static void Rollback(List<Change> changes, string folder, Dictionary<Object, Object> copies)
        {
            foreach (var change in changes.AsEnumerable().Reverse())
            {
                if (change.Target == null) continue;
                using (var serialized = new SerializedObject(change.Target))
                {
                    var property = serialized.FindProperty(change.Path);
                    if (property == null) continue;
                    property.objectReferenceValue = change.Previous;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
            }
            if (folder != null && AssetDatabase.IsValidFolder(folder)) AssetDatabase.DeleteAsset(folder);
            foreach (var copy in copies.Values)
                if (copy != null && !EditorUtility.IsPersistent(copy)) Object.DestroyImmediate(copy);
            VrcForwardNegativeMipCompatibility.Cleanup();
        }

        private static Dictionary<string, VrcForwardArrayShaderCompatibility.Result> CreateMaterialCopies(
            IEnumerable<Material> materials, Dictionary<Object, Object> copies, ISet<Texture2DArray> rebased, string folder)
        {
            var adaptedShaders = new Dictionary<string, VrcForwardArrayShaderCompatibility.Result>();
            // Keep resolved properties and variant inheritance on build
            // copies. The original material hierarchy remains untouched.
            foreach (var material in materials.Distinct())
            {
                if (material.shader == null) continue;
                // Variants may have no locally serialized texture properties.
                // Enumerate the shader, then read the resolved native values.
                var names = Enumerable.Range(0, material.shader.GetPropertyCount())
                    .Where(i => material.shader.GetPropertyType(i) == UnityEngine.Rendering.ShaderPropertyType.Texture)
                    .Select(material.shader.GetPropertyName)
                    .Where(n => material.GetTexture(n) != null && copies.ContainsKey(material.GetTexture(n))).ToArray();
                if (names.Length == 0) continue;
                var copy = new Material(material) { name = material.name, hideFlags = HideFlags.None };
                copies.Add(material, copy); // Also own it if shader adaptation fails.
                var reducedNames = VrcForwardArrayPreflight.Properties(material, rebased);
                VrcForwardArrayShaderCompatibility.Result adaptedShader = null;
                if (reducedNames.Length > 0)
                {
                    var shaderKey = material.shader.GetInstanceID() + ":" + string.Join("|", reducedNames);
                    if (!adaptedShaders.TryGetValue(shaderKey, out adaptedShader))
                    {
                        adaptedShader = VrcForwardArrayShaderCompatibility.Create(material.shader, reducedNames, folder);
                        adaptedShaders.Add(shaderKey, adaptedShader);
                    }
                }
                if (adaptedShader != null)
                {
                    // Flatten only this build copy before changing its shader;
                    // authoring variants and all resolved property values stay intact.
                    copy.parent = null;
                    // Assigning a shader resets Unity's custom render queue.
                    // Keep the flattened value, including the default sentinel.
                    int renderQueue = copy.rawRenderQueue;
                    copy.shader = adaptedShader.Shader;
                    copy.renderQueue = renderQueue;
                }
                foreach (var name in names)
                {
                    var original = (Texture2DArray)material.GetTexture(name);
                    copy.SetTexture(name, (Texture)copies[original]);
                    // Native mip limits retain logical dimensions in this
                    // uniform, although GPU GetDimensions sees the rebased view.
                    var texelSize = name + "_TexelSize";
                    if (adaptedShader != null && adaptedShader.Uniforms.TryGetValue(texelSize, out var uniform))
                        copy.SetVector(uniform, HasSavedVector(material, texelSize) ? material.GetVector(texelSize)
                            : LogicalTexelSize(original));
                }
            }
            return adaptedShaders;
        }

        private static void RefreshAnimatorCopies(Dictionary<Object, Object> copies)
        {
            // Serialized remapping updates the controller graph but does not
            // invalidate dependent AnimatorOverrideController clip caches.
            foreach (var controller in copies.Values.OfType<UnityEditor.Animations.AnimatorController>())
                controller.layers = controller.layers;
            foreach (var entry in copies.Where(e => e.Key is AnimatorOverrideController))
            {
                var source = (AnimatorOverrideController)entry.Key;
                var copy = (AnimatorOverrideController)entry.Value;
                copy.runtimeAnimatorController = copies.TryGetValue(source.runtimeAnimatorController, out var controller)
                    ? (RuntimeAnimatorController)controller : source.runtimeAnimatorController;
                var overrides = new List<KeyValuePair<AnimationClip, AnimationClip>>();
                source.GetOverrides(overrides);
                copy.ApplyOverrides(overrides.Select(pair => new KeyValuePair<AnimationClip, AnimationClip>(
                    pair.Key != null && copies.TryGetValue(pair.Key, out var key) ? (AnimationClip)key : pair.Key,
                    pair.Value != null && copies.TryGetValue(pair.Value, out var value) ? (AnimationClip)value : pair.Value)).ToList());
            }
        }

        private static void CopyAnimatedMetadata(IEnumerable<AnimationClip> clips,
            Dictionary<Object, Object> copies, IEnumerable<VrcForwardArrayShaderCompatibility.Result> shaders)
        {
            var aliases = shaders.SelectMany(shader => shader.Uniforms).Distinct().ToArray();
            if (aliases.Length == 0) return;
            foreach (var source in clips)
            {
                foreach (var binding in AnimationUtility.GetCurveBindings(source))
                {
                    if (binding.type == null || !typeof(Renderer).IsAssignableFrom(binding.type)) continue;
                    foreach (var alias in aliases)
                    {
                        var prefix = "material." + alias.Key;
                        if (binding.propertyName != prefix && !binding.propertyName.StartsWith(prefix + ".", StringComparison.Ordinal)) continue;
                        if (!copies.TryGetValue(source, out var asset))
                        {
                            asset = VrcForwardGeneratedAssets.Clone(source);
                            copies.Add(source, asset);
                        }
                        var adapted = binding;
                        adapted.propertyName = "material." + alias.Value + binding.propertyName.Substring(prefix.Length);
                        // Keep the original curve too: the same renderer/clip can
                        // also select materials which did not need adaptation.
                        AnimationUtility.SetEditorCurve((AnimationClip)asset, adapted, AnimationUtility.GetEditorCurve(source, binding));
                    }
                }
            }
        }

        internal static IEnumerable<Object> AuthoringAssets(GameObject avatar, bool includeEditorOnly)
        {
            // Only established avatar rendering/animation consumers. Arbitrary
            // authoring components can hold editor-only data or be removed by
            // NDMF/SDK; a serialized reference alone is not runtime evidence.
            var components = avatar.GetComponentsInChildren<Component>(true)
                .Where(c => c is Renderer || c is Animator || c is Animation || c is VRC.SDK3.Avatars.Components.VRCAvatarDescriptor)
                .Where(c => c != null && (includeEditorOnly || !VrcForwardAssetGraph.IsEditorOnly(c.transform)));
            return VrcForwardAssetGraph.Collect(VrcForwardAssetGraph.RootAssets(components));
        }

        internal static bool PolicyProblem(Texture2DArray texture, string group, bool ignore, int mipCount,
            long reserved, out string code, out string reason, out long bytes)
        {
            code = reason = null;
            bytes = 0;
            if (ignore || mipCount <= 1 || string.IsNullOrEmpty(group)) return false;
            var policy = VrcForwardMipPolicies.Read(group, out reason);
            if (reason != null) { code = "array-quality-policy"; return true; }
            if (!policy.HasValue || policy.Value.IgnoreGlobalLimit || policy.Value.Bias >= 0) return false;
            if (!VrcForwardNegativeMipCompatibility.CanPrepareWithBudget(texture, policy.Value.Bias, reserved, out reason, mipCount))
            { code = "array-native-staging"; return true; }
            bytes = VrcForwardNegativeMipCompatibility.StagingBytes(texture, policy.Value.Bias, mipCount);
            return false;
        }

        private static Vector4 LogicalTexelSize(Texture2DArray source)
        {
            // Native export can remove authored top mips before the client ever
            // loads the array. Automatic texel metadata describes that delivered
            // logical image, not the editor's pre-export allocation.
            int skip = ExportMipSkip(source);
            int width = Math.Max(1, source.width >> skip), height = Math.Max(1, source.height >> skip);
            return new Vector4(1f / width, 1f / height, width, height);
        }

        internal static int ExportMipSkip(Texture2DArray source)
        {
            if (!PlayerSettings.mipStripping || source.isReadable || source.ignoreMipmapLimit || source.mipmapCount <= 1)
                return 0;
            var settings = VrcForwardMipPolicies.QualityAsset();
            if (settings == null) throw new InvalidOperationException("Unity's quality settings could not be loaded.");
            int minimum = int.MaxValue;
            using (var serialized = new SerializedObject(settings))
            {
                var names = serialized.FindProperty("m_TextureMipmapLimitGroupNames");
                var levels = serialized.FindProperty("m_QualitySettings");
                if (names == null || levels == null) throw new InvalidOperationException("Unity's quality-setting schema changed.");
                int group = VrcForwardMipPolicies.GroupIndex(names, source.mipmapLimitGroup);
                for (int i = 0; i < levels.arraySize; i++)
                {
                    var level = levels.GetArrayElementAtIndex(i);
                    if (!VrcForwardMipPolicies.Included(level)) continue;
                    var global = level.FindPropertyRelative("globalTextureMipmapLimit");
                    if (global == null) throw new InvalidOperationException("Unity's global mip-limit field changed.");
                    long limit = global.intValue;
                    if (group >= 0)
                    {
                        var entries = level.FindPropertyRelative("textureMipmapLimitSettings");
                        if (entries == null || entries.arraySize <= group)
                            throw new InvalidOperationException("Unity's texture-group policy table changed.");
                        var entry = entries.GetArrayElementAtIndex(group);
                        var mode = entry.FindPropertyRelative("limitBiasMode");
                        var bias = entry.FindPropertyRelative("limitBias");
                        if (mode == null || bias == null) throw new InvalidOperationException("Unity's texture-group policy fields changed.");
                        if (mode.intValue == (int)TextureMipmapLimitBiasMode.OverrideGlobalLimit) limit = bias.intValue;
                        else if (mode.intValue == (int)TextureMipmapLimitBiasMode.OffsetGlobalLimit) limit += bias.intValue;
                        else throw new InvalidOperationException("Unity's texture-group policy mode is not supported.");
                    }
                    minimum = Math.Min(minimum, (int)Math.Max(0L, Math.Min(31L, limit)));
                }
            }
            return minimum == int.MaxValue ? 0 : VrcForwardMipPolicies.Reduction(source, minimum, source.mipmapCount);
        }

        private static Texture2DArray CopyArray(Texture2DArray source, int policy, out bool reduced)
        {
            reduced = false;
            if (policy <= 0) return VrcForwardGeneratedAssets.Clone(source);
            Texture2DArray staging = null, result = null;
            try
            {
                staging = ReadableCopy(source);
                // Unity 6000.0 clamps reduction at an eight-pixel minimum
                // dimension and the last available mip. Use the selected desktop
                // policy, not activeMipmapLimit: the active editor quality may be
                // excluded from desktop builds and have a different group policy.
                int skip = VrcForwardMipPolicies.Reduction(source, policy, source.mipmapCount);
                staging.Apply(false, false);
                if (skip == 0)
                {
                    staging.ignoreMipmapLimit = true;
                    staging.Apply(false, !source.isReadable);
                    result = staging; staging = null;
                    return result;
                }
                int count = source.mipmapCount - skip;
                if (count <= 0) throw new InvalidOperationException("Unity reported an invalid texture-array mip limit.");
                var flags = count > 1 ? TextureCreationFlags.MipChain : TextureCreationFlags.None;
                result = new Texture2DArray(Math.Max(1, source.width >> skip), Math.Max(1, source.height >> skip),
                    source.depth, source.graphicsFormat, flags, count) { name = source.name, hideFlags = HideFlags.None };
                if (result.graphicsFormat != source.graphicsFormat) throw new InvalidOperationException("The native array format changed during mip preparation.");
                for (int layer = 0; layer < source.depth; layer++)
                    for (int mip = 0; mip < count; mip++)
                    {
                        var data = staging.GetPixelData<byte>(mip + skip, layer);
                        if (data.Length != result.GetPixelData<byte>(mip, layer).Length)
                            throw new InvalidOperationException("The native array mip payload has an unexpected size.");
                        result.SetPixelData(data, mip, layer);
                    }
                using (var destination = new SerializedObject(result))
                {
                    CopyTextureSettings(source, destination);
                    destination.ApplyModifiedPropertiesWithoutUndo();
                }
                result.ignoreMipmapLimit = true;
                result.Apply(false, !source.isReadable);
                reduced = true;
                return result;
            }
            catch
            {
                if (result != null) Object.DestroyImmediate(result);
                throw;
            }
            finally
            {
                if (staging != null) Object.DestroyImmediate(staging);
            }
        }

        // Imported native assets retain serialized pixels even when their
        // authoring texture is non-readable. Unlock only this private copy.
        internal static Texture2DArray ReadableCopy(Texture2DArray source)
        {
            var copy = VrcForwardGeneratedAssets.Clone(source);
            using (var serialized = new SerializedObject(copy))
            {
                var readable = serialized.FindProperty("m_IsReadable");
                if (readable == null) throw new InvalidOperationException("Unity's texture-array readability field changed.");
                readable.boolValue = true;
                serialized.ApplyModifiedPropertiesWithoutUndo();
            }
            return copy;
        }

        // Sampling, usage and color settings that a newly constructed array lacks.
        internal static void CopyTextureSettings(Texture2DArray source, SerializedObject destination)
        {
            using (var original = new SerializedObject(source))
                foreach (var path in TextureSettingFields)
                {
                    var property = original.FindProperty(path);
                    if (property != null) destination.CopyFromSerializedProperty(property);
                }
        }

        private static bool HasSavedVector(Material material, string name)
        {
            // A user-supplied value (including zero) overrides Unity's automatic
            // texel-size uniform. Preserve it rather than replacing it with ours.
            var seen = new HashSet<Material>();
            for (var current = material; current != null && seen.Add(current); current = current.parent)
            {
                using (var serialized = new SerializedObject(current))
                {
                    var colors = serialized.FindProperty("m_SavedProperties.m_Colors");
                    if (colors == null) continue;
                    for (int i = 0; i < colors.arraySize; i++)
                        if (colors.GetArrayElementAtIndex(i).FindPropertyRelative("first").stringValue == name) return true;
                }
            }
            return false;
        }

        private static bool CanCopyContainer(Object asset) =>
            asset is Material || asset is CustomRenderTexture ||
            asset is AnimationClip || asset is RuntimeAnimatorController || asset is ScriptableObject || asset is StateMachineBehaviour ||
            asset.GetType().Namespace == "UnityEditor.Animations";

        private static void Rewrite(Object target, IDictionary<Object, Object> copies, ICollection<Change> changes)
        {
            // Material.parent is editor-only and is not exposed as a writable
            // SerializedProperty, but CollectDependencies still follows it.
            if (target is Material material && material.parent != null && copies.TryGetValue(material.parent, out var parent))
                material.parent = (Material)parent;
            using (var serialized = new SerializedObject(target))
            {
                var property = serialized.GetIterator();
                bool enter = true;
                while (property.Next(enter))
                {
                    enter = VrcForwardAssetGraph.ShouldEnter(property);
                    if (property.propertyType != SerializedPropertyType.ObjectReference || VrcForwardAssetGraph.IsMetadata(property.name)) continue;
                    var original = property.objectReferenceValue;
                    if (original == null || !copies.TryGetValue(original, out var copy)) continue;
                    changes?.Add(new Change { Target = target, Path = property.propertyPath, Previous = original });
                    property.objectReferenceValue = copy;
                }
                serialized.ApplyModifiedPropertiesWithoutUndo();
            }
        }

        public static void Cleanup()
        {
            VrcForwardNegativeMipCompatibility.Cleanup();
            VrcForwardGeneratedAssets.Cleanup(Registry, FolderPrefix, FoldersKey);
        }
    }
}
