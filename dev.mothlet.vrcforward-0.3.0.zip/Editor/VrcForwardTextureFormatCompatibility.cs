using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;
using VRC.SDKBase.Editor.BuildPipeline;

namespace VrcForward.Editor
{
    /// <summary>
    /// Teach the SDK's existing scanner the native Unity 6 signed texture formats.
    /// The SDK otherwise charges every unknown format as RGBAFloat (16 bytes per
    /// pixel), turning an R8 signed data texture into a sixteenfold overestimate.
    /// No textures, SDK thresholds, shader rules or performance results are replaced.
    /// </summary>
    [InitializeOnLoad]
    public sealed class VrcForwardTextureFormatCompatibility : IVRCSDKBuildRequestedCallback, IActiveBuildTargetChanged
    {
        private static bool warned;
        private sealed class Addition
        {
            internal IDictionary<TextureFormat, float> Table;
            internal TextureFormat Format;
            internal float Value;
        }
        private static readonly List<Addition> Additions = new List<Addition>();

        // Three-channel textures expand to four channels on the Windows/D3D11
        // avatar target, just as RGB24 does in the SDK's existing unsigned table.
        private static readonly KeyValuePair<TextureFormat, float>[] MissingFormats =
        {
            new KeyValuePair<TextureFormat, float>(TextureFormat.R8_SIGNED, 1f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.RG16_SIGNED, 2f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.RGB24_SIGNED, 4f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.RGBA32_SIGNED, 4f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.R16_SIGNED, 2f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.RG32_SIGNED, 4f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.RGB48_SIGNED, 8f),
            new KeyValuePair<TextureFormat, float>(TextureFormat.RGBA64_SIGNED, 8f)
        };

        static VrcForwardTextureFormatCompatibility() => Refresh();

        public void OnActiveBuildTargetChanged(BuildTarget previousTarget, BuildTarget newTarget)
        {
            Refresh();
            VrcForwardAuthoringGuard.Refresh();
        }

        internal static void Refresh()
        {
            if (VrcForwardBuildContext.HandlesCurrentTarget && VrcForwardBuildContext.Compatible) Apply();
            else
            {
                for (int i = Additions.Count - 1; i >= 0; i--)
                {
                    var addition = Additions[i];
                    if (addition.Table.TryGetValue(addition.Format, out var current) && current == addition.Value)
                        addition.Table.Remove(addition.Format);
                    Additions.RemoveAt(i);
                }
            }
        }

        public int callbackOrder => -100020;

        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            if (requestedBuildType == VRCSDKRequestedBuildType.Avatar) Refresh();
            return true;
        }

        /// <summary>
        /// Add only missing native-format definitions. Safe to call repeatedly;
        /// a newer SDK's own definitions always take precedence.
        /// </summary>
        public static int Apply()
        {
            if (!VrcForwardBuildContext.HandlesCurrentTarget || !VrcForwardBuildContext.Compatible) return 0;
            try
            {
                var table = VrcForwardSdkAdapter.TextureFormats();

                var added = 0;
                foreach (var entry in MissingFormats)
                {
                    if (table.ContainsKey(entry.Key)) continue;
                    table.Add(entry.Key, entry.Value);
                    Additions.Add(new Addition { Table = table, Format = entry.Key, Value = entry.Value });
                    added++;
                }
                return added;
            }
            catch (Exception exception)
            {
                if (!warned)
                {
                    warned = true;
                    Debug.LogWarning("[VRCForward] Could not register signed texture formats with the SDK. " +
                        "Its original texture-memory accounting remains in use. " + exception.Message);
                }
                return 0;
            }
        }
    }
}
