using System;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using VRC.SDK3A.Editor;
using VRC.SDKBase.Editor;

namespace VrcForward.Editor
{
    // The SDK owns avatar selection and building. This window owns setup and receipts.
    public sealed class VrcForwardWindow : EditorWindow
    {
        [SerializeField] private bool showLocations;
        [SerializeField] private bool showEnvironment;
        [SerializeField] private bool showPolicies;
        [SerializeField] private Vector2 scroll;
        [SerializeField] private VrcForwardBuildHistoryView buildHistory = new VrcForwardBuildHistoryView();
        [SerializeField] private VrcForwardAvatarCheck avatarCheck = new VrcForwardAvatarCheck();
        private ClientInstallation client;
        private double lastProbe = -10;
        private string sdk, baseSdk, modularAvatar, ndmf, toolWarning, localError, profileError;
        private GUIStyle outer, wrapped, muted, heading;
        private bool stylesAreDark;
        private VrcForwardBuildReceipt savedReceipt;
        private const float LabelWidth = 120;

        [MenuItem("VRChat SDK/VRCForward", false, 601)]
        public static void Open() => GetWindow<VrcForwardWindow>("VRCForward");

        private void OnEnable()
        {
            outer = null;
            minSize = new Vector2(340, 340);
            titleContent = new GUIContent("VRCForward");
            if (buildHistory == null) buildHistory = new VrcForwardBuildHistoryView();
            if (avatarCheck == null) avatarCheck = new VrcForwardAvatarCheck();
            buildHistory.Invalidate();
            VrcForwardSdkBridge.Changed += OnBuildChanged;
            EditorApplication.projectChanged += Invalidate;
            LoadSavedReceipt();
            RefreshEnvironment();
        }
        private void OnDisable()
        {
            VrcForwardSdkBridge.Changed -= OnBuildChanged;
            EditorApplication.projectChanged -= Invalidate;
        }
        private void Invalidate() { lastProbe = -10; Repaint(); }
        private void OnSelectionChange() => Repaint();
        private void OnBuildChanged() { savedReceipt = null; buildHistory?.Invalidate(); Repaint(); }
        private static string BuildError => VrcForwardSdkBridge.LastBuildError;

        private void LoadSavedReceipt()
        {
            savedReceipt = null;
            if (BuildError != null) return;
            savedReceipt = VrcForwardBuildHistory.Read(out _, 8).FirstOrDefault()?.Receipt;
        }
        private void OnInspectorUpdate()
        {
            if (EditorApplication.timeSinceStartup - lastProbe > 4) RefreshEnvironment();
            if (IsBuilding()) Repaint();
        }
        private void RefreshEnvironment()
        {
            lastProbe = EditorApplication.timeSinceStartup;
            sdk = VrcForwardSdkBridge.InstalledSdkVersion();
            baseSdk = VrcForwardSdkBridge.InstalledPackageVersion("com.vrchat.base");
            modularAvatar = VrcForwardSdkBridge.InstalledPackageVersion("nadena.dev.modular-avatar");
            ndmf = VrcForwardSdkBridge.InstalledPackageVersion("nadena.dev.ndmf");
            toolWarning = VrcForwardSdkBridge.OptionalToolWarning();
            if (EditorUserBuildSettings.activeBuildTarget == BuildTarget.StandaloneWindows64) localError = null;
            try
            {
                var settings = VrcForwardSettings.instance;
                client = VrcForwardClient.LocateForEditor(settings.clientDirectory, settings.localAvatarDirectory, Application.unityVersion);
            }
            catch (Exception e) { client = new ClientInstallation { Error = e.Message }; }
            Repaint();
        }
        private static bool IsBuilding() => VrcForwardBuildContext.Active ||
            BuildPipeline.isBuildingPlayer ||
            (VRCSdkControlPanel.window != null && VRCSdkControlPanel.TryGetBuilder<IVRCSdkAvatarBuilderApi>(out var builder) && builder.BuildState == SdkBuildState.Building);

        private void EnsureStyles()
        {
            bool dark = EditorGUIUtility.isProSkin;
            if (outer != null && stylesAreDark == dark) return;
            stylesAreDark = dark;
            outer = new GUIStyle { padding = new RectOffset(12, 12, 12, 12) };
            wrapped = new GUIStyle(EditorStyles.label) { wordWrap = true };
            muted = new GUIStyle(EditorStyles.centeredGreyMiniLabel) { alignment = TextAnchor.MiddleLeft, wordWrap = true };
            heading = new GUIStyle(EditorStyles.boldLabel) { fontSize = 13, wordWrap = true };
        }
        private void OnGUI()
        {
            EnsureStyles();
            if (client == null) RefreshEnvironment();
            bool building = IsBuilding();
            bool busy = building || EditorApplication.isCompiling || EditorApplication.isUpdating;
            bool editorReady = Application.unityVersion == VrcForwardClient.TargetEngine;
            bool sdkReady = sdk == VrcForwardClient.TargetSdk && baseSdk == VrcForwardClient.TargetSdk;
            bool targetReady = EditorUserBuildSettings.activeBuildTarget == BuildTarget.StandaloneWindows64;
            var settings = VrcForwardSettings.instance;
            bool clientReady = !settings.stageNativeBuildAndTest || string.IsNullOrEmpty(client?.Error);
            var oldLabelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = LabelWidth;
            try
            {
                DrawToolbar();
                scroll = EditorGUILayout.BeginScrollView(scroll);
                GUILayout.BeginVertical(outer);
                if (!VrcForwardSettings.IsVRChatProject)
                {
                    GUILayout.Label("VRCForward is off for this project", heading);
                    GUILayout.Label("Avatar preparation, edit checks and local test delivery are disabled.", wrapped);
                    GUILayout.Space(4);
                    using (new EditorGUI.DisabledScope(busy))
                        if (GUILayout.Button("Turn on", GUILayout.Width(100))) VrcForwardSettings.IsVRChatProject = true;
                    GUILayout.EndVertical();
                    EditorGUILayout.EndScrollView();
                    return;
                }
                string status = building ? "Building…" : EditorApplication.isCompiling ? "Compiling…" :
                    !editorReady ? "Feature preparation needs Unity " + VrcForwardClient.TargetEngine :
                    !sdkReady ? "Feature preparation needs SDK " + VrcForwardClient.TargetSdk :
                    !targetReady ? "Windows avatar features inactive" : !clientReady ? "SDK builds ready; set up local testing" : "Ready for SDK builds";
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label(status, heading);
                    if (!clientReady && targetReady && editorReady && sdkReady &&
                        GUILayout.Button("Set up", EditorStyles.miniButton, GUILayout.Width(60))) showLocations = true;
                }
                if (!targetReady)
                {
                    using (new EditorGUI.DisabledScope(busy))
                        if (GUILayout.Button("Switch to Windows 64-bit")) SwitchTarget();
                }
                if (!string.IsNullOrEmpty(localError)) EditorGUILayout.HelpBox(localError, MessageType.Error);
                if (!sdkReady) EditorGUILayout.HelpBox("Use Base and Avatars SDK " + VrcForwardClient.TargetSdk +
                    ". Installed: Base " + (baseSdk ?? "not installed") + ", Avatars " + (sdk ?? "not installed") + ".", MessageType.Info);
                DrawAuthoringNotice();
                using (new EditorGUI.DisabledScope(busy || !VrcForwardBuildContext.Compatible || !targetReady))
                    VrcForwardArrayAuthoring.DrawSelection();

                GUILayout.Space(10);
                DrawLastBuild(building);
                GUILayout.Space(10);
                avatarCheck.Draw(busy);
                GUILayout.Space(10);

                if (Section(ref showPolicies, "Texture array policies"))
                {
                    using (new EditorGUI.DisabledScope(busy || !VrcForwardBuildContext.Compatible || !targetReady))
                        DrawMipPolicies();
                    SectionEnd();
                }
                if (Section(ref showLocations, "Local testing"))
                {
                    using (new EditorGUI.DisabledScope(busy))
                    {
                        EditorGUI.BeginChangeCheck();
                        settings.stageNativeBuildAndTest = EditorGUILayout.ToggleLeft(new GUIContent("Copy Build & Test output to this client",
                            "Avatar preparation still runs when this is off."), settings.stageNativeBuildAndTest);
                        if (EditorGUI.EndChangeCheck()) { settings.Persist(); Repaint(); }
                        DrawLocations();
                    }
                    SectionEnd();
                }
                VrcForwardAutoSaveGui.Draw();
                buildHistory.Draw();
                if (Section(ref showEnvironment, "Project"))
                {
                    DrawProject(busy, targetReady);
                    SectionEnd();
                }
                GUILayout.EndVertical();
                EditorGUILayout.EndScrollView();
            }
            finally { EditorGUIUtility.labelWidth = oldLabelWidth; }
        }

        // A collapsible section with a full-width header. Callers draw the body
        // when this returns true, then call SectionEnd.
        internal static bool Section(ref bool expanded, string title)
        {
            expanded = EditorGUILayout.BeginFoldoutHeaderGroup(expanded, title);
            EditorGUILayout.EndFoldoutHeaderGroup();
            if (expanded) GUILayout.Space(2);
            return expanded;
        }
        internal static void SectionEnd() => GUILayout.Space(8);

        private void DrawToolbar()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                if (GUILayout.Button(new GUIContent("Open SDK", "Open VRChat SDK"), EditorStyles.toolbarButton, GUILayout.Width(70)))
                    EditorWindow.GetWindow<VRCSdkControlPanel>(false, "VRChat SDK", true);
                GUILayout.FlexibleSpace();
                GUILayout.Label("v" + PackageVersion(), EditorStyles.miniLabel, GUILayout.Width(42));
                if (GUILayout.Button("Guide", EditorStyles.toolbarButton, GUILayout.Width(54))) OpenGuide();
                if (GUILayout.Button("Copy diagnostics", EditorStyles.toolbarButton, GUILayout.Width(112)))
                {
                    EditorGUIUtility.systemCopyBuffer = Diagnostics();
                    ShowNotification(new GUIContent("Diagnostics copied"));
                }
            }
        }
        private static void ValueRow(string label, string value) =>
            EditorGUILayout.LabelField(new GUIContent(label), new GUIContent(value ?? "", value ?? ""));

        private void DrawProject(bool busy, bool targetReady)
        {
            using (new EditorGUI.DisabledScope(busy))
            {
                bool vrchat = EditorGUILayout.ToggleLeft(new GUIContent("VRChat project",
                    "Turn off to stop VRCForward's avatar preparation, edit checks and local test delivery in this project."),
                    VrcForwardSettings.IsVRChatProject);
                if (vrchat != VrcForwardSettings.IsVRChatProject) VrcForwardSettings.IsVRChatProject = vrchat;
            }
            ValueRow("Unity", Application.unityVersion);
            ValueRow("Avatars SDK", sdk ?? "Checking…");
            ValueRow("Base SDK", baseSdk ?? "Not installed");
            ValueRow("Build target", targetReady ? "Windows 64-bit" : EditorUserBuildSettings.activeBuildTarget.ToString());
            ValueRow("Client engine", string.IsNullOrEmpty(client?.EngineVersion) ? "Not found" : client.EngineVersion);
            if (!string.IsNullOrEmpty(modularAvatar)) ValueRow("Modular Avatar", modularAvatar);
            if (!string.IsNullOrEmpty(ndmf)) ValueRow("NDMF", ndmf);
            if (!string.IsNullOrEmpty(toolWarning)) EditorGUILayout.HelpBox(toolWarning, MessageType.Warning);
        }

        private void DrawLastBuild(bool building)
        {
            var receipt = VrcForwardSdkBridge.LastReceipt ?? savedReceipt;
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label("Last build", EditorStyles.boldLabel);
                if (receipt != null && !building && DateTimeOffset.TryParse(receipt.timestampUtc, out var completed))
                    GUILayout.Label(new GUIContent(completed.ToLocalTime().ToString("dd MMM · HH:mm"),
                        completed.ToLocalTime().ToString("f")), EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
            }
            if (building) { GUILayout.Label("Building…", muted); return; }
            if (BuildError != null && (receipt == null || receipt.sdkBuildSucceeded))
            { EditorGUILayout.HelpBox(BuildError, MessageType.Error); return; }
            if (receipt == null) { GUILayout.Label("No builds yet", muted); return; }
            string avatarName = string.IsNullOrEmpty(receipt.avatarName) ? "Avatar" : receipt.avatarName;
            GUILayout.Label(avatarName + (receipt.sdkBuildSucceeded ? "" : " — build failed"), wrapped);
            if (receipt.sdkBuildSucceeded)
                GUILayout.Label(VrcForwardBuildHistory.SizeAndTime(receipt) +
                    (string.IsNullOrEmpty(receipt.bundleEngine) ? "" : " · Unity " + receipt.bundleEngine) +
                    (receipt.stagedForClient ? " · copied to local client" : ""), muted);
            if (receipt.prepared != null && receipt.prepared.Length > 0)
                GUILayout.Label("Prepared " + string.Join(", ", receipt.prepared), muted);
            if (!string.IsNullOrEmpty(receipt.error))
                EditorGUILayout.HelpBox(receipt.error, ReferenceEquals(receipt, savedReceipt) ? MessageType.None : MessageType.Error);
            if (receipt.adjustments != null)
                foreach (string adjustment in receipt.adjustments) EditorGUILayout.HelpBox(adjustment, MessageType.Info);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Copy details", EditorStyles.miniButton, GUILayout.Width(90)))
                {
                    EditorGUIUtility.systemCopyBuffer = VrcForwardSupportText.Receipt(receipt);
                    ShowNotification(new GUIContent("Build details copied"));
                }
                // A cleaned client folder need not hide a still-available SDK output.
                string bundle = File.Exists(receipt.deliveredBundle) ? receipt.deliveredBundle : receipt.sdkBundle;
                using (new EditorGUI.DisabledScope(!File.Exists(bundle)))
                    if (GUILayout.Button(new GUIContent("Show file", bundle), EditorStyles.miniButton, GUILayout.Width(90)))
                        EditorUtility.RevealInFinder(bundle);
                GUILayout.FlexibleSpace();
            }
        }
        private void DrawLocations()
        {
            var settings = VrcForwardSettings.instance;
            DrawLocationProfiles(settings);
            EditorGUI.BeginChangeCheck();
            settings.clientDirectory = FolderField("Client", settings.clientDirectory, client?.Directory);
            settings.localAvatarDirectory = FolderField("Test avatars", settings.localAvatarDirectory, client?.AvatarDirectory);
            if (EditorGUI.EndChangeCheck())
            {
                VrcForwardClientProfiles.CaptureActive(settings);
                settings.Persist();
                RefreshEnvironment();
            }
            if (settings.stageNativeBuildAndTest && !string.IsNullOrEmpty(client?.Error))
                EditorGUILayout.HelpBox(client.Error, MessageType.Warning);
        }

        private void DrawLocationProfiles(VrcForwardSettings settings)
        {
            var profiles = VrcForwardClientProfiles.All(settings).ToArray();
            var active = VrcForwardClientProfiles.Active(settings);
            int selected = active == null ? 0 : Array.IndexOf(profiles, active) + 1;
            using (new EditorGUILayout.HorizontalScope())
            {
                int choice = EditorGUILayout.Popup(new GUIContent("Profile", "Named client and test-avatar locations saved on this machine. Editing a location updates the selected profile."), selected,
                    new[] { "Current locations" }.Concat(profiles.Select(profile => profile.name ?? "Unnamed profile")).ToArray());
                if (choice != selected)
                {
                    VrcForwardClientProfiles.Select(settings, choice == 0 ? "" : profiles[choice - 1].id);
                    profileError = null;
                    RefreshEnvironment();
                    active = VrcForwardClientProfiles.Active(settings);
                }
                if (GUILayout.Button(new GUIContent("+", "Save detected or configured locations as a new profile"), EditorStyles.miniButton, GUILayout.Width(24)))
                {
                    active = VrcForwardClientProfiles.Add(settings, client?.Directory, client?.AvatarDirectory);
                    profileError = null;
                }
                using (new EditorGUI.DisabledScope(active == null))
                    if (GUILayout.Button(new GUIContent("−", "Remove this saved profile; keep the current locations"), EditorStyles.miniButton, GUILayout.Width(24)))
                    {
                        VrcForwardClientProfiles.DeleteActive(settings);
                        active = null;
                        profileError = null;
                    }
            }
            if (active != null)
            {
                EditorGUI.BeginChangeCheck();
                string name = EditorGUILayout.DelayedTextField("Name", active.name);
                if (EditorGUI.EndChangeCheck())
                    profileError = VrcForwardClientProfiles.Rename(settings, name) ? null : "Profile names must be unique and not empty.";
            }
            if (!string.IsNullOrEmpty(profileError)) EditorGUILayout.HelpBox(profileError, MessageType.Warning);
        }

        private void DrawMipPolicies()
        {
            var settings = VrcForwardSettings.instance;
            var project = VrcForwardProjectSettings.instance;
            var groups = VrcForwardMipPolicies.Groups();
            GUILayout.Label(groups.Length == 0
                ? "No mip-limit groups yet. Add one in Quality settings, then link it here."
                : "A linked group keeps one policy across every desktop quality level.", wrapped);
            foreach (var group in groups)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label(group, wrapped);
                    bool linked = project.sharedDesktopGroups.Contains(group);
                    if (GUILayout.Button(linked ? "Unlink" : "Link", EditorStyles.miniButton, GUILayout.Width(52)))
                    {
                        if (linked) project.sharedDesktopGroups.Remove(group);
                        if (linked) project.Persist();
                        else ShowLinkMenu(group);
                    }
                }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Quality settings", EditorStyles.miniButton, GUILayout.Width(110))) SettingsService.OpenProjectSettings("Project/Quality");
                if (settings.HasAcknowledgedWarnings && GUILayout.Button("Show notices again", EditorStyles.miniButton, GUILayout.Width(120)))
                    settings.ResetWarnings();
                GUILayout.FlexibleSpace();
            }
        }

        private static void ShowLinkMenu(string group)
        {
            var menu = new GenericMenu();
            var levels = QualitySettings.names;
            for (int i = 0; i < levels.Length; i++)
            {
                var policy = VrcForwardMipPolicies.At(group, i);
                if (policy == null) continue;
                int level = i;
                string description = policy.Mode == (int)TextureMipmapLimitBiasMode.OverrideGlobalLimit ? "fixed " : "offset ";
                menu.AddItem(new GUIContent("Use " + levels[i] + " (" + description + policy.Bias + ")"), false,
                    () => VrcForwardAuthoringGuard.LinkGroup(group, level));
            }
            if (menu.GetItemCount() == 0) menu.AddDisabledItem(new GUIContent("No desktop quality levels"));
            menu.ShowAsContext();
        }

        private static void DrawAuthoringNotice()
        {
            if (string.IsNullOrEmpty(VrcForwardAuthoringNotice.Message)) return;
            EditorGUILayout.HelpBox("Last edit not applied\n" + VrcForwardAuthoringNotice.Message, MessageType.Info);
            using (new EditorGUILayout.HorizontalScope())
            {
                var context = VrcForwardAuthoringNotice.Context;
                if (context != null && GUILayout.Button("Select affected asset", EditorStyles.miniButton))
                { Selection.activeObject = context; EditorGUIUtility.PingObject(context); }
                if (GUILayout.Button("Dismiss", EditorStyles.miniButton)) VrcForwardAuthoringNotice.Clear();
            }
        }
        private static string FolderField(string label, string value, string automatic)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                string displayed = string.IsNullOrEmpty(value) ? automatic ?? "" : value;
                EditorGUI.BeginChangeCheck();
                string edited = EditorGUILayout.DelayedTextField(new GUIContent(label,
                    (string.IsNullOrEmpty(value) ? "Automatic: " : "Override: ") + displayed), displayed);
                if (EditorGUI.EndChangeCheck()) value = edited;
                if (GUILayout.Button(new GUIContent("…", "Choose " + label.ToLowerInvariant() + " folder"), EditorStyles.miniButton, GUILayout.Width(24)))
                {
                    string selected = EditorUtility.OpenFolderPanel(label, displayed, "");
                    if (!string.IsNullOrEmpty(selected)) { value = selected; GUI.changed = true; }
                }
                using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(value)))
                    if (GUILayout.Button(new GUIContent("Auto", "Use the detected location"), EditorStyles.miniButton, GUILayout.Width(40)))
                    { value = ""; GUI.changed = true; }
            }
            return value;
        }
        private void SwitchTarget()
        {
            localError = null;
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
            {
                localError = "Install Windows Build Support (Mono) for Unity " + VrcForwardClient.TargetEngine + " in Unity Hub, then reopen this project.";
                return;
            }
            try
            {
                if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
                    localError = "Unity could not change the build target. Check the Console for the editor's error.";
            }
            catch (Exception e) { localError = e.Message; }
            RefreshEnvironment();
            GUIUtility.ExitGUI();
        }
        private static void OpenGuide()
        {
            var info = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(VrcForwardWindow).Assembly);
            if (info != null) UnityEditorInternal.InternalEditorUtility.OpenFileAtLineExternal(Path.Combine(info.resolvedPath, "README.md"), 1);
        }
        private static string PackageVersion() =>
            UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(VrcForwardWindow).Assembly)?.version ?? "";

        private string Diagnostics()
        {
            var text = new StringBuilder("VRCForward diagnostics\n");
            text.AppendLine("Package: " + PackageVersion());
            text.AppendLine("Editor: " + Application.unityVersion).AppendLine("Avatars SDK: " + sdk).AppendLine("Base SDK: " + baseSdk);
            text.AppendLine("Target: " + EditorUserBuildSettings.activeBuildTarget);
            text.AppendLine("Project use: " + (VrcForwardSettings.IsVRChatProject ? "VRChat" : "Non-VRChat"));
            text.AppendLine("Shared desktop mip groups: " + string.Join(", ", VrcForwardProjectSettings.instance.sharedDesktopGroups));
            text.AppendLine("Local test delivery: " + (VrcForwardSettings.instance.stageNativeBuildAndTest ? "on" : "off"));
            text.AppendLine("Client profile: " + (VrcForwardClientProfiles.Active(VrcForwardSettings.instance)?.name ?? "Current locations"));
            text.AppendLine("Client engine: " + client?.EngineVersion).AppendLine("Client: " + client?.Directory);
            text.AppendLine("Test avatars: " + client?.AvatarDirectory).AppendLine("Detection: " + (client?.Error ?? "OK"));
            text.AppendLine("MA: " + (modularAvatar ?? "not installed")).AppendLine("NDMF: " + (ndmf ?? "not installed"));
            text.AppendLine("SDK status: " + VrcForwardSdkBridge.Status);
            if (!string.IsNullOrEmpty(localError)) text.AppendLine("Setup error: " + localError);
            if (!string.IsNullOrEmpty(VrcForwardAuthoringNotice.Message)) text.AppendLine("Last authoring notice: " + VrcForwardAuthoringNotice.Message);
            return VrcForwardSupportText.Copy(text.ToString());
        }
    }
}
