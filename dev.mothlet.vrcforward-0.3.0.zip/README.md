# VRCForward

Make Unity 6 VRChat avatars with native sound variations, signed texture data and
quality-aware texture arrays. Keep your project and the normal VRChat SDK workflow;
there is no Unity 2022 conversion or separate avatar builder.

## What you can make

- **Varied avatar sounds** with native AudioRandomContainer playlists and
  randomization.
- **Signed shader data** using Unity 6's newer native signed Texture2D formats,
  without packing negative values into unsigned color textures.
- **Quality-aware texture arrays** with fixed mip limits or positive and negative
  global offsets, including animated materials and Read/Write-enabled source arrays.

You author with Unity's own controls; VRCForward prepares the build.

## Install

You need **Unity 6000.0.67f1** with **Windows Build Support (Mono)**.

**New project:** unzip `dev.mothlet.vrcforward-0.3.0-unity6-project.zip`. In ALCOM,
choose **Add Existing Project**, open **Manage** and choose **Install Packages**. The
project includes VRCForward and locks VRChat Base + Avatars SDK 3.10.5, which ALCOM
installs as locked even though it lists no SDK for Unity 6.

**Existing project:** with **VRChat Base + Avatars SDK 3.10.5** installed, choose
**+ > Add package from tarball…** in Unity Package Manager and select
`dev.mothlet.vrcforward-0.3.0.tgz`.

Then use **Build & Test** or **Build & Publish** in the normal **VRChat SDK** panel.

`dev.mothlet.vrcforward-0.3.0.zip` contains the package at its root for VPM distribution tooling.

For Modular Avatar projects, use **Modular Avatar 1.18.7** and **NDMF 1.14.8**.
Local testing needs a VRChat client on the same Unity version as the editor, on
Windows or Linux/Proton.

## The VRCForward window

**VRChat SDK > VRCForward** holds setup, project mode and diagnostics in one place.

If an edit to a texture array would break an open avatar, VRCForward keeps the
previous setting and tells you why, in the array Inspector and in the window.
You can link a mip group so its policy is shared across desktop quality levels;
linked edits stay together, support Undo/Redo and skip excluded quality levels.

Not a VRChat project? Choose **Non-VRChat project** in a notice, or turn
**VRChat project** off under **Project** in the window, and VRCForward stays out of the way.

Copying Build & Test output to your client (**Local testing**) can be turned off on its own; avatar preparation still runs
for Build & Test and Build & Publish. On other Unity/SDK versions, ordinary SDK
builds keep working, and an avatar that needs VRCForward tells you which resource
needs which versions.

Array preparation is automatic. Policies that can't be represented on the build
fall back to the global default for that build, with a note in the Console and the
build details. Your source assets and quality settings stay as you authored them.

## Try a native feature

**Sound variations:** create an Audio Random Container from Unity's Assets > Create >
Audio menu, add AudioClips to its list, and assign it to an AudioSource's Audio Resource
field on the avatar. Build through the SDK.

**Array mip policies:** in Project Settings > Quality, add a mip-limit group. In
**VRChat SDK > VRCForward > Texture array policies**, select **Link** and choose
which desktop quality level's policy to share. Select the Texture2DArray, enable
**Use mip limits** in its normal Inspector, and choose its **Mipmap group**. The same
controls are available in the VRCForward window for selected arrays. Use the array
in the avatar's material.

VRChat's Low, Medium and High presets all keep the global texture limit at 0, so in
VRChat a negative offset currently shows the full-size array; fixed limits and
positive offsets take effect as set.

Fixed limits and positive offsets that remove top mips need readable ShaderLab
source for the material's shader; VRCForward checks it before accepting the edit.
Global/default, ignored, single-mip and size-clamped arrays work with any shader.

The SDK's usual component and performance limits still apply.

## Editor tools

**Avatar check** lists the texture arrays and native audio resources VRCForward will
prepare, and anything that blocks the build. Run it again after edits.

**Scene autosave** is optional and starts off. It saves changed scenes while you're
idle and keeps rotating recovery copies, including for unnamed scenes. **Open copy**
opens a recovered scene alongside your original.

Under **Local testing**, save named client profiles to switch between installations or
Proton prefixes. **Build history** lists past builds and compares size, build time,
editor and SDK versions and preparation adjustments.
